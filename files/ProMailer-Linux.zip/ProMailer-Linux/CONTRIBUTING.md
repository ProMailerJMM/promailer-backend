# 🛠️ Contributing to ProMailer

First off, thank you for taking the time to contribute and help build sovereign, local-first outreach software! ProMailer is open-source, private, and designed for solo builders, developers, and agency operators.

---

## 🚀 Local Development Environment Setup

### 1. Requirements
* **Python 3.10+** (verified on macOS, Windows 10/11, and Linux)
* **SQLite3** (for local datastores)
* Optional: **Ollama** (for local sovereign AI outbox compilation)

### 2. Installation
Clone the repository and install developer dependencies:
```bash
git clone https://github.com/ProMailerJMM/promailer-backend.git
cd promailer-backend
pip install -r requirements.txt
```

### 3. Launching Setup Onboarding
ProMailer features a dark-themed Tkinter GUI setup wizard. To boot the onboarding screen and configure outbox keys:
```bash
python3 app_launcher.py
```
If you are developing in a headless Linux environment, use our classic interactive command line wizard:
```bash
python3 setup_wizard.py
```

---

## 🗄️ Database Concurrency Architecture (WAL Mode)

To allow the Flask dashboard to read data smoothly while background campaign processes are writing, the SQLite connection is configured with Write-Ahead Logging (WAL) and thread locks:
* **Pragma settings:** Every connection executes `PRAGMA journal_mode=WAL` with a custom `timeout=30.0` limit.
* **Modifications:** Always query SQLite through our standardized `get_db_connection()` utility in `database.py` to ensure safe, concurrent transactions.

---

## 📦 Building Platform-Native Executables

ProMailer uses PyInstaller to bundle dependencies, Python runtime, templates, and static directories into native double-clickable apps (zero python required for users). 

We have written dedicated build scripts located inside the `build/` directory for each operating system:

* **macOS (.app bundle):**
  ```bash
  chmod +x build/build_mac.sh
  ./build/build_mac.sh
  ```
* **Windows (.exe bundle):**
  ```cmd
  build\build_windows.bat
  ```
* **Linux (native binary):**
  ```bash
  chmod +x build/build_linux.sh
  ./build/build_linux.sh
  ```

---

## 🔒 Security & Privacy Commitments
To defend user privacy, plaintext API keys or email App Passwords must never leak into log outputs, print functions, or remote cloud services. The setup wizard sets strict local file security properties (`chmod 600` on `.env`) automatically.

*Thank you for supporting sovereign software!*
