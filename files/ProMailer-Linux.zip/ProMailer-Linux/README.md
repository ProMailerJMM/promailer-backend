# ⚡ ProMailer — Sovereign Cold Outreach Workstation (Linux Edition)

🚀 **QUICK START: Run `chmod +x *.sh` in this folder, then execute `./promailer_dashboard.sh` to automatically check your environment, start secure database pipelines, open the dark-mode console, and initiate outreach sends on safe background threads!**

---

ProMailer is a local-first, highly deliverable cold outreach engine built to run natively on Linux workstations (Ubuntu, Debian, Fedora, Arch, etc.). By running entirely on your own workstation, you maintain 100% database privacy, absolute file security, and pay zero ongoing middleman subscription SaaS fees.

---

## 🚀 Easy Onboarding (Under 2 Minutes)

### 1. Unzip the Application Folder
* **Action:** Unzip the `ProMailer-Linux.zip` folder and navigate to the directory in your terminal.
* **Permissions:** Grant execution rights to the shell scripts by running:
  ```bash
  chmod +x *.sh
  ```

### 2. Boot the Outreach Service (`./promailer_dashboard.sh`)
* **Action:** Run the launcher from your shell:
  ```bash
  ./promailer_dashboard.sh
  ```
* **Result:** Checks if Python is installed, automatically installs any missing dependencies (Flask, requests, dotenv, beautifulsoup4), starts your local SQLite WAL database server, and loads the premium web console on **`http://localhost:5050`**!
* **Headless environments:** If `xdg-open` is not available, the launcher gracefully handles it and prints the direct browser URL (`http://localhost:5050`) for easy copying.

### 3. Onboarding Setup Wizard
* **First Launch:** A clean CLI onboarding setup wizard will prompt you in the terminal window to securely input credentials.
* **Setup:** Enter your outbox SMTP credentials, sender display name, custom IMAP server for replies, and chosen AI backend (OpenAI, Anthropic, or 100% local sovereign Ollama).
* **Security:** Configuration parameters are immediately locked down under robust UNIX file permissions (`chmod 600` on `.env`) so no other users on your machine can read them.

### 4. Zero-Terminal Campaign & Reply Engine
Once onboarding is complete:
1. The premium dark-theme web console boots automatically on **`http://localhost:5050`** and loads in your browser.
2. **Campaign outreach and reply tracking run automatically on silent background threads!** As long as the dashboard script is active, ProMailer automatically runs campaign dispatches (respecting your daily 20-email limit and a polite 4-minute cool-down delay) and scans for replies on a silent IMAP loop. You do NOT need to execute secondary shell scripts!

---

## 🔍 In-App AI Lead Finder & Scraper
No more buying lists or scraping websites manually. ProMailer features a built-in search engine:
1. Click the **"Find Leads"** button in the dashboard header.
2. Enter a search query (e.g., `Accountants in Toronto`) and choose your target size.
3. Click **Find & Enrich Leads**.
4. Watch the glassmorphic terminal log stream active website crawls, extract real-time contact emails (`mailto:` and text regex), filter junk domains, and load them **instantly** into your active SQLite outreach pipeline!

---

## 🔒 100% Sovereign Local AI (Ollama Setup)
To compile outreach copy completely offline and free of cost:
1. Download and run [Ollama for Linux](https://ollama.com).
2. Pull your local language model in terminal:
   ```bash
   ollama pull llama3.2:3b
   ```
3. Boot the ProMailer launcher, select Option **[1] (Ollama)** in the setup wizard, and enjoy zero-cost, private text compiling on your local CPU/GPU hardware.

---

Sovereign cold outreach engineered by **[Just Me Media](https://justmemedia.ca)**.  
*© 2026 Just Me Media. All rights reserved.*
