# 🐧 ProMailer for Linux — Sovereign Cold Outreach Engine

> [!NOTE]
> **Linux Launcher:** Run **`chmod +x start_promailer.sh && ./start_promailer.sh`** in your terminal to launch the interactive outbox loop!
> 
> Tested on **Ubuntu 22.04+** and Debian derivatives.

# ⚡ ProMailer — Sovereign Cold Outreach Engine

ProMailer is a local-first, highly deliverable cold outreach workstation built for solo founders, builders, and agency operators. It runs entirely on your own desktop hardware, offering full sovereignty over your database, leads pipeline, and AI text compilers with zero ongoing SaaS middleman subscription costs.

---

## ✨ Features
* **Multi-LLM Native Cascade:** Choose between absolute sovereign local generation (**Ollama**) or high-fidelity cloud models (**OpenAI / Anthropic**) with seamless API key integration.
* **Intelligent Scraping:** Crawls target URLs on-the-fly to synthesize business service lines, context, and cities before composing the outreach.
* **Plaintext Deliverability:** Bypasses marketing spam filters by sending clean, direct, tracking-pixel-free personal messages that land directly in primary text feeds.
* **Gmail SMTP Integration:** Outbound sending with full `Reply-To` parameters.
* **Automatic Reply Tracking:** Secure local IMAP polling detects incoming replies and updates your dashboard instantly, transitioning leads to manual follow-up modes.
* **Sleek Local Dashboard:** High-end glassmorphic dark-theme UI on `localhost:5050` displaying real-time metrics, queue sizes, and deep-inspect brief compiles.

---

## 🚀 Quick Start (Under 3 Minutes)

### 1. Clone & Setup Environments
Ensure you have **Python 3.10+** installed on your workstation.
Navigate to the directory and run:
```bash
pip3 install -r requirements.txt
```

### 2. Run the Interactive Configuration Wizard
ProMailer features a first-run onboarding configuration wizard to validate API keys and setup outbox servers automatically:
```bash
python3 main.py
```
*(If you ever need to update your keys or mail configurations, simply run: `python3 main.py --reconfigure`)*

### 3. Load Your CSV Leads Pipeline
Bootstrap prospects into your local SQLite database:
```bash
python3 prospect_loader.py leads.csv
```
*Columns supported: `business_name`/`company_name`, `email`, `website`, `contact_name`/`name`, `industry`, `city`.*

### 4. Execute Campaign Outreach
Kick off the automated sending pipeline:
```bash
python3 main.py
```
*(Features strict daily limits of 20 emails and an automatic polite 4-minute cool-down gap between sends to preserve domain reputation.)*

### 5. Inspect Performance Dashboard
Launch your premium dark-mode web console:
```bash
python3 dashboard.py
```
Open **`http://localhost:5050`** in your browser to view lead metrics and inspect synthesized emails!

---

## 🐋 Local AI Sovereign Execution (Ollama)
To maintain 100% private, free execution:
1. Download and run [Ollama](https://ollama.com).
2. Pull your model:
   ```bash
   ollama pull llama3.2:3b
   ```
3. Boot the setup wizard and select option `[1]`.

---

## 🔒 Security & Privacy Permissions
Since your campaign pipeline contains highly sensitive prospect emails and custom configurations, file locking is enforced. The setup wizard automatically sets a secure permission layer (`chmod 600`) on your local `.env` file to ensure plaintext App Passwords and API keys remain unreadable to non-admin or system guests on your workstation.

---

Sovereign cold outreach engineered by **[Just Me Media](https://justmemedia.ca)**.
