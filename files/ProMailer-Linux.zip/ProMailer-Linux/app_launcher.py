#!/usr/bin/env python3
"""
ProMailer - Application Launcher
Initializes and starts the campaign engine + dashboard

CROSS-PLATFORM: Works on macOS, Windows, Linux
THREAD-SAFE: Proper initialization order
GRACEFUL SHUTDOWN: Cleans up threads properly
"""

import os
import sys
import time
import threading
import webbrowser
from pathlib import Path

# Ensure imports work from local modules
PROJECT_ROOT = Path(__file__).parent.absolute()
sys.path.insert(0, str(PROJECT_ROOT))

from config import config
from logger import get_logger

logger = get_logger(__name__)


def validate_configuration() -> bool:
    """Validate that essential configuration is set"""
    logger.info("Validating configuration...")
    
    if not config.smtp_user or not config.smtp_password:
        logger.error("SMTP credentials not configured. Run setup wizard.")
        return False
    
    if not config.is_llm_available():
        logger.warning(f"No LLM provider available. Using fallback text generation.")
    
    logger.info("Configuration validated ✓")
    return True


def initialize_campaign_engine():
    """Initialize and start the campaign engine"""
    try:
        import main
        
        logger.info("Starting campaign engine...")
        success = main.start_campaign()
        
        if success:
            logger.info("Campaign engine started ✓")
            return True
        else:
            logger.warning("Campaign engine already running")
            return True
            
    except Exception as e:
        logger.error(f"Failed to start campaign engine: {e}", exc_info=True)
        return False


def initialize_followup_engine():
    """Initialize and start the follow-up engine"""
    try:
        import main
        import follow_up
        
        logger.info("Starting follow-up engine...")
        success = follow_up.start_followup_engine(send_email_func=main.send_email)
        
        if success:
            logger.info("Follow-up engine started ✓")
            return True
        else:
            logger.warning("Follow-up engine already running")
            return True
            
    except Exception as e:
        logger.error(f"Failed to start follow-up engine: {e}", exc_info=True)
        return False


def start_dashboard():
    """Start Flask dashboard server"""
    try:
        from dashboard import app
        
        logger.info("Starting Flask dashboard...")
        
        # Run in a thread so we can return control
        def run_dashboard():
            try:
                app.run(
                    host='127.0.0.1',
                    port=5050,
                    debug=False,
                    use_reloader=False,
                    threaded=True
                )
            except Exception as e:
                logger.error(f"Dashboard error: {e}", exc_info=True)
        
        dashboard_thread = threading.Thread(
            target=run_dashboard,
            daemon=True,
            name="ProMailer-Dashboard"
        )
        dashboard_thread.start()
        
        # Wait for server to be ready
        time.sleep(2)
        logger.info("Dashboard started ✓")
        return True
        
    except Exception as e:
        logger.error(f"Failed to start dashboard: {e}", exc_info=True)
        return False


def open_dashboard():
    """Open dashboard in default browser"""
    try:
        time.sleep(1)  # Give server time to start
        url = "http://localhost:5050"
        logger.info(f"Opening dashboard at {url}")
        webbrowser.open(url)
    except Exception as e:
        logger.warning(f"Could not open browser: {e}")


def shutdown_gracefully():
    """Clean shutdown of all engines"""
    logger.info("Shutting down ProMailer...")
    
    try:
        import main
        main.stop_campaign()
    except Exception as e:
        logger.warning(f"Error stopping campaign: {e}")
    
    try:
        import follow_up
        follow_up.stop_followup_engine()
    except Exception as e:
        logger.warning(f"Error stopping followup: {e}")
    
    logger.info("Shutdown complete")


def main_app():
    """Main application entry point"""
    logger.info("═" * 60)
    logger.info("ProMailer — Sovereign Cold Email Outreach")
    logger.info("═" * 60)
    
    try:
        # Step 1: Validate configuration
        if not validate_configuration():
            logger.error("Configuration validation failed. Exiting.")
            return False
        
        # Step 2: Initialize database
        try:
            from database import init_db
            init_db()
            logger.info("Database initialized ✓")
        except Exception as e:
            logger.error(f"Database initialization failed: {e}")
            return False
        
        # Step 3: Start campaign engine
        if not initialize_campaign_engine():
            logger.warning("Campaign engine failed to start (continuing anyway)")
        
        # Step 4: Start follow-up engine
        if not initialize_followup_engine():
            logger.warning("Follow-up engine failed to start (continuing anyway)")
        
        # Step 5: Start dashboard
        if not start_dashboard():
            logger.error("Dashboard failed to start. Exiting.")
            return False
        
        # Step 6: Open browser
        open_dashboard()
        
        logger.info("═" * 60)
        logger.info("ProMailer is running!")
        logger.info("Dashboard: http://localhost:5050")
        logger.info("═" * 60)
        
        return True
        
    except Exception as e:
        logger.error(f"Application startup failed: {e}", exc_info=True)
        return False


if __name__ == "__main__":
    try:
        success = main_app()
        
        if success:
            # Keep running
            try:
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                logger.info("Received shutdown signal")
        
        shutdown_gracefully()
        sys.exit(0 if success else 1)
        
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)
