"""
ProMailer — Centralized Configuration Management

Provides a single source of truth for all environment variables,
with validation and thread-safe access.
"""

import os
import threading
from dotenv import load_dotenv
from pathlib import Path

# Lock for thread-safe config reloading
_config_lock = threading.RLock()

# Cache configuration after first load
_config_cache = {}
_cache_valid = False

def reload_env():
    """Reload environment variables from .env file."""
    global _config_cache, _cache_valid
    with _config_lock:
        load_dotenv(override=True)
        _config_cache = {}
        _cache_valid = False
        print("[ProMailer] Configuration reloaded from .env")


def get_config(key: str, default=None, cast_type=str):
    """
    Thread-safe config getter with optional type casting.
    Caches values after first access.
    
    Args:
        key: Environment variable name
        default: Default value if not set
        cast_type: Type to cast to (str, int, float, bool)
    
    Returns:
        Configuration value
    """
    global _config_cache, _cache_valid
    
    with _config_lock:
        if key in _config_cache:
            return _config_cache[key]
        
        value = os.getenv(key, default)
        
        # Type conversion
        if value is not None and cast_type != str:
            try:
                if cast_type == bool:
                    value = value.lower() in ('true', '1', 'yes', 'on')
                elif cast_type == int:
                    value = int(value)
                elif cast_type == float:
                    value = float(value)
            except (ValueError, AttributeError):
                print(f"[ProMailer] Warning: Could not cast {key}={value} to {cast_type.__name__}, using default")
                value = default
        
        _config_cache[key] = value
        return value


# ═════════════════════════════════════════════════════════════════════════════
# SMTP / IMAP Configuration
# ═════════════════════════════════════════════════════════════════════════════

def get_smtp_server() -> str:
    """SMTP server hostname"""
    return get_config("SMTP_SERVER", "smtp.gmail.com")


def get_smtp_port() -> int:
    """SMTP server port"""
    return get_config("SMTP_PORT", "587", int)


def get_smtp_user() -> str:
    """SMTP user (email address)"""
    return get_config("SMTP_USER") or get_config("GMAIL_USER") or ""


def get_smtp_password() -> str:
    """SMTP password / app password"""
    return get_config("SMTP_PASSWORD") or get_config("GMAIL_APP_PASSWORD") or ""


def get_sender_name() -> str:
    """Display name for outgoing emails"""
    return get_config("SENDER_NAME", "ProMailer")


def get_reply_to() -> str:
    """Reply-To header address"""
    return get_config("REPLY_TO", "") or get_smtp_user()


def get_imap_server() -> str:
    """IMAP server hostname"""
    return get_config("IMAP_SERVER", "imap.gmail.com")


def get_imap_port() -> int:
    """IMAP server port"""
    return get_config("IMAP_PORT", "993", int)


# ═════════════════════════════════════════════════════════════════════════════
# LLM Provider Configuration
# ═════════════════════════════════════════════════════════════════════════════

def get_llm_provider() -> str:
    """Active LLM provider (ollama, openai, anthropic, google, groq, deepseek, custom)"""
    provider = get_config("LLM_PROVIDER", "ollama").lower().strip()
    valid = ["ollama", "openai", "anthropic", "google", "groq", "deepseek", "custom"]
    if provider not in valid:
        print(f"[ProMailer] Invalid LLM_PROVIDER '{provider}', defaulting to ollama")
        return "ollama"
    return provider


def get_ollama_url() -> str:
    """Ollama API endpoint"""
    return get_config("OLLAMA_URL", "http://localhost:11434/api/generate")


def get_ollama_model() -> str:
    """Ollama model name"""
    return get_config("OLLAMA_MODEL", "llama3.2:3b")


def get_openai_api_key() -> str:
    """OpenAI API key"""
    return get_config("OPENAI_API_KEY", "").strip()


def get_openai_model() -> str:
    """OpenAI model name"""
    return get_config("OPENAI_MODEL", "gpt-4o-mini")


def get_anthropic_api_key() -> str:
    """Anthropic API key"""
    return get_config("ANTHROPIC_API_KEY", "").strip()


def get_anthropic_model() -> str:
    """Anthropic model name"""
    return get_config("ANTHROPIC_MODEL", "claude-3-5-haiku-20241022")


def get_google_api_key() -> str:
    """Google Generative AI API key"""
    return get_config("GOOGLE_API_KEY", "").strip()


def get_google_model() -> str:
    """Google model name"""
    return get_config("GOOGLE_MODEL", "gemini-1.5-flash")


def get_groq_api_key() -> str:
    """Groq API key"""
    return get_config("GROQ_API_KEY", "").strip()


def get_groq_model() -> str:
    """Groq model name"""
    return get_config("GROQ_MODEL", "mixtral-8x7b-32768")


def get_deepseek_api_key() -> str:
    """DeepSeek API key"""
    return get_config("DEEPSEEK_API_KEY", "").strip()


def get_deepseek_model() -> str:
    """DeepSeek model name"""
    return get_config("DEEPSEEK_MODEL", "deepseek-chat")


def get_custom_api_key() -> str:
    """Custom LLM API key"""
    return get_config("LLM_CUSTOM_API_KEY", "").strip()


def get_custom_base_url() -> str:
    """Custom LLM base URL"""
    return get_config("LLM_CUSTOM_BASE_URL", "").strip()


def get_custom_model() -> str:
    """Custom LLM model name"""
    return get_config("LLM_CUSTOM_MODEL", "").strip()


# ═════════════════════════════════════════════════════════════════════════════
# Campaign Configuration
# ═════════════════════════════════════════════════════════════════════════════

def get_daily_send_limit() -> int:
    """Max emails to send per calendar day"""
    return get_config("DAILY_SEND_LIMIT", "20", int)


def get_cooldown_minutes() -> int:
    """Seconds to wait between sending emails"""
    return get_config("COOLDOWN_MINUTES", "4", int) * 60


def get_reply_check_interval_minutes() -> int:
    """How often to check for new replies (minutes)"""
    return get_config("REPLY_CHECK_INTERVAL", "15", int)


# ═════════════════════════════════════════════════════════════════════════════
# Optional APIs
# ═════════════════════════════════════════════════════════════════════════════

def get_google_places_api_key() -> str:
    """Google Places API key (optional, for lead finding)"""
    return get_config("GOOGLE_PLACES_API_KEY", "").strip()


# ═════════════════════════════════════════════════════════════════════════════
# Validation
# ═════════════════════════════════════════════════════════════════════════════

def validate_smtp_config() -> tuple[bool, str]:
    """
    Validate SMTP configuration is complete.
    
    Returns:
        (is_valid, error_message)
    """
    if not get_smtp_user():
        return False, "SMTP_USER is not configured"
    if not get_smtp_password():
        return False, "SMTP_PASSWORD is not configured"
    if not get_sender_name():
        return False, "SENDER_NAME is not configured"
    return True, ""


def validate_llm_config() -> tuple[bool, str]:
    """
    Validate LLM configuration is present.
    Note: Actual API validation happens in llm.py
    
    Returns:
        (is_valid, error_message)
    """
    provider = get_llm_provider()
    
    if provider == "openai" and not get_openai_api_key():
        return False, "OPENAI_API_KEY is not configured for provider 'openai'"
    elif provider == "anthropic" and not get_anthropic_api_key():
        return False, "ANTHROPIC_API_KEY is not configured for provider 'anthropic'"
    elif provider == "google" and not get_google_api_key():
        return False, "GOOGLE_API_KEY is not configured for provider 'google'"
    elif provider == "groq" and not get_groq_api_key():
        return False, "GROQ_API_KEY is not configured for provider 'groq'"
    elif provider == "deepseek" and not get_deepseek_api_key():
        return False, "DEEPSEEK_API_KEY is not configured for provider 'deepseek'"
    elif provider == "custom" and (not get_custom_api_key() or not get_custom_base_url()):
        return False, "LLM_CUSTOM_API_KEY and LLM_CUSTOM_BASE_URL required for provider 'custom'"
    
    return True, ""


def validate_all() -> tuple[bool, list]:
    """
    Validate all critical configuration.
    
    Returns:
        (is_valid, list_of_errors)
    """
    errors = []
    
    valid_smtp, err = validate_smtp_config()
    if not valid_smtp:
        errors.append(f"SMTP: {err}")
    
    valid_llm, err = validate_llm_config()
    if not valid_llm:
        errors.append(f"LLM: {err}")
    
    return len(errors) == 0, errors


if __name__ == "__main__":
    # Test config loading
    reload_env()
    
    print("=== ProMailer Configuration Test ===\n")
    print(f"SMTP User: {get_smtp_user()}")
    print(f"SMTP Server: {get_smtp_server()}:{get_smtp_port()}")
    print(f"Sender Name: {get_sender_name()}")
    print(f"Reply-To: {get_reply_to()}")
    print(f"\nLLM Provider: {get_llm_provider()}")
    print(f"Daily Limit: {get_daily_send_limit()} emails/day")
    print(f"Cooldown: {get_cooldown_minutes()} seconds\n")
    
    valid, errors = validate_all()
    if valid:
        print("✓ Configuration is valid!")
    else:
        print("✗ Configuration issues found:")
        for err in errors:
            print(f"  - {err}")


class Config:
    @property
    def db_path(self) -> str:
        return get_config("DB_PATH", "pipeline.db")

    @property
    def smtp_user(self) -> str:
        return get_smtp_user()

    @property
    def smtp_password(self) -> str:
        return get_smtp_password()

    @property
    def sender_name(self) -> str:
        return get_sender_name()

    @property
    def sender_email(self) -> str:
        return get_smtp_user()

    @property
    def reply_to(self) -> str:
        return get_reply_to()

    @property
    def imap_server(self) -> str:
        return get_imap_server()

    @property
    def imap_port(self) -> int:
        return get_imap_port()

    @property
    def smtp_host(self) -> str:
        return get_smtp_server()

    @property
    def smtp_port(self) -> int:
        return get_smtp_port()

    @property
    def daily_send_limit(self) -> int:
        return get_daily_send_limit()

    @property
    def cooldown_seconds(self) -> int:
        return get_cooldown_minutes()  # Cooldown minutes getter actually returns seconds

    @property
    def followup_days(self) -> int:
        return get_config("FOLLOWUP_DAYS", "3", int)

    @property
    def max_followups(self) -> int:
        return get_config("MAX_FOLLOWUPS", "3", int)

    @property
    def email_template(self) -> str:
        try:
            import json
            templates_file = Path("templates.json")
            if templates_file.exists():
                data = json.loads(templates_file.read_text())
                for t in data:
                    if t.get("active"):
                        return t.get("body", "")
        except Exception:
            pass
        return get_config("EMAIL_TEMPLATE", "Hi {contact_name},\n\nI came across {company_name}...")

    @property
    def llm_provider(self) -> str:
        return get_llm_provider()

    @property
    def openai_api_key(self) -> str:
        return get_openai_api_key()

    @property
    def anthropic_api_key(self) -> str:
        return get_anthropic_api_key()

    @property
    def groq_api_key(self) -> str:
        return get_groq_api_key()

    @property
    def deepseek_api_key(self) -> str:
        return get_deepseek_api_key()

    @property
    def google_api_key(self) -> str:
        return get_google_api_key()

    @property
    def custom_llm_api_key(self) -> str:
        return get_custom_api_key()

    @property
    def custom_llm_base_url(self) -> str:
        return get_custom_base_url()

    @property
    def custom_llm_model(self) -> str:
        return get_custom_model()

    @property
    def ollama_url(self) -> str:
        return get_ollama_url()

    @property
    def ollama_model(self) -> str:
        return get_ollama_model()

    @property
    def google_places_api_key(self) -> str:
        return get_google_places_api_key()

    def is_llm_available(self) -> bool:
        provider = self.llm_provider
        if provider == 'ollama':
            return True
        elif provider == 'openai' and self.openai_api_key:
            return True
        elif provider == 'anthropic' and self.anthropic_api_key:
            return True
        elif provider == 'google' and self.google_api_key:
            return True
        elif provider == 'groq' and self.groq_api_key:
            return True
        elif provider == 'deepseek' and self.deepseek_api_key:
            return True
        elif provider == 'custom' and self.custom_llm_api_key:
            return True
        return False


config = Config()
