from flask import Flask, render_template_string, request, jsonify
import sqlite3
import os
import csv
import io
from datetime import datetime
from database import DB_NAME, init_db
import sys
from pathlib import Path

# Run DB migration check on startup
try:
    init_db()
except Exception as e:
    print(f"[ProMailer] DB migration error: {e}")

def resource_path(relative):
    base = getattr(sys, '_MEIPASS', Path(__file__).parent)
    return str(Path(base) / relative)

app = Flask(__name__)
app.template_folder = resource_path('templates')
app.static_folder = resource_path('static')

# Lead Finder Thread State
lead_finder_thread = None
lead_finder_logs = []
lead_finder_active = False
lead_finder_results = {}

# Premium glassmorphic styling, Outfit & Fira Code typography, with rich modals and dynamic Javascript search, sorting, and pagination
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ProMailer — Sovereign Outreach Console</title>
    
    <!-- Modern Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fira+Code:wght@400;500;700&family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --bg-color: #080a0c;
            --surface-color: rgba(15, 20, 28, 0.85);
            --surface-raised: rgba(28, 38, 54, 0.6);
            --border-color: #1c2636;
            --border-glow: rgba(0, 242, 254, 0.15);
            --text-primary: #e6edf3;
            --text-secondary: #8b949e;
            --accent-blue: #58a6ff;
            --accent-cyan: #00f2fe;
            --accent-cyan-glow: rgba(0, 242, 254, 0.4);
            --status-success: #30a14e;
            --status-warning: #d29922;
            --status-danger: #ff5f56;
            --status-pending: #d29922;
            --status-sent: #388bfd;
            --status-replied: #30a14e;
            --status-followed: #bc8cff;
            --status-generated: #565656;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        html, body {
            background-color: var(--bg-color);
            background-image: 
                radial-gradient(var(--border-color) 1px, transparent 0),
                radial-gradient(var(--border-color) 1px, transparent 0);
            background-size: 40px 40px;
            background-position: 0 0, 20px 20px;
            color: var(--text-primary);
            font-family: 'Outfit', sans-serif;
            -webkit-font-smoothing: antialiased;
            min-height: 100vh;
            padding: 40px 20px;
        }

        .monospace {
            font-family: 'Fira Code', 'Courier New', Courier, monospace;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: var(--surface-color);
            backdrop-filter: blur(16px);
            border: 1px solid var(--border-color);
            padding: 35px;
            border-radius: 16px;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.6);
        }

        /* ── Header ── */
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 25px;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 20px;
        }

        h1 {
            color: var(--text-primary);
            font-size: 28px;
            margin: 0;
            font-weight: 800;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        h1 span {
            color: var(--accent-cyan);
            text-shadow: 0 0 12px var(--accent-cyan-glow);
        }

        .tagline {
            font-size: 13px;
            color: var(--text-secondary);
            margin-top: 4px;
        }

        /* ── Action Buttons Header ── */
        .header-actions {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .btn {
            padding: 10px 18px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            font-family: inherit;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s;
            border: 1px solid var(--border-color);
            background: transparent;
            color: var(--text-primary);
        }

        .btn:hover {
            background: rgba(255, 255, 255, 0.03);
            border-color: var(--text-primary);
        }

        .btn-primary {
            background: var(--accent-cyan);
            border-color: var(--accent-cyan);
            color: var(--bg-color);
            box-shadow: 0 4px 15px rgba(0, 242, 254, 0.15);
        }

        .btn-primary:hover {
            background: #00d6e0;
            border-color: #00d6e0;
            box-shadow: 0 4px 20px var(--accent-cyan-glow);
            transform: translateY(-1px);
        }

        /* ── Play / Pause Campaign Switch ── */
        .campaign-switch {
            display: flex;
            align-items: center;
            background: rgba(28, 38, 54, 0.4);
            border: 1px solid var(--border-color);
            padding: 6px 14px;
            border-radius: 30px;
            gap: 10px;
        }

        .switch-indicator {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            display: inline-block;
        }

        .switch-indicator.running {
            background: var(--status-success);
            box-shadow: 0 0 10px var(--status-success);
            animation: pulse 2s infinite;
        }

        .switch-indicator.paused {
            background: var(--status-warning);
            box-shadow: 0 0 8px var(--status-warning);
        }

        .campaign-state-text {
            font-family: 'Fira Code', monospace;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-weight: 700;
        }

        .btn-toggle-state {
            background: transparent;
            border: none;
            cursor: pointer;
            color: var(--accent-cyan);
            font-size: 12px;
            font-weight: 700;
            font-family: inherit;
            padding: 2px 6px;
            display: flex;
            align-items: center;
            gap: 4px;
            text-decoration: underline;
        }

        /* ── Stats Bar ── */
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 20px;
            margin-bottom: 35px;
        }

        .stat-card {
            background: var(--surface-raised);
            border: 1px solid var(--border-color);
            padding: 20px;
            border-radius: 10px;
            position: relative;
            overflow: hidden;
            transition: transform 0.2s, border-color 0.2s, box-shadow 0.2s;
            cursor: pointer;
        }

        .stat-card:hover {
            transform: translateY(-2px);
            border-color: var(--accent-blue);
            box-shadow: 0 5px 15px rgba(88, 166, 255, 0.08);
        }

        .stat-card::after {
            content: '';
            position: absolute;
            top: 0; left: 0; width: 4px; height: 100%;
            background: var(--accent-blue);
        }
        
        .stat-card.total::after { background: var(--accent-cyan); }
        .stat-card.sent::after { background: var(--status-sent); }
        .stat-card.replied::after { background: var(--status-replied); }
        .stat-card.pending::after { background: var(--status-pending); }
        .stat-card.rate::after { background: var(--status-followed); }
        .stat-card.failed::after { background: var(--status-danger); }

        .stat-card h3 {
            margin: 0;
            font-size: 11px;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .stat-card p {
            font-size: 30px;
            font-weight: 800;
            margin: 10px 0 0;
            color: var(--text-primary);
        }

        /* ── Filters and Controls Bar ── */
        .controls-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            flex-wrap: wrap;
            gap: 16px;
        }

        .tabs {
            display: flex;
            background: rgba(28, 38, 54, 0.3);
            border: 1px solid var(--border-color);
            padding: 4px;
            border-radius: 8px;
            gap: 4px;
        }

        .tab-btn {
            background: transparent;
            border: none;
            color: var(--text-secondary);
            padding: 8px 16px;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            font-family: inherit;
            transition: all 0.15s;
        }

        .tab-btn:hover {
            color: var(--text-primary);
        }

        .tab-btn.active {
            background: var(--surface-raised);
            color: var(--accent-cyan);
            border: 1px solid var(--border-color);
        }

        .search-box {
            position: relative;
            max-width: 320px;
            width: 100%;
        }

        .search-input {
            width: 100%;
            background: rgba(15, 20, 28, 0.85);
            border: 1px solid var(--border-color);
            padding: 10px 16px;
            border-radius: 8px;
            color: var(--text-primary);
            font-size: 13px;
            outline: none;
            transition: border-color 0.2s, box-shadow 0.2s;
            font-family: inherit;
        }

        .search-input:focus {
            border-color: var(--accent-cyan);
            box-shadow: 0 0 10px var(--border-glow);
        }

        /* ── Table Layout ── */
        .table-container {
            width: 100%;
            overflow-x: auto;
            border: 1px solid var(--border-color);
            border-radius: 10px;
            background: rgba(10, 14, 20, 0.5);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            text-align: left;
            padding: 14px 18px;
            border-bottom: 1px solid var(--border-color);
            font-size: 13.5px;
        }

        th {
            background: rgba(28, 38, 54, 0.4);
            color: var(--text-secondary);
            font-weight: 600;
            text-transform: uppercase;
            font-size: 11px;
            letter-spacing: 0.5px;
            cursor: pointer;
            user-select: none;
        }

        th:hover {
            color: var(--text-primary);
        }

        tr:last-child td {
            border-bottom: none;
        }

        tr:hover td {
            background: rgba(88, 166, 255, 0.02);
        }

        /* Status Badges */
        .status {
            padding: 4px 10px;
            border-radius: 4px;
            font-size: 10.5px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            display: inline-block;
            font-family: 'Fira Code', monospace;
        }

        .status-pending { background: rgba(210, 153, 34, 0.12); color: var(--status-pending); border: 1px solid rgba(210, 153, 34, 0.25); }
        .status-sent { background: rgba(56, 139, 253, 0.12); color: var(--status-sent); border: 1px solid rgba(56, 139, 253, 0.25); }
        .status-followed_up { background: rgba(188, 140, 255, 0.12); color: var(--status-followed); border: 1px solid rgba(188, 140, 255, 0.25); }
        .status-replied { background: rgba(48, 161, 78, 0.12); color: var(--status-replied); border: 1px solid rgba(48, 161, 78, 0.25); }
        .status-generated { background: rgba(86, 86, 86, 0.12); color: var(--status-generated); border: 1px solid rgba(86, 86, 86, 0.25); }
        .status-failed { background: rgba(255, 95, 86, 0.12); color: var(--status-danger); border: 1px solid rgba(255, 95, 86, 0.25); }

        .website-link {
            color: var(--accent-blue);
            text-decoration: none;
        }

        .website-link:hover {
            text-decoration: underline;
        }

        .actions-cell {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .btn-action {
            background: transparent;
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 11px;
            font-weight: 500;
            font-family: inherit;
            transition: all 0.2s;
        }

        .btn-action:hover {
            border-color: var(--accent-cyan);
            color: var(--accent-cyan);
            box-shadow: 0 0 8px rgba(0, 242, 254, 0.15);
        }

        .btn-action:disabled {
            border-color: var(--border-color) !important;
            color: var(--text-secondary) !important;
            cursor: not-allowed !important;
            opacity: 0.5;
            box-shadow: none !important;
        }

        .btn-replied {
            border-color: rgba(48, 161, 78, 0.3);
            color: var(--status-replied);
        }

        .btn-replied:hover {
            background: rgba(48, 161, 78, 0.1);
            border-color: var(--status-replied);
            color: #ffffff;
            box-shadow: 0 0 8px rgba(48, 161, 78, 0.3);
        }

        .btn-delete {
            border-color: rgba(255, 95, 86, 0.3);
            color: var(--status-danger);
        }

        .btn-delete:hover {
            background: rgba(255, 95, 86, 0.1);
            border-color: var(--status-danger);
            color: #ffffff;
            box-shadow: 0 0 8px rgba(255, 95, 86, 0.3);
        }

        /* ── Pagination ── */
        .pagination-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 20px;
            font-size: 13px;
            color: var(--text-secondary);
        }

        .pagination-buttons {
            display: flex;
            gap: 8px;
        }

        /* ── dialog Native Modals ── */
        dialog {
            background: #080a0c;
            border: 1px solid var(--border-color);
            border-radius: 12px;
            box-shadow: 0 0 30px rgba(0, 242, 254, 0.1), 0 20px 50px rgba(0, 0, 0, 0.8);
            width: calc(100% - 32px);
            max-width: 540px;
            padding: 0;
            margin: auto;
            color: var(--text-primary);
            font-family: inherit;
            outline: none;
            overflow: hidden;
            backdrop-filter: blur(16px);
        }

        dialog::backdrop {
            background-color: rgba(4, 6, 8, 0.85);
            backdrop-filter: blur(6px);
        }

        .modal-header {
            background: rgba(28, 38, 54, 0.4);
            border-bottom: 1px solid var(--border-color);
            height: 46px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
        }

        .modal-title {
            font-weight: 700;
            font-size: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .close-modal-btn {
            background: transparent;
            border: none;
            cursor: pointer;
            color: var(--text-secondary);
            padding: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .close-modal-btn:hover {
            color: var(--text-primary);
        }

        .modal-body {
            padding: 24px;
        }

        .form-group {
            margin-bottom: 18px;
        }

        .form-label {
            display: block;
            font-family: 'Fira Code', monospace;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--accent-blue);
            margin-bottom: 6px;
        }

        .form-input, .form-textarea {
            width: 100%;
            background: rgba(15, 20, 28, 0.85);
            border: 1px solid var(--border-color);
            padding: 11px 14px;
            border-radius: 6px;
            color: var(--text-primary);
            font-size: 13.5px;
            outline: none;
            transition: all 0.2s;
            font-family: inherit;
        }

        .form-input:focus, .form-textarea:focus {
            border-color: var(--accent-cyan);
            box-shadow: 0 0 10px var(--border-glow);
        }

        /* ── Dynamic Toast Notifications ── */
        .toast-container {
            position: fixed;
            bottom: 24px;
            right: 24px;
            z-index: 1000;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .toast {
            background: rgba(15, 20, 28, 0.95);
            border: 1px solid var(--border-color);
            padding: 14px 20px;
            border-radius: 8px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.5);
            font-size: 13px;
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--text-primary);
            min-width: 280px;
            animation: slideIn 0.3s cubic-bezier(0.16, 1, 0.3, 1);
            border-left: 4px solid var(--accent-blue);
            backdrop-filter: blur(10px);
        }

        .toast.success { border-left-color: var(--status-success); }
        .toast.error { border-left-color: var(--status-danger); }
        .toast.warning { border-left-color: var(--status-warning); }

        /* ── Animations ── */
        @keyframes pulse {
            0% { transform: scale(1); opacity: 0.8; }
            50% { transform: scale(1.2); opacity: 1; }
            100% { transform: scale(1); opacity: 0.8; }
        }

        @keyframes slideIn {
            from { transform: translateX(100%) translateY(0); opacity: 0; }
            to { transform: translateX(0) translateY(0); opacity: 1; }
        }

        .footer {
            margin-top: 40px;
            text-align: center;
            font-size: 11.5px;
            color: var(--text-secondary);
        }
        
        .footer a {
            color: var(--accent-cyan);
            text-decoration: none;
        }
        
        .footer a:hover {
            text-decoration: underline;
        }

        /* Pacing Label Style */
        .pacing-badge {
            background: rgba(88, 166, 255, 0.08);
            border: 1px dashed rgba(88, 166, 255, 0.25);
            color: var(--text-secondary);
            padding: 10px 16px;
            border-radius: 8px;
            font-size: 12.5px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
            line-height: 1.4;
        }
        .pacing-badge strong {
            color: var(--accent-blue);
        }

        /* AI Coach Drawer Style */
        .ai-coach-drawer {
            position: fixed;
            top: 0;
            right: -450px;
            width: 450px;
            height: 100vh;
            background: #080a0c;
            border-left: 1px solid var(--border-color);
            box-shadow: -10px 0 40px rgba(0, 0, 0, 0.7);
            z-index: 1000;
            transition: right 0.3s cubic-bezier(0.16, 1, 0.3, 1);
            display: flex;
            flex-direction: column;
            color: var(--text-primary);
        }
        .ai-coach-drawer.open {
            right: 0;
        }
        .drawer-header {
            background: rgba(28, 38, 54, 0.4);
            border-bottom: 1px solid var(--border-color);
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
        }
        .drawer-body {
            padding: 20px;
            flex: 1;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        .drawer-footer {
            padding: 20px;
            border-top: 1px solid var(--border-color);
            background: rgba(28, 38, 54, 0.2);
            display: flex;
            gap: 10px;
        }

        /* Settings Subsections */
        .settings-section-title {
            font-family: 'Fira Code', monospace;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: var(--accent-cyan);
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 6px;
            margin: 25px 0 15px 0;
            font-weight: 700;
        }
        .settings-section-title:first-of-type {
            margin-top: 0;
        }

        /* Tabs inside Settings Modal */
        .modal-tabs {
            display: flex;
            gap: 8px;
            margin-bottom: 15px;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 8px;
            flex-wrap: wrap;
        }
        .modal-tab-btn {
            background: transparent;
            border: 1px solid var(--border-color);
            color: var(--text-secondary);
            padding: 6px 12px;
            cursor: pointer;
            font-size: 12px;
            font-weight: 600;
            border-radius: 4px;
            transition: all 0.15s;
            font-family: inherit;
        }
        .modal-tab-btn:hover {
            color: var(--text-primary);
            border-color: var(--text-primary);
        }
        .modal-tab-btn.active {
            background: var(--surface-raised);
            color: var(--accent-cyan);
            border-color: var(--accent-cyan);
        }

        /* Chat bubbles */
        .chat-bubble {
            max-width: 85%;
            padding: 12px 16px;
            border-radius: 8px;
            font-size: 13px;
            line-height: 1.5;
        }
        .chat-bubble.user {
            background: rgba(88, 166, 255, 0.15);
            border: 1px solid rgba(88, 166, 255, 0.25);
            align-self: flex-end;
        }
        .chat-bubble.ai {
            background: rgba(0, 242, 254, 0.08);
            border: 1px solid rgba(0, 242, 254, 0.15);
            align-self: flex-start;
        }

        /* Daily Brief Card Style */
        .brief-card {
            background: rgba(28, 38, 54, 0.4);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 16px;
            display: flex;
            flex-direction: column;
            gap: 8px;
            transition: border-color 0.2s;
        }
        .brief-card:hover {
            border-color: var(--accent-blue);
        }
        .brief-card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Toast Container for Actions -->
        <div class="toast-container" id="toast-container"></div>

        <!-- Dynamic Update Alert Banner -->
        <div id="update-alert-banner" style="display: none; background: rgba(210, 153, 34, 0.12); border: 1px solid var(--status-warning); padding: 14px 20px; border-radius: 8px; margin-bottom: 25px; align-items: center; justify-content: space-between; gap: 15px; flex-wrap: wrap;">
            <div style="display: flex; align-items: center; gap: 12px;">
                <span style="font-size: 20px;">🎁</span>
                <span style="font-size: 13.5px;">A newer version of ProMailer (<strong id="latest-version-num">1.1.0</strong>) is available. Download the updated package to get the latest features and optimizations.</span>
            </div>
            <a href="https://promailer.ca" target="_blank" class="btn btn-primary" style="border-color: var(--status-warning); background: var(--status-warning); color: #000; padding: 6px 14px; font-size: 12px; text-decoration: none; border-radius: 6px; font-weight: 700;">Update Now</a>
        </div>

        <header>
            <div>
                <h1>⚡ ProMailer <span>Sovereign Outreach</span></h1>
                <div class="tagline">Local-first, air-gapped cold email compiler & engine</div>
            </div>
            
            <div class="header-actions">
                <!-- Play / Pause Campaign state -->
                <div class="campaign-switch">
                    <span class="switch-indicator {% if state == 'running' %}running{% else %}paused{% endif %}" id="campaign-indicator"></span>
                    <span class="campaign-state-text" id="campaign-state-text">{{ state }}</span>
                    <button class="btn-toggle-state" onclick="toggleCampaignState()">
                        [Toggle]
                    </button>
                </div>

                <button class="btn" onclick="openModal('lead-finder-modal')">
                    🔍 Find Leads
                </button>
                <button class="btn" onclick="openModal('csv-modal')">
                    📤 Load CSV
                </button>
                <button class="btn" onclick="openSettingsModal()">
                    ⚙️ Settings
                </button>
                <button class="btn" onclick="toggleAICoach()">
                    🧠 AI Coach
                </button>
                <button class="btn btn-primary" onclick="openModal('add-modal')">
                    ➕ Add Prospect
                </button>
            </div>
        </header>

        <!-- Pacing Guardrail Label -->
        <div class="pacing-badge">
            <span>🛡️</span>
            <span>ProMailer sends a maximum of <strong id="pacing-send-limit">20</strong> emails per day with a <strong id="pacing-cooldown">4</strong>-minute gap. This is intentional — you are starting conversations, not blasting.</span>
        </div>
        
        <!-- Stats Cards Grid -->
        <div class="stats">
            <div class="stat-card total" onclick="filterByStatus('all')">
                <h3>Total Prospects</h3>
                <p id="stat-total">{{ stats.total }}</p>
            </div>
            <div class="stat-card pending" onclick="filterByStatus('pending')">
                <h3>Pipeline Queue</h3>
                <p id="stat-pending">{{ stats.pending }}</p>
            </div>
            <div class="stat-card sent" onclick="filterByStatus('sent')">
                <h3>Outbox Sent</h3>
                <p id="stat-sent">{{ stats.sent }}</p>
            </div>
            <div class="stat-card replied" onclick="filterByStatus('replied')">
                <h3>Replies</h3>
                <p id="stat-replied">{{ stats.replied }}</p>
            </div>
            <div class="stat-card rate">
                <h3>Reply Rate</h3>
                <p id="stat-rate">{{ stats.reply_rate }}%</p>
            </div>
            <div class="stat-card failed" onclick="filterByStatus('failed')">
                <h3>Failed</h3>
                <p id="stat-failed">{{ stats.failed }}</p>
            </div>
        </div>

        <!-- Daily Brief Section -->
        <div id="daily-brief-container" style="background: rgba(15, 20, 28, 0.4); border: 1px solid var(--border-color); border-radius: 12px; padding: 25px; margin-bottom: 30px; display: none;">
            <div style="border-bottom: 1px solid var(--border-color); padding-bottom: 12px; margin-bottom: 18px;">
                <h2 style="font-size: 16px; font-weight: 700; display: flex; align-items: center; gap: 8px;">📬 Daily Brief &amp; Replies</h2>
            </div>
            <div id="daily-brief-list" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 15px;">
                <!-- Loaded dynamically -->
            </div>
        </div>

        <!-- Filters Bar -->
        <div class="controls-bar">
            <div class="tabs">
                <button class="tab-btn active" id="tab-all" onclick="filterByStatus('all')">All</button>
                <button class="tab-btn" id="tab-pending" onclick="filterByStatus('pending')">Pending</button>
                <button class="tab-btn" id="tab-sent" onclick="filterByStatus('sent')">Sent</button>
                <button class="tab-btn" id="tab-replied" onclick="filterByStatus('replied')">Replied</button>
                <button class="tab-btn" id="tab-followed_up" onclick="filterByStatus('followed_up')">Followed Up</button>
                <button class="tab-btn" id="tab-generated" onclick="filterByStatus('generated')">Generated</button>
            </div>
            
            <div class="search-box">
                <input type="text" id="search-input" class="search-input" placeholder="Search company, name, email..." oninput="handleSearch()">
            </div>
        </div>

        <!-- Leads Table container -->
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th onclick="sortTable('company_name')">Business / Contact Name</th>
                        <th onclick="sortTable('contact_email')">Email Address</th>
                        <th onclick="sortTable('website')">Website</th>
                        <th onclick="sortTable('status')">Outreach Status</th>
                        <th onclick="sortTable('sent_at')">Last Sent / Active</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="leads-tbody">
                    <!-- Loaded dynamically via JavaScript -->
                </tbody>
            </table>
        </div>

        <!-- Pagination Controls -->
        <div class="pagination-container">
            <div id="pagination-info">Showing 0-0 of 0 prospects</div>
            <div class="pagination-buttons">
                <button class="btn btn-action" id="btn-prev" onclick="prevPage()">&lt; Prev</button>
                <button class="btn btn-action" id="btn-next" onclick="nextPage()">Next &gt;</button>
            </div>
        </div>
        
        <div class="footer">
            Sovereign pipeline powered by <a href="https://justmemedia.ca" target="_blank">Just Me Media</a> — © 2026 ProMailer. All Rights Reserved.
        </div>
    </div>

    <!-- ── Add Lead Modal ── -->
    <dialog id="add-modal">
        <div class="modal-header">
            <div class="modal-title">➕ Add Single Prospect</div>
            <button class="close-modal-btn" onclick="closeModal('add-modal')">✕</button>
        </div>
        <div class="modal-body">
            <form id="add-lead-form" onsubmit="submitAddLead(event)">
                <div class="form-group">
                    <label class="form-label" for="add-company">Company Name *</label>
                    <input type="text" id="add-company" class="form-input" placeholder="Acme Corp" required>
                </div>
                <div class="form-group">
                    <label class="form-label" for="add-name">Contact Name</label>
                    <input type="text" id="add-name" class="form-input" placeholder="John Doe">
                </div>
                <div class="form-group">
                    <label class="form-label" for="add-email">Contact Email *</label>
                    <input type="email" id="add-email" class="form-input" placeholder="john@acmecorp.com" required>
                </div>
                <div class="form-group">
                    <label class="form-label" for="add-website">Website (URL)</label>
                    <input type="url" id="add-website" class="form-input" placeholder="https://acmecorp.com">
                </div>
                <div class="form-group">
                    <label class="form-label" for="add-areas">Specialties / Practice Areas</label>
                    <input type="text" id="add-areas" class="form-input" placeholder="SaaS, B2B Software">
                </div>
                <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 24px;">
                    <button type="button" class="btn" onclick="closeModal('add-modal')">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Lead</button>
                </div>
            </form>
        </div>
    </dialog>

    <!-- ── Import CSV Modal ── -->
    <dialog id="csv-modal">
        <div class="modal-header">
            <div class="modal-title">📤 Upload CSV Leads File</div>
            <button class="close-modal-btn" onclick="closeModal('csv-modal')">✕</button>
        </div>
        <div class="modal-body">
            <form id="csv-form" onsubmit="submitCSVImport(event)">
                <div class="form-group">
                    <label class="form-label" for="csv-file">Select CSV File</label>
                    <input type="file" id="csv-file" class="form-input" accept=".csv" required style="padding: 8px;">
                </div>
                <div style="font-size: 12px; color: var(--text-secondary); line-height: 1.5; margin-bottom: 20px;">
                    <p style="font-weight: 600; margin-bottom: 6px; color: var(--text-primary);">💡 Auto-Headers Mapped:</p>
                    <p>• Company name columns (e.g. <code>company</code>, <code>business</code>)</p>
                    <p>• Email address columns (e.g. <code>email</code>, <code>contact_email</code>)</p>
                    <p>• Website URL, Contact Name, Practice/specialty sectors.</p>
                </div>
                <div style="display: flex; justify-content: flex-end; gap: 10px;">
                    <button type="button" class="btn" onclick="closeModal('csv-modal')">Cancel</button>
                    <button type="submit" class="btn btn-primary" id="csv-submit-btn">Upload &amp; Parse</button>
                </div>
            </form>
        </div>
    </dialog>

    <!-- ── In-App Lead Finder Modal ── -->
    <dialog id="lead-finder-modal" style="max-width: 600px;">
        <div class="modal-header">
            <div class="modal-title">🔍 AI Lead Finder &amp; Scraper</div>
            <button class="close-modal-btn" onclick="closeModal('lead-finder-modal')">✕</button>
        </div>
        <div class="modal-body">
            <form id="lead-finder-form" onsubmit="submitLeadFinder(event)">
                <div class="form-group">
                    <label class="form-label" for="finder-query">Search Query</label>
                    <input type="text" id="finder-query" class="form-input" placeholder="e.g. Criminal Defense lawyers in Ottawa Ontario" required style="padding: 10px;">
                </div>
                <div class="form-group" style="margin-top: 15px;">
                    <label class="form-label" for="finder-limit">Target Lead Count</label>
                    <select id="finder-limit" class="form-input" style="padding: 10px; background: var(--surface-raised); border: 1px solid var(--border-color); color: var(--text-primary); cursor: pointer;">
                        <option value="10">10 Leads (Quick Scan)</option>
                        <option value="20" selected>20 Leads (Recommended)</option>
                        <option value="40">40 Leads (Standard Run)</option>
                        <option value="60">60 Leads (Deep Enrichment)</option>
                    </select>
                </div>
                <div style="font-size: 11.5px; color: var(--text-secondary); line-height: 1.5; margin-bottom: 20px; background: rgba(28,38,54,0.3); padding: 12px; border-radius: 6px; border: 1px solid var(--border-color);">
                    <p style="font-weight: 600; margin-bottom: 4px; color: var(--text-primary);">💡 Auto-Discovery Engine:</p>
                    <p>Uses active Google Places details OR free fallback DuckDuckGo search to extract business websites, scrape contact emails directly from pages, and preview them before importing.</p>
                </div>
                <div style="display: flex; justify-content: flex-end; gap: 10px; margin-bottom: 20px;">
                    <button type="button" class="btn" onclick="closeModal('lead-finder-modal')">Cancel</button>
                    <button type="submit" class="btn btn-primary" id="finder-submit-btn">Find &amp; Enrich Leads  →</button>
                </div>
            </form>
            
            <!-- Terminal Output Console -->
            <div id="finder-console-container" style="display: none; margin-top: 15px;">
                <div class="form-label">🖥️ Lead Finder Console Log</div>
                <div id="finder-console" style="background: #05070a; border: 1px solid #1c2636; border-radius: 6px; padding: 15px; font-family: 'Fira Code', 'Courier New', monospace; font-size: 11.5px; line-height: 1.6; height: 180px; overflow-y: auto; color: var(--accent-cyan); text-shadow: 0 0 4px rgba(0,242,254,0.15);">
                    <div style="color: var(--text-secondary);">Waiting to start lead generation...</div>
                </div>
            </div>

            <!-- Results Preview Table -->
            <div id="finder-results-container" style="display: none; margin-top: 20px; border-top: 1px solid var(--border-color); padding-top: 15px;">
                <div class="form-label" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                    <span>📋 Discovered Leads</span>
                    <button type="button" class="btn btn-primary" id="btn-import-all" onclick="importAllLeads()" style="font-size: 11px; padding: 5px 10px; height: auto;">Load All to Pipeline</button>
                </div>
                <div style="max-height: 250px; overflow-y: auto; border: 1px solid var(--border-color); border-radius: 6px;">
                    <table style="width: 100%; font-size: 12px; border-collapse: collapse;">
                        <thead style="position: sticky; top: 0; background: #080a0c; z-index: 10;">
                            <tr>
                                <th style="padding: 10px; font-size: 10px; background: #0f141c; text-align: left;">Business Name</th>
                                <th style="padding: 10px; font-size: 10px; background: #0f141c; text-align: left;">Email Address</th>
                                <th style="padding: 10px; font-size: 10px; background: #0f141c; text-align: right;">Action</th>
                            </tr>
                        </thead>
                        <tbody id="finder-results-tbody">
                            <!-- Filled dynamically -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </dialog>

    <!-- ── Inspect Brief Modal ── -->
    <dialog id="brief-modal" style="max-width: 650px;">
        <div class="modal-header">
            <div class="modal-title">📧 Compiled Email Outreach Brief</div>
            <button class="close-modal-btn" onclick="closeModal('brief-modal')">✕</button>
        </div>
        <div class="modal-body" style="padding-top: 16px;">
            <div style="margin-bottom: 12px; font-size: 13px;">
                <span class="form-label" style="display: inline-block; margin-bottom: 0;">To:</span>
                <span id="brief-recipient" style="font-weight: 600;">john@acme.com</span>
            </div>
            <div class="form-group">
                <textarea id="brief-content" class="form-textarea monospace" rows="14" readonly style="resize: vertical; font-size: 12.5px; line-height: 1.5; background: #06080b; color: #d1d5db;"></textarea>
            </div>
            <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 20px;">
                <span style="font-size: 11px; color: var(--text-secondary);" id="brief-sent-time">Waiting to be sent...</span>
                <div style="display: flex; gap: 10px;">
                    <button class="btn" onclick="copyBriefText()">📋 Copy Text</button>
                    <button class="btn btn-primary" onclick="closeModal('brief-modal')">Close</button>
                </div>
            </div>
        </div>
    </dialog>

    <!-- ── Settings Modal ── -->
    <dialog id="settings-modal" style="max-width: 650px;">
        <div class="modal-header">
            <div class="modal-title">⚙️ Campaign &amp; AI Settings</div>
            <button class="close-modal-btn" onclick="closeModal('settings-modal')">✕</button>
        </div>
        <div class="modal-body" style="padding-top: 16px; max-height: 80vh; overflow-y: auto;">
            <form id="settings-form" onsubmit="submitSaveSettings(event)">
                
                <!-- ── CAMPAIGN CONTROLS ── -->
                <div class="settings-section-title">── Campaign Controls ──</div>
                <div class="form-group">
                    <label class="form-label" for="settings-send-limit">Daily Send Limit: <span id="label-send-limit" style="color: #fff; font-weight: bold;">20</span> emails/day</label>
                    <input type="range" id="settings-send-limit" min="1" max="100" value="20" class="form-input" style="padding: 0; height: 6px; background: var(--border-color); cursor: pointer;" oninput="document.getElementById('label-send-limit').textContent = this.value">
                </div>
                <div class="form-group">
                    <label class="form-label" for="settings-cooldown">Cooldown Delay: <span id="label-cooldown" style="color: #fff; font-weight: bold;">4</span> minutes</label>
                    <input type="range" id="settings-cooldown" min="1" max="30" value="4" class="form-input" style="padding: 0; height: 6px; background: var(--border-color); cursor: pointer;" oninput="document.getElementById('label-cooldown').textContent = this.value">
                </div>

                <!-- ── AI PROVIDER ── -->
                <div class="settings-section-title">── AI Model Provider ──</div>
                <div class="form-group">
                    <label class="form-label" for="settings-llm-provider">Provider</label>
                    <select id="settings-llm-provider" class="form-input" style="padding: 10px; background: var(--surface-raised); border: 1px solid var(--border-color); color: var(--text-primary); cursor: pointer;" onchange="toggleProviderFields()">
                        <option value="ollama">Ollama (Local sovereign, 100% private &amp; free)</option>
                        <option value="openai">OpenAI (gpt-4o-mini, high accuracy)</option>
                        <option value="anthropic">Anthropic Claude (claude-3-5-haiku)</option>
                        <option value="google">Google Gemini (gemini-1.5-flash, free tier available)</option>
                        <option value="groq">Groq Llama (Fastest, free tier available)</option>
                        <option value="deepseek">DeepSeek Chat (Extremely cost efficient)</option>
                        <option value="custom">Custom (OpenAI-compatible endpoints, Ollama, etc.)</option>
                    </select>
                </div>
                
                <!-- API Key fields (dynamically shown) -->
                <div class="form-group" id="field-api-key" style="display: none;">
                    <label class="form-label" for="settings-api-key">API Key</label>
                    <div style="display: flex; gap: 10px;">
                        <input type="password" id="settings-api-key" class="form-input" placeholder="Paste your API key here">
                        <button type="button" class="btn" onclick="testAPIKey()" id="btn-test-key">Test Key</button>
                    </div>
                    <span id="test-key-status" style="font-size: 11px; margin-top: 4px; display: block;"></span>
                </div>

                <!-- Custom Fields (only for "custom" option) -->
                <div id="fields-custom-llm" style="display: none; background: rgba(28,38,54,0.3); padding: 15px; border-radius: 8px; border: 1px solid var(--border-color); margin-bottom: 18px;">
                    <div class="form-group">
                        <label class="form-label" for="settings-custom-name">Custom Provider Name</label>
                        <input type="text" id="settings-custom-name" class="form-input" placeholder="e.g. Together AI">
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="settings-custom-base-url">Base URL</label>
                        <input type="url" id="settings-custom-base-url" class="form-input" placeholder="e.g. https://api.together.xyz/v1">
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="settings-custom-model">Model Name</label>
                        <input type="text" id="settings-custom-model" class="form-input" placeholder="e.g. meta-llama/Llama-3-70b-chat-hf">
                    </div>
                </div>

                <!-- Ollama URL & Model fields -->
                <div id="fields-ollama" style="background: rgba(28,38,54,0.3); padding: 15px; border-radius: 8px; border: 1px solid var(--border-color); margin-bottom: 18px;">
                    <div class="form-group">
                        <label class="form-label" for="settings-ollama-url">Ollama Base URL</label>
                        <input type="url" id="settings-ollama-url" class="form-input" placeholder="Default: http://localhost:11434/api/generate">
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="settings-ollama-model">Ollama Model</label>
                        <input type="text" id="settings-ollama-model" class="form-input" placeholder="Default: llama3.2:3b">
                    </div>
                </div>

                <!-- Google Places Key -->
                <div class="form-group">
                    <label class="form-label" for="settings-google-places-key">Google Places API Key (Optional — enables Lead Finder)</label>
                    <input type="password" id="settings-google-places-key" class="form-input" placeholder="Paste Places API key here">
                </div>

                <!-- Key Acquisition instructions (collapsible) -->
                <details style="margin-bottom: 20px; background: rgba(28,38,54,0.2); border: 1px solid var(--border-color); padding: 10px; border-radius: 6px;">
                    <summary style="font-size: 12.5px; cursor: pointer; color: var(--accent-cyan); font-weight: 600;">📘 Get API Keys guide</summary>
                    <div style="font-size: 11.5px; line-height: 1.6; color: var(--text-secondary); margin-top: 10px; display: flex; flex-direction: column; gap: 8px;">
                        <div>🔓 <strong>Free Tiers:</strong></div>
                        <div>• <strong>Groq:</strong> Sign up at console.groq.com to get a fast free key.</div>
                        <div>• <strong>Google Gemini:</strong> Sign up at ai.google.dev to get a key with a generous free tier.</div>
                        <div>• <strong>DeepSeek:</strong> Extremely cheap platform.deepseek.com (~$0.14 per 1M tokens).</div>
                        <div>💰 <strong>Paid Cloud Engines:</strong></div>
                        <div>• <strong>OpenAI:</strong> Create a key at platform.openai.com/api-keys.</div>
                        <div>• <strong>Anthropic:</strong> Create a key at console.anthropic.com.</div>
                        <div>🔧 <strong>Custom:</strong> Works with Together AI, OpenRouter, Mistral, LocalAI or any OpenAI-compatible API.</div>
                    </div>
                </details>

                <!-- ── OUTREACH TEMPLATES ── -->
                <div class="settings-section-title">── Email Template Editor ──</div>
                
                <div class="modal-tabs" id="template-tabs-container" style="display: flex; gap: 10px; margin-bottom: 15px;">
                    <!-- Loaded dynamically via JavaScript -->
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="settings-template-name">Template Name</label>
                    <input type="text" id="settings-template-name" class="form-input" placeholder="e.g. Standard Outreach" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="settings-template-subject">Email Subject</label>
                    <input type="text" id="settings-template-subject" class="form-input" placeholder="Quick question regarding {company_name}" required>
                </div>

                <div class="form-group">
                    <label class="form-label" for="settings-template-body">Email Template Body</label>
                    <textarea id="settings-template-body" class="form-textarea monospace" rows="10" placeholder="Write your outreach email template here. Use placeholders: {contact_name}, {company_name}, {website}, {practice_areas}." required style="font-size: 12.5px; line-height: 1.5;"></textarea>
                </div>

                <div style="font-size: 11px; color: var(--text-secondary); margin-bottom: 20px;">
                    💡 Placeholders auto-injected: <code>{contact_name}</code>, <code>{company_name}</code>, <code>{website}</code>, <code>{practice_areas}</code>.
                </div>

                <div style="display: flex; justify-content: space-between; gap: 10px; margin-top: 24px;">
                    <div>
                        <button type="button" class="btn btn-delete" id="btn-delete-template" onclick="deleteCurrentTemplate()" style="display: none;">Remove Template</button>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="button" class="btn" onclick="closeModal('settings-modal')">Cancel</button>
                        <button type="submit" class="btn btn-primary">Save Settings</button>
                    </div>
                </div>
            </form>
        </div>
    </dialog>

    <!-- ── Inspect Reply Modal ── -->
    <dialog id="reply-modal" style="max-width: 600px;">
        <div class="modal-header">
            <div class="modal-title">📬 Prospect Reply Received</div>
            <button class="close-modal-btn" onclick="closeModal('reply-modal')">✕</button>
        </div>
        <div class="modal-body">
            <div style="margin-bottom: 12px; font-size: 13.5px;">
                <span class="form-label" style="display: inline-block; margin-bottom: 0;">From:</span>
                <span id="reply-sender-header" style="font-weight: 600;">john@company.com</span>
            </div>
            <div class="form-group">
                <textarea id="reply-body-content" class="form-textarea monospace" rows="12" readonly style="resize: vertical; font-size: 12.5px; line-height: 1.5; background: #06080b; color: #d1d5db;"></textarea>
            </div>
            <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 20px;">
                <span style="font-size: 11px; color: var(--text-secondary);" id="reply-received-time">Received time</span>
                <div style="display: flex; gap: 10px;">
                    <a href="" id="reply-mailto-btn" class="btn btn-primary" style="text-decoration: none;">✉️ Reply Directly</a>
                    <button class="btn" onclick="closeModal('reply-modal')">Close</button>
                </div>
            </div>
        </div>
    </dialog>

    <!-- ── AI Coach Drawer ── -->
    <div class="ai-coach-drawer" id="ai-coach-drawer">
        <div class="drawer-header">
            <div class="modal-title">🧠 ProMailer AI Coach</div>
            <button class="close-modal-btn" onclick="toggleAICoach()">✕</button>
        </div>
        <div class="drawer-body" id="ai-coach-chat-area">
            <div class="chat-bubble ai">
                Hi! I am your outreach coach. I automatically read your active email template and any recent replies received.<br><br>
                How can I help you refine your templates or draft a personalized follow-up?
            </div>
        </div>
        
        <!-- Quick prompts helper -->
        <div style="padding: 10px 20px; display: flex; flex-direction: column; gap: 6px;">
            <button class="btn btn-action" style="font-size: 11px; text-align: left; padding: 6px 10px; width: 100%; justify-content: flex-start;" onclick="sendCoachPreset('make my template sound less salesy')">
                ✍️ "Make active template sound less salesy"
            </button>
            <button class="btn btn-action" style="font-size: 11px; text-align: left; padding: 6px 10px; width: 100%; justify-content: flex-start;" onclick="sendCoachPreset('summarize my recent replies')">
                📬 "Summarize my recent replies"
            </button>
            <button class="btn btn-action" style="font-size: 11px; text-align: left; padding: 6px 10px; width: 100%; justify-content: flex-start;" onclick="sendCoachPreset('suggest follow-up ideas')">
                💡 "Suggest outreach follow-up ideas"
            </button>
        </div>

        <div class="drawer-footer">
            <input type="text" id="ai-coach-input" class="form-input" placeholder="Ask coach anything..." onkeydown="if(event.key==='Enter') sendCoachMessage()">
            <button class="btn btn-primary" onclick="sendCoachMessage()" id="btn-send-coach">Send</button>
        </div>
    </div>

    <!-- JS Logic -->
    <script>
        // Seeded directly from Flask Jinja context
        let leads = {{ leads_json | safe }};
        let currentFilter = 'all';
        let searchQuery = '';
        let sortColumn = 'created_at';
        let sortDirection = 'desc';
        let currentPage = 1;
        const rowsPerPage = 15;

        // Toast Helper
        function showToast(message, type = 'info') {
            const container = document.getElementById('toast-container');
            const toast = document.createElement('div');
            toast.className = `toast ${type}`;
            toast.innerHTML = `<span>💬</span> <div>${message}</div>`;
            container.appendChild(toast);
            
            setTimeout(() => {
                toast.style.opacity = '0';
                toast.style.transform = 'translateY(10px)';
                setTimeout(() => toast.remove(), 300);
            }, 3000);
        }

        // Modal Helpers
        function openModal(id) {
            document.getElementById(id).showModal();
        }

        function closeModal(id) {
            document.getElementById(id).close();
        }

        // In-App Lead Finder AJAX & Polling
        let leadFinderInterval = null;
        let lastLogLength = 0;

        async function submitLeadFinder(e) {
            e.preventDefault();
            const query = document.getElementById('finder-query').value.trim();
            const limit = parseInt(document.getElementById('finder-limit').value);
            const submitBtn = document.getElementById('finder-submit-btn');
            const consoleContainer = document.getElementById('finder-console-container');
            const consoleBox = document.getElementById('finder-console');

            if (!query) {
                showToast('Please enter a search query.', 'error');
                return;
            }

            // Reset UI
            submitBtn.disabled = true;
            submitBtn.textContent = '🔍 Working...';
            consoleContainer.style.display = 'block';
            document.getElementById('finder-results-container').style.display = 'none'; // Hide old results
            consoleBox.innerHTML = '<div style="color: var(--status-warning);">[System] Initializing lead generation background thread...</div>';
            lastLogLength = 0;

            try {
                const res = await fetch('/api/start_lead_finder', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ query: query, limit: limit })
                });

                if (res.ok) {
                    showToast('Lead finder successfully initiated!', 'success');
                    // Start polling
                    leadFinderInterval = setInterval(pollLeadFinderStatus, 1000);
                } else {
                    const data = await res.json();
                    showToast(data.message || 'Failed to start lead finder.', 'error');
                    submitBtn.disabled = false;
                    submitBtn.textContent = 'Find & Enrich Leads  →';
                }
            } catch (err) {
                showToast('Network error starting lead finder.', 'error');
                submitBtn.disabled = false;
                submitBtn.textContent = 'Find & Enrich Leads  →';
            }
        }

        let currentFinderLeads = []; // Global variable to store last results

        function renderFinderResults(leadsList) {
            currentFinderLeads = leadsList;
            const container = document.getElementById('finder-results-container');
            const tbody = document.getElementById('finder-results-tbody');
            tbody.innerHTML = '';
            
            leadsList.forEach((lead, index) => {
                const tr = document.createElement('tr');
                tr.id = `finder-lead-row-${index}`;
                
                // Name & Website link
                const nameCell = document.createElement('td');
                nameCell.style.padding = '10px';
                nameCell.style.borderBottom = '1px solid var(--border-color)';
                if (lead.website) {
                    nameCell.innerHTML = `<strong>${lead.company_name}</strong><br><a href="${lead.website}" target="_blank" class="website-link" style="font-size: 11px;">${lead.website.substring(0, 45)}...</a>`;
                } else {
                    nameCell.innerHTML = `<strong>${lead.company_name}</strong>`;
                }
                
                // Email status
                const emailCell = document.createElement('td');
                emailCell.style.padding = '10px';
                emailCell.style.borderBottom = '1px solid var(--border-color)';
                if (lead.contact_email) {
                    emailCell.innerHTML = `<span class="status status-replied" style="font-size: 10px; padding: 2px 6px;">${lead.contact_email}</span>`;
                } else {
                    emailCell.innerHTML = `<span class="status status-failed" style="font-size: 10px; padding: 2px 6px;">None Found</span>`;
                }
                
                // Action cell (individual import)
                const actionCell = document.createElement('td');
                actionCell.style.padding = '10px';
                actionCell.style.borderBottom = '1px solid var(--border-color)';
                actionCell.style.textAlign = 'right';
                
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'btn-action';
                btn.style.fontSize = '10px';
                btn.style.padding = '3px 8px';
                btn.textContent = 'Load';
                
                if (lead.contact_email) {
                    btn.onclick = () => importSingleLead(index);
                } else {
                    btn.disabled = true;
                    btn.title = 'No email found';
                }
                actionCell.appendChild(btn);
                
                tr.appendChild(nameCell);
                tr.appendChild(emailCell);
                tr.appendChild(actionCell);
                tbody.appendChild(tr);
            });
            
            container.style.display = 'block';
        }

        async function importSingleLead(index) {
            const lead = currentFinderLeads[index];
            const row = document.getElementById(`finder-lead-row-${index}`);
            const btn = row.querySelector('button');
            btn.disabled = true;
            btn.textContent = 'Loading...';
            
            try {
                const res = await fetch('/api/import_leads', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ leads: [lead] })
                });
                
                if (res.ok) {
                    const data = await res.json();
                    const detail = data.details && data.details[0];
                    if (detail && detail.status === 'added') {
                        showToast(`Lead loaded to pipeline successfully!`, 'success');
                        row.style.opacity = '0.5';
                        btn.replaceWith(document.createTextNode('✓ Loaded'));
                        reloadDashboardData();
                    } else if (detail && detail.status === 'duplicate') {
                        showToast(`Lead is already in your pipeline.`, 'warning');
                        btn.replaceWith(document.createTextNode('Already in pipeline'));
                    } else {
                        showToast(`Failed to load lead.`, 'error');
                        btn.disabled = false;
                        btn.textContent = 'Load';
                    }
                }
            } catch (err) {
                showToast('Error importing lead.', 'error');
                btn.disabled = false;
                btn.textContent = 'Load';
            }
        }

        async function importAllLeads() {
            // Filter only leads that have emails
            const validLeads = currentFinderLeads.filter(l => l.contact_email);
            if (validLeads.length === 0) {
                showToast('No leads with valid emails to import.', 'warning');
                return;
            }
            
            const btn = document.getElementById('btn-import-all');
            btn.disabled = true;
            btn.textContent = 'Loading...';
            
            try {
                const res = await fetch('/api/import_leads', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ leads: validLeads })
                });
                
                if (res.ok) {
                    const data = await res.json();
                    showToast(`Successfully imported ${data.added} leads! (${data.skipped} skipped/duplicates)`, 'success');
                    closeModal('lead-finder-modal');
                    reloadDashboardData();
                }
            } catch (err) {
                showToast('Error importing leads.', 'error');
            } finally {
                btn.disabled = false;
                btn.textContent = 'Load All to Pipeline';
            }
        }

        async function pollLeadFinderStatus() {
            const consoleBox = document.getElementById('finder-console');
            const submitBtn = document.getElementById('finder-submit-btn');

            try {
                const res = await fetch('/api/lead_finder_status');
                if (res.ok) {
                    const data = await res.json();
                    const logs = data.logs || [];
                    const active = data.active;
                    const results = data.results || {};

                    // Only append new logs
                    if (logs.length > lastLogLength) {
                        for (let i = lastLogLength; i < logs.length; i++) {
                            const div = document.createElement('div');
                            div.textContent = logs[i];
                            // Color specific messages
                            if (logs[i].startsWith('✅')) {
                                div.style.color = 'var(--status-success)';
                            } else if (logs[i].startsWith('❌') || logs[i].startsWith('⚠')) {
                                div.style.color = 'var(--status-danger)';
                            } else if (logs[i].startsWith('🚀') || logs[i].startsWith('🎯')) {
                                div.style.color = 'var(--accent-cyan)';
                                div.style.fontWeight = 'bold';
                            }
                            consoleBox.appendChild(div);
                        }
                        lastLogLength = logs.length;
                        consoleBox.scrollTop = consoleBox.scrollHeight;
                    }

                    if (!active) {
                        clearInterval(leadFinderInterval);
                        submitBtn.disabled = false;
                        submitBtn.textContent = 'Find & Enrich Leads  →';
                        
                        if (results && results.leads && results.leads.length > 0) {
                            showToast(`Lead finder complete! Found ${results.leads.length} businesses.`, 'success');
                            renderFinderResults(results.leads);
                        } else {
                            showToast('Lead finder completed or stopped.', 'info');
                        }
                    }
                }
            } catch (err) {
                console.error('Error polling lead finder status:', err);
            }
        }

        // Play/Pause Runner toggle
        async function toggleCampaignState() {
            const indicator = document.getElementById('campaign-indicator');
            const textEl = document.getElementById('campaign-state-text');
            const isRunning = textEl.textContent.trim().toLowerCase() === 'running';
            const newState = isRunning ? 'paused' : 'running';

            try {
                const res = await fetch('/toggle_campaign', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ state: newState })
                });

                if (res.ok) {
                    const data = await res.json();
                    textEl.textContent = data.state;
                    if (data.state === 'running') {
                        indicator.className = 'switch-indicator running';
                        showToast('Campaign pipeline is now active and running!', 'success');
                    } else {
                        indicator.className = 'switch-indicator paused';
                        showToast('Campaign pipeline is paused safely.', 'warning');
                    }
                }
            } catch (err) {
                showToast('Failed to switch campaign execution mode.', 'error');
            }
        }

        // Add Single Prospect Form
        async function submitAddLead(e) {
            e.preventDefault();
            const data = {
                company_name: document.getElementById('add-company').value,
                contact_name: document.getElementById('add-name').value,
                contact_email: document.getElementById('add-email').value,
                website: document.getElementById('add-website').value,
                practice_areas: document.getElementById('add-areas').value
            };

            try {
                const res = await fetch('/add_lead', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify(data)
                });
                
                const result = await res.json();
                if (res.ok) {
                    showToast('Prospect added successfully to SQLite pipeline!', 'success');
                    closeModal('add-modal');
                    document.getElementById('add-lead-form').reset();
                    reloadDashboardData();
                } else {
                    showToast(result.message || 'Error adding lead.', 'error');
                }
            } catch (err) {
                showToast('Network error during operation.', 'error');
            }
        }

        // CSV Import Form
        async function submitCSVImport(e) {
            e.preventDefault();
            const fileInput = document.getElementById('csv-file');
            const submitBtn = document.getElementById('csv-submit-btn');
            
            if (fileInput.files.length === 0) return;
            
            const formData = new FormData();
            formData.append('csv_file', fileInput.files[0]);
            
            submitBtn.disabled = true;
            submitBtn.textContent = 'Parsing...';
            
            try {
                const res = await fetch('/import_csv', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await res.json();
                if (res.ok) {
                    showToast(`Success! Imported ${result.added} prospects. (${result.duplicates} skipped as duplicates)`, 'success');
                    closeModal('csv-modal');
                    document.getElementById('csv-form').reset();
                    reloadDashboardData();
                } else {
                    showToast(result.message || 'Failed to parse CSV.', 'error');
                }
            } catch (err) {
                showToast('Error uploading CSV leads spreadsheet.', 'error');
            } finally {
                submitBtn.disabled = false;
                submitBtn.textContent = 'Upload & Parse';
            }
        }

        // Trigger dynamic API page data reload
        async function reloadDashboardData() {
            try {
                const res = await fetch('/leads_api');
                if (res.ok) {
                    const data = await res.json();
                    leads = data.leads;
                    
                    // Update stats counters
                    document.getElementById('stat-total').textContent = data.stats.total;
                    document.getElementById('stat-pending').textContent = data.stats.pending;
                    document.getElementById('stat-sent').textContent = data.stats.sent;
                    document.getElementById('stat-replied').textContent = data.stats.replied;
                    document.getElementById('stat-failed').textContent = data.stats.failed;
                    document.getElementById('stat-rate').textContent = data.stats.reply_rate + '%';
                    
                    renderTable();
                    loadDailyBrief();
                }
            } catch (err) {
                console.error('Error reloading statistics.', err);
            }
        }

        // Action: Mark as Replied
        async function markAsReplied(id) {
            try {
                const res = await fetch(`/update_status/${id}`, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ status: 'replied' })
                });
                if (res.ok) {
                    showToast('Prospect marked as Replied! Campaign outbound checks paused.', 'success');
                    reloadDashboardData();
                }
            } catch (err) {
                showToast('Failed to update prospect.', 'error');
            }
        }

        // Action: Delete Lead
        async function deleteLead(id) {
            if (!confirm('Are you absolutely sure you want to remove this prospect from your sovereign database?')) return;
            
            try {
                const res = await fetch(`/delete_lead/${id}`, {
                    method: 'POST'
                });
                if (res.ok) {
                    showToast('Prospect deleted successfully.', 'success');
                    reloadDashboardData();
                }
            } catch (err) {
                showToast('Failed to remove prospect.', 'error');
            }
        }

        // Modal Action: Inspect Brief Drawer
        function inspectBrief(id) {
            const lead = leads.find(l => l.id == id);
            if (!lead) return;
            
            document.getElementById('brief-recipient').textContent = `${lead.company_name} (${lead.contact_email})`;
            document.getElementById('brief-content').value = lead.generated_email || 'No outreach brief compiled yet. The campaign loop will crawl the website and synthesize a highly personalized outline natively on first execution.';
            document.getElementById('brief-sent-time').textContent = lead.sent_at ? `Sent on: ${lead.sent_at}` : 'Status: Waiting in outreach queue';
            
            openModal('brief-modal');
        }

        // Copy outreach brief text
        function copyBriefText() {
            const copyText = document.getElementById('brief-content');
            copyText.select();
            copyText.setSelectionRange(0, 99999);
            navigator.clipboard.writeText(copyText.value);
            showToast('Outreach text copied to system clipboard!', 'success');
        }

        // Table Render engine with sorting, search queries, and client-side pagination
        function filterByStatus(status) {
            currentFilter = status;
            
            // Remove active classes
            document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
            const activeTab = document.getElementById(`tab-${status}`);
            if (activeTab) activeTab.classList.add('active');
            
            currentPage = 1;
            renderTable();
        }

        function handleSearch() {
            searchQuery = document.getElementById('search-input').value.toLowerCase();
            currentPage = 1;
            renderTable();
        }

        function sortTable(column) {
            if (sortColumn === column) {
                sortDirection = sortDirection === 'asc' ? 'desc' : 'asc';
            } else {
                sortColumn = column;
                sortDirection = 'asc';
            }
            renderTable();
        }

        function prevPage() {
            if (currentPage > 1) {
                currentPage--;
                renderTable();
            }
        }

        function nextPage() {
            const filtered = getFilteredLeads();
            if (currentPage * rowsPerPage < filtered.length) {
                currentPage++;
                renderTable();
            }
        }

        function getFilteredLeads() {
            return leads.filter(lead => {
                // Filter by status tab selection
                if (currentFilter !== 'all') {
                    if (lead.status !== currentFilter) return false;
                }
                
                // Filter by search query
                if (searchQuery) {
                    const matchCompany = (lead.company_name || '').toLowerCase().includes(searchQuery);
                    const matchName = (lead.contact_name || '').toLowerCase().includes(searchQuery);
                    const matchEmail = (lead.contact_email || '').toLowerCase().includes(searchQuery);
                    return matchCompany || matchName || matchEmail;
                }
                
                return true;
            }).sort((a, b) => {
                let valA = a[sortColumn] || '';
                let valB = b[sortColumn] || '';
                
                if (typeof valA === 'string') valA = valA.toLowerCase();
                if (typeof valB === 'string') valB = valB.toLowerCase();
                
                if (valA < valB) return sortDirection === 'asc' ? -1 : 1;
                if (valA > valB) return sortDirection === 'asc' ? 1 : -1;
                return 0;
            });
        }

        function renderTable() {
            const tbody = document.getElementById('leads-tbody');
            tbody.innerHTML = '';
            
            const filtered = getFilteredLeads();
            
            // Slice page rows
            const startIndex = (currentPage - 1) * rowsPerPage;
            const endIndex = Math.min(startIndex + rowsPerPage, filtered.length);
            const pagedLeads = filtered.slice(startIndex, endIndex);
            
            if (pagedLeads.length === 0) {
                tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; color: var(--text-secondary); padding: 30px;">No prospects found in your SQLite pipeline database. Click "+ Add Prospect" to get started!</td></tr>`;
                document.getElementById('pagination-info').textContent = 'Showing 0-0 of 0 prospects';
                document.getElementById('btn-prev').disabled = true;
                document.getElementById('btn-next').disabled = true;
                return;
            }
            
            pagedLeads.forEach(lead => {
                const tr = document.createElement('tr');
                
                const displayContactName = lead.contact_name ? lead.contact_name : 'N/A';
                const formattedSent = lead.sent_at ? lead.sent_at : 'Waiting';
                
                const websiteLink = lead.website 
                    ? `<a href="${lead.website}" target="_blank" class="website-link">${lead.website.replace(/^https?:\/\//i, '')}</a>` 
                    : '<span style="color:var(--text-secondary);">None</span>';
                
                tr.innerHTML = `
                    <td>
                        <div style="font-weight: 600; color:var(--text-primary);">${lead.company_name}</div>
                        <div style="font-size: 11.5px; color: var(--text-secondary); margin-top: 2px;">👤 ${displayContactName}</div>
                    </td>
                    <td class="monospace">${lead.contact_email}</td>
                    <td>${websiteLink}</td>
                    <td><span class="status status-${lead.status}">${lead.status}</span></td>
                    <td class="monospace">${formattedSent}</td>
                    <td>
                        <div class="actions-cell">
                            <button class="btn-action" onclick="inspectBrief(${lead.id})">🔍 Inspect Brief</button>
                            ${lead.status !== 'replied' ? `<button class="btn-action btn-replied" onclick="markAsReplied(${lead.id})">✔ Replied</button>` : ''}
                            <button class="btn-action btn-delete" onclick="deleteLead(${lead.id})">✕ Remove</button>
                        </div>
                    </td>
                `;
                tbody.appendChild(tr);
            });
            
            // Update pagination text & buttons
            document.getElementById('pagination-info').textContent = `Showing ${startIndex + 1}-${endIndex} of ${filtered.length} prospects`;
            document.getElementById('btn-prev').disabled = currentPage === 1;
            document.getElementById('btn-next').disabled = endIndex >= filtered.length;
        }

        const CURRENT_VERSION = '1.0.0';
        async function checkUpdates() {
            try {
                const res = await fetch('https://promailer-backend-rdnl.onrender.com/version');
                if (res.ok) {
                    const data = await res.json();
                    if (data.version && data.version !== CURRENT_VERSION) {
                        document.getElementById('latest-version-num').textContent = data.version;
                        document.getElementById('update-alert-banner').style.display = 'flex';
                    }
                }
            } catch (err) {
                console.log('Update checker skipped:', err);
            }
        }

        // ── Settings JS Logic ──
        let settingsTemplates = [];
        let activeTemplateId = null;

        async function openSettingsModal() {
            try {
                const res = await fetch('/api/get_settings');
                if (res.ok) {
                    const data = await res.json();
                    
                    // Set Campaign sliders
                    document.getElementById('settings-send-limit').value = data.daily_send_limit;
                    document.getElementById('label-send-limit').textContent = data.daily_send_limit;
                    document.getElementById('settings-cooldown').value = data.cooldown_minutes;
                    document.getElementById('label-cooldown').textContent = data.cooldown_minutes;
                    
                    // Set Provider dropdown
                    const providerSelect = document.getElementById('settings-llm-provider');
                    providerSelect.value = data.llm_provider;
                    
                    // Fill API Keys
                    const apiKeys = {
                        openai: data.openai_key,
                        anthropic: data.anthropic_key,
                        google: data.google_key,
                        groq: data.groq_key,
                        deepseek: data.deepseek_key,
                        custom: data.llm_custom_key
                    };
                    
                    // Store templates
                    settingsTemplates = data.templates || [];
                    const activeTmpl = settingsTemplates.find(t => t.active);
                    activeTemplateId = activeTmpl ? activeTmpl.id : (settingsTemplates[0] ? settingsTemplates[0].id : null);
                    
                    // Custom provider options
                    document.getElementById('settings-custom-name').value = data.llm_custom_name || '';
                    document.getElementById('settings-custom-base-url').value = data.llm_custom_base_url || '';
                    document.getElementById('settings-custom-model').value = data.llm_custom_model || '';
                    
                    // Ollama options
                    document.getElementById('settings-ollama-url').value = data.ollama_url || '';
                    document.getElementById('settings-ollama-model').value = data.ollama_model || '';
                    
                    // Places API key
                    document.getElementById('settings-google-places-key').value = data.google_places_api_key || '';
                    
                    // Set active API key value based on provider select
                    updateApiKeyField(apiKeys[data.llm_provider] || '');
                    
                    toggleProviderFields();
                    renderTemplateTabs();
                    
                    if (activeTemplateId) {
                        loadTemplateToEditor(activeTemplateId);
                    }
                    
                    // Clear test key status
                    document.getElementById('test-key-status').textContent = '';
                    
                    openModal('settings-modal');
                }
            } catch (err) {
                showToast('Failed to load campaign settings.', 'error');
            }
        }

        function updateApiKeyField(val) {
            const keyInput = document.getElementById('settings-api-key');
            keyInput.value = val;
            // set placeholder
            keyInput.placeholder = val ? '••••••••••••••••••••' : 'Paste API key here';
        }

        function toggleProviderFields() {
            const provider = document.getElementById('settings-llm-provider').value;
            const keyField = document.getElementById('field-api-key');
            const customFields = document.getElementById('fields-custom-llm');
            const ollamaFields = document.getElementById('fields-ollama');
            
            // Clear test status
            document.getElementById('test-key-status').textContent = '';
            
            if (provider === 'ollama') {
                keyField.style.display = 'none';
                customFields.style.display = 'none';
                ollamaFields.style.display = 'block';
            } else if (provider === 'custom') {
                keyField.style.display = 'block';
                customFields.style.display = 'block';
                ollamaFields.style.display = 'none';
            } else {
                keyField.style.display = 'block';
                customFields.style.display = 'none';
                ollamaFields.style.display = 'none';
            }
        }

        async function testAPIKey() {
            const provider = document.getElementById('settings-llm-provider').value;
            const apiKey = document.getElementById('settings-api-key').value;
            const statusEl = document.getElementById('test-key-status');
            
            statusEl.style.color = 'var(--status-warning)';
            statusEl.textContent = '⏳ Testing connection...';
            
            const payload = {
                provider: provider,
                api_key: apiKey
            };
            
            if (provider === 'custom') {
                payload.base_url = document.getElementById('settings-custom-base-url').value;
                payload.model = document.getElementById('settings-custom-model').value;
            } else if (provider === 'google') {
                payload.model = 'gemini-1.5-flash';
            }
            
            try {
                const res = await fetch('/api/test_llm', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify(payload)
                });
                
                const data = await res.json();
                if (res.ok && data.status === 'success') {
                    statusEl.style.color = 'var(--status-success)';
                    statusEl.textContent = '✅ Connected successfully!';
                    showToast('LLM test successful!', 'success');
                } else {
                    statusEl.style.color = 'var(--status-danger)';
                    statusEl.textContent = '❌ Failed: ' + (data.message || 'Unknown error');
                    showToast('LLM test failed.', 'error');
                }
            } catch (err) {
                statusEl.style.color = 'var(--status-danger)';
                statusEl.textContent = '❌ Connection error.';
            }
        }

        function renderTemplateTabs() {
            const container = document.getElementById('template-tabs-container');
            container.innerHTML = '';
            
            settingsTemplates.forEach((t) => {
                const wrapper = document.createElement('div');
                wrapper.style.display = 'flex';
                wrapper.style.flexDirection = 'column';
                wrapper.style.alignItems = 'center';
                wrapper.style.gap = '4px';
                
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = `modal-tab-btn ${t.id === activeTemplateId ? 'active' : ''}`;
                btn.textContent = t.active ? `★ ${t.name}` : t.name;
                btn.onclick = () => {
                    saveCurrentEditorState();
                    activeTemplateId = t.id;
                    renderTemplateTabs();
                    loadTemplateToEditor(t.id);
                };
                
                wrapper.appendChild(btn);
                
                if (!t.active) {
                    const activeLink = document.createElement('a');
                    activeLink.href = '#';
                    activeLink.style.fontSize = '9px';
                    activeLink.style.color = 'var(--accent-blue)';
                    activeLink.style.textDecoration = 'none';
                    activeLink.textContent = 'Set Active';
                    activeLink.onclick = (e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        makeTemplateActive(t.id);
                    };
                    wrapper.appendChild(activeLink);
                } else {
                    const activeSpan = document.createElement('span');
                    activeSpan.style.fontSize = '9px';
                    activeSpan.style.color = 'var(--status-success)';
                    activeSpan.textContent = 'Active';
                    wrapper.appendChild(activeSpan);
                }
                
                container.appendChild(wrapper);
            });
            
            if (settingsTemplates.length < 5) {
                const addBtn = document.createElement('button');
                addBtn.type = 'button';
                addBtn.className = 'modal-tab-btn';
                addBtn.style.border = '1px dashed var(--border-color)';
                addBtn.textContent = '+ Add New';
                addBtn.onclick = () => {
                    saveCurrentEditorState();
                    const newId = Math.max(...settingsTemplates.map(t => t.id), 0) + 1;
                    const newTmpl = {
                        id: newId,
                        name: `Outreach Draft ${settingsTemplates.length + 1}`,
                        subject: "Quick question regarding {company_name}",
                        body: "Hi {contact_name},\\n\\nI came across {company_name}...",
                        active: false
                    };
                    settingsTemplates.push(newTmpl);
                    activeTemplateId = newId;
                    renderTemplateTabs();
                    loadTemplateToEditor(newId);
                };
                container.appendChild(addBtn);
            }
        }

        function loadTemplateToEditor(id) {
            const t = settingsTemplates.find(tmpl => tmpl.id === id);
            if (t) {
                document.getElementById('settings-template-name').value = t.name;
                document.getElementById('settings-template-subject').value = t.subject;
                document.getElementById('settings-template-body').value = t.body;
                
                // Show delete button if multiple templates
                const deleteBtn = document.getElementById('btn-delete-template');
                deleteBtn.style.display = settingsTemplates.length > 1 ? 'inline-block' : 'none';
            }
        }

        function saveCurrentEditorState() {
            if (!activeTemplateId) return;
            const name = document.getElementById('settings-template-name').value.trim();
            const subject = document.getElementById('settings-template-subject').value.trim();
            const body = document.getElementById('settings-template-body').value;
            
            const current = settingsTemplates.find(t => t.id === activeTemplateId);
            if (current) {
                current.name = name || current.name;
                current.subject = subject || current.subject;
                current.body = body;
            }
        }

        function makeTemplateActive(id) {
            saveCurrentEditorState();
            settingsTemplates.forEach(t => t.active = (t.id === id));
            renderTemplateTabs();
            showToast('Active outreach template updated!', 'success');
        }

        function deleteCurrentTemplate() {
            if (settingsTemplates.length <= 1) {
                showToast('You must keep at least one template.', 'warning');
                return;
            }
            if (!confirm('Are you sure you want to delete this template draft?')) return;
            
            const idx = settingsTemplates.findIndex(t => t.id === activeTemplateId);
            const wasActive = settingsTemplates[idx].active;
            settingsTemplates.splice(idx, 1);
            
            if (wasActive) {
                settingsTemplates[0].active = true;
            }
            activeTemplateId = settingsTemplates[0].id;
            renderTemplateTabs();
            loadTemplateToEditor(activeTemplateId);
            showToast('Template draft removed.', 'info');
        }

        async function submitSaveSettings(e) {
            e.preventDefault();
            saveCurrentEditorState();
            
            const provider = document.getElementById('settings-llm-provider').value;
            const limit = parseInt(document.getElementById('settings-send-limit').value);
            const cooldown = parseInt(document.getElementById('settings-cooldown').value);
            
            const payload = {
                llm_provider: provider,
                daily_send_limit: limit,
                cooldown_minutes: cooldown,
                templates: settingsTemplates
            };
            
            // Map individual provider keys
            const keyVal = document.getElementById('settings-api-key').value;
            if (provider !== 'ollama') {
                payload[provider + '_key'] = keyVal;
            }
            
            if (provider === 'custom') {
                payload.llm_custom_name = document.getElementById('settings-custom-name').value;
                payload.llm_custom_base_url = document.getElementById('settings-custom-base-url').value;
                payload.llm_custom_model = document.getElementById('settings-custom-model').value;
            } else if (provider === 'ollama') {
                payload.ollama_url = document.getElementById('settings-ollama-url').value;
                payload.ollama_model = document.getElementById('settings-ollama-model').value;
            }
            
            // Google Places key
            payload.google_places_api_key = document.getElementById('settings-google-places-key').value;
            
            try {
                const res = await fetch('/api/save_settings', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify(payload)
                });
                
                if (res.ok) {
                    showToast('Settings saved successfully! Pacing updated.', 'success');
                    
                    // Update frontend pacing label
                    document.getElementById('pacing-send-limit').textContent = limit;
                    document.getElementById('pacing-cooldown').textContent = cooldown;
                    
                    closeModal('settings-modal');
                } else {
                    showToast('Failed to save settings.', 'error');
                }
            } catch (err) {
                showToast('Network error saving settings.', 'error');
            }
        }

        // ── Daily Brief JS Logic ──
        async function loadDailyBrief() {
            try {
                const res = await fetch('/api/daily_brief');
                if (res.ok) {
                    const data = await res.json();
                    const container = document.getElementById('daily-brief-container');
                    const listEl = document.getElementById('daily-brief-list');
                    
                    if (data.replies && data.replies.length > 0) {
                        listEl.innerHTML = '';
                        data.replies.forEach(r => {
                            const card = document.createElement('div');
                            card.className = 'brief-card';
                            
                            // Shorten reply text
                            let cleanReply = r.reply_body || 'No message content parsed.';
                            let snippet = cleanReply.length > 120 ? cleanReply.substring(0, 120) + '...' : cleanReply;
                            
                            card.innerHTML = `
                                <div class="brief-card-header">
                                    <span style="font-weight:700; color:var(--text-primary);">${r.company_name}</span>
                                    <span style="font-size:11px; color:var(--text-secondary);">${r.reply_received_at.split(' ')[0]}</span>
                                </div>
                                <div style="font-size:11.5px; color:var(--text-secondary); margin-bottom:4px;">👤 ${r.contact_name || 'Contact'} (${r.contact_email})</div>
                                <div style="font-size:12.5px; line-height:1.4; color:#d1d5db; background:rgba(0,0,0,0.2); padding:8px; border-radius:4px; margin-bottom:8px; border:1px solid rgba(255,255,255,0.03); max-height:60px; overflow:hidden; font-family: monospace;">
                                    ${snippet}
                                </div>
                                <button class="btn btn-action" style="font-size:11px; padding:4px 8px; align-self: flex-end;" onclick="inspectReply(${r.id})">🔍 Inspect Reply</button>
                            `;
                            listEl.appendChild(card);
                        });
                        container.style.display = 'block';
                    } else {
                        container.style.display = 'none';
                    }
                }
            } catch (err) {
                console.error('Error loading daily brief replies:', err);
            }
        }

        let currentRepliesList = []; // local cache
        async function inspectReply(leadId) {
            // Get replies details
            try {
                const res = await fetch('/api/daily_brief');
                if (res.ok) {
                    const data = await res.json();
                    const reply = data.replies.find(r => r.id === leadId);
                    if (reply) {
                        document.getElementById('reply-sender-header').textContent = `${reply.company_name} - ${reply.contact_name || 'Contact'} (${reply.contact_email})`;
                        document.getElementById('reply-body-content').value = reply.reply_body || 'No content parsed.';
                        document.getElementById('reply-received-time').textContent = `Received: ${reply.reply_received_at}`;
                        
                        // Mailto link Setup
                        const mailtoBtn = document.getElementById('reply-mailto-btn');
                        const subjectText = encodeURIComponent(`Re: Outreach connection`);
                        mailtoBtn.href = `mailto:${reply.contact_email}?subject=${subjectText}`;
                        
                        openModal('reply-modal');
                    }
                }
            } catch (err) {
                showToast('Failed to load reply details.', 'error');
            }
        }

        // ── AI Coach Chat Logic ──
        function toggleAICoach() {
            const drawer = document.getElementById('ai-coach-drawer');
            drawer.classList.toggle('open');
        }

        async function sendCoachPreset(text) {
            document.getElementById('ai-coach-input').value = text;
            sendCoachMessage();
        }

        async function sendCoachMessage() {
            const inputEl = document.getElementById('ai-coach-input');
            const message = inputEl.value.trim();
            const chatArea = document.getElementById('ai-coach-chat-area');
            const sendBtn = document.getElementById('btn-send-coach');
            
            if (!message) return;
            
            // Append User Message
            const userBubble = document.createElement('div');
            userBubble.className = 'chat-bubble user';
            userBubble.textContent = message;
            chatArea.appendChild(userBubble);
            
            inputEl.value = '';
            chatArea.scrollTop = chatArea.scrollHeight;
            
            // Loading bubble
            const loadingBubble = document.createElement('div');
            loadingBubble.className = 'chat-bubble ai';
            loadingBubble.textContent = '⏳ Thinking...';
            chatArea.appendChild(loadingBubble);
            chatArea.scrollTop = chatArea.scrollHeight;
            
            sendBtn.disabled = true;
            
            try {
                const res = await fetch('/api/ai_coach', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ message: message })
                });
                
                loadingBubble.remove();
                
                if (res.ok) {
                    const data = await res.json();
                    const coachBubble = document.createElement('div');
                    coachBubble.className = 'chat-bubble ai';
                    
                    // Simple markdown formatting helper
                    let formatted = data.response
                        .replace(/\\n/g, '<br>')
                        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                        .replace(/\*(.*?)\*/g, '<em>$1</em>')
                        .replace(/`(.*?)`/g, '<code class="monospace">$1</code>');
                        
                    coachBubble.innerHTML = formatted;
                    chatArea.appendChild(coachBubble);
                } else {
                    const data = await res.json();
                    const errBubble = document.createElement('div');
                    errBubble.className = 'chat-bubble ai';
                    errBubble.style.color = 'var(--status-danger)';
                    errBubble.textContent = '❌ Coach is unavailable: ' + (data.message || 'Check your AI credentials.');
                    chatArea.appendChild(errBubble);
                }
            } catch (err) {
                loadingBubble.remove();
                const errBubble = document.createElement('div');
                errBubble.className = 'chat-bubble ai';
                errBubble.style.color = 'var(--status-danger)';
                errBubble.textContent = '❌ Network connection error.';
                chatArea.appendChild(errBubble);
            } finally {
                sendBtn.disabled = false;
                chatArea.scrollTop = chatArea.scrollHeight;
            }
        }

        // Run render on initial loading
        window.onload = () => {
            renderTable();
            checkUpdates();
            loadDailyBrief();
            
            // Load limits from backend for pacing label
            fetch('/api/get_settings')
                .then(res => res.json())
                .then(data => {
                    document.getElementById('pacing-send-limit').textContent = data.daily_send_limit;
                    document.getElementById('pacing-cooldown').textContent = data.cooldown_minutes;
                }).catch(err => {});
        };
    </script>
</body>
</html>
"""

def get_db_connection():
    conn = sqlite3.connect(DB_NAME, timeout=30.0)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.row_factory = sqlite3.Row
    return conn

def format_dt(val):
    if not val:
        return None
    if isinstance(val, str):
        return val
    try:
        return val.strftime('%Y-%m-%d %H:%M:%S')
    except Exception:
        return str(val)

@app.route('/')
def index():
    conn = get_db_connection()
    leads_rows = conn.execute('SELECT * FROM leads ORDER BY created_at DESC').fetchall()
    
    # Map row objects to clean lists of dicts for client JSON injection
    leads_list = []
    for r in leads_rows:
        leads_list.append({
            'id': r['id'],
            'company_name': r['company_name'],
            'contact_name': r['contact_name'],
            'contact_email': r['contact_email'],
            'website': r['website'],
            'practice_areas': r['practice_areas'],
            'status': r['status'],
            'generated_email': r['generated_email'],
            'created_at': format_dt(r['created_at']),
            'sent_at': format_dt(r['sent_at'])
        })
        
    from datetime import datetime
    today = datetime.now().strftime('%Y-%m-%d')
    
    total = conn.execute('SELECT COUNT(*) FROM leads').fetchone()[0]
    sent = conn.execute("SELECT COUNT(*) FROM leads WHERE status IN ('sent', 'followed_up')").fetchone()[0]
    replied = conn.execute("SELECT COUNT(*) FROM leads WHERE status = 'replied'").fetchone()[0]
    pending = conn.execute("SELECT COUNT(*) FROM leads WHERE status = 'pending'").fetchone()[0]
    failed = conn.execute("SELECT COUNT(*) FROM leads WHERE status = 'failed'").fetchone()[0]
    
    # Calculate Dynamic Reply Rate %
    total_contacted = sent + replied
    reply_rate = round((replied / total_contacted) * 100, 1) if total_contacted > 0 else 0.0
    
    stats = {
        'total': total,
        'sent': sent,
        'replied': replied,
        'pending': pending,
        'failed': failed,
        'reply_rate': reply_rate
    }
    
    # Check current Play/Pause Campaign state
    state = 'running'
    if os.path.exists("campaign_state.txt"):
        with open("campaign_state.txt", "r") as f:
            file_state = f.read().strip().lower()
            if file_state in ['running', 'paused']:
                state = file_state
                
    conn.close()
    
    # Import json safely into HTML Template injection
    import json
    return render_template_string(HTML_TEMPLATE, leads_json=json.dumps(leads_list), stats=stats, state=state)

@app.route('/leads_api')
def leads_api():
    conn = get_db_connection()
    leads_rows = conn.execute('SELECT * FROM leads ORDER BY created_at DESC').fetchall()
    
    leads_list = []
    for r in leads_rows:
        leads_list.append({
            'id': r['id'],
            'company_name': r['company_name'],
            'contact_name': r['contact_name'],
            'contact_email': r['contact_email'],
            'website': r['website'],
            'practice_areas': r['practice_areas'],
            'status': r['status'],
            'generated_email': r['generated_email'],
            'created_at': format_dt(r['created_at']),
            'sent_at': format_dt(r['sent_at'])
        })
        
    total = conn.execute('SELECT COUNT(*) FROM leads').fetchone()[0]
    sent = conn.execute("SELECT COUNT(*) FROM leads WHERE status IN ('sent', 'followed_up')").fetchone()[0]
    replied = conn.execute("SELECT COUNT(*) FROM leads WHERE status = 'replied'").fetchone()[0]
    pending = conn.execute("SELECT COUNT(*) FROM leads WHERE status = 'pending'").fetchone()[0]
    failed = conn.execute("SELECT COUNT(*) FROM leads WHERE status = 'failed'").fetchone()[0]
    
    total_contacted = sent + replied
    reply_rate = round((replied / total_contacted) * 100, 1) if total_contacted > 0 else 0.0
    
    stats = {
        'total': total,
        'sent': sent,
        'replied': replied,
        'pending': pending,
        'failed': failed,
        'reply_rate': reply_rate
    }
    
    conn.close()
    return jsonify({'leads': leads_list, 'stats': stats})

@app.route('/toggle_campaign', methods=['POST'])
def toggle_campaign():
    data = request.json or {}
    new_state = data.get('state', 'running').strip().lower()
    
    if new_state not in ['running', 'paused']:
        return jsonify({'status': 'error', 'message': 'Invalid state'}), 400
        
    with open("campaign_state.txt", "w") as f:
        f.write(new_state)
        
    return jsonify({'status': 'success', 'state': new_state})

@app.route('/add_lead', methods=['POST'])
def add_lead_route():
    data = request.json or {}
    company_name = data.get('company_name', '').strip()
    contact_name = data.get('contact_name', '').strip()
    contact_email = data.get('contact_email', '').strip()
    website = data.get('website', '').strip()
    practice_areas = data.get('practice_areas', '').strip()
    
    if not company_name or not contact_email:
        return jsonify({'status': 'error', 'message': 'Company name and Email are required'}), 400
        
    conn = get_db_connection()
    try:
        conn.execute('''
            INSERT INTO leads (company_name, contact_name, contact_email, website, practice_areas, created_at, status)
            VALUES (?, ?, ?, ?, ?, ?, 'pending')
        ''', (company_name, contact_name, contact_email, website, practice_areas, datetime.now()))
        conn.commit()
        conn.close()
        return jsonify({'status': 'success', 'message': 'Prospect added successfully'})
    except sqlite3.IntegrityError:
        conn.close()
        return jsonify({'status': 'error', 'message': 'Prospect email already exists in database'}), 400

@app.route('/update_status/<int:lead_id>', methods=['POST'])
def update_status(lead_id):
    data = request.json or {}
    status = data.get('status', '').strip().lower()
    if status not in ['pending', 'generated', 'sent', 'replied', 'followed_up', 'failed']:
        return jsonify({'status': 'error', 'message': 'Invalid status'}), 400
        
    conn = get_db_connection()
    conn.execute("UPDATE leads SET status = ? WHERE id = ?", (status, lead_id))
    conn.commit()
    conn.close()
    return jsonify({'status': 'success'})

@app.route('/delete_lead/<int:lead_id>', methods=['POST'])
def delete_lead(lead_id):
    conn = get_db_connection()
    conn.execute("DELETE FROM leads WHERE id = ?", (lead_id,))
    conn.commit()
    conn.close()
    return jsonify({'status': 'success'})

@app.route('/api/start_lead_finder', methods=['POST'])
def start_lead_finder():
    global lead_finder_thread, lead_finder_logs, lead_finder_active, lead_finder_results
    
    if lead_finder_active:
        return jsonify({'status': 'error', 'message': 'Lead finder is already running.'}), 400
        
    data = request.json or {}
    query = data.get('query', '').strip()
    limit = int(data.get('limit', 20))
    
    if not query:
        return jsonify({'status': 'error', 'message': 'Query is required.'}), 400
        
    # Reset State
    lead_finder_logs = []
    lead_finder_active = True
    lead_finder_results = {}
    
    def worker():
        global lead_finder_active, lead_finder_results
        try:
            from lead_finder import find_and_enrich
            
            def callback(msg):
                lead_finder_logs.append(msg)
                print(f"[Lead Finder] {msg}")
                
            res = find_and_enrich(
                query=query,
                max_results=limit,
                load_to_db=False,
                export_csv=True,
                progress_cb=callback
            )
            lead_finder_results = res
        except Exception as e:
            lead_finder_logs.append(f"❌ Error: {str(e)}")
            print(f"[Lead Finder Error] {e}")
        finally:
            lead_finder_active = False
            
    lead_finder_thread = threading.Thread(target=worker, daemon=True)
    lead_finder_thread.start()
    
    return jsonify({'status': 'success', 'message': 'Lead finder successfully initiated.'})

@app.route('/api/lead_finder_status', methods=['GET'])
def lead_finder_status():
    return jsonify({
        'active': lead_finder_active,
        'logs': lead_finder_logs,
        'results': lead_finder_results
    })

@app.route('/api/import_leads', methods=['POST'])
def import_leads():
    data = request.json or {}
    leads = data.get('leads', [])
    if not leads:
        return jsonify({'status': 'error', 'message': 'No leads provided'}), 400
        
    import sqlite3
    from datetime import datetime
    
    conn = sqlite3.connect('pipeline.db', timeout=30)
    conn.execute("PRAGMA journal_mode=WAL")
    cursor = conn.cursor()
    
    results = []
    added_count = 0
    skipped_count = 0
    
    for lead in leads:
        email = lead.get('contact_email', '').strip().lower()
        if not email:
            results.append({'email': email, 'status': 'no_email'})
            skipped_count += 1
            continue
            
        try:
            cursor.execute("""
                INSERT INTO leads (company_name, contact_name, contact_email, website, practice_areas, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                lead.get('company_name', ''),
                lead.get('contact_name') or None,
                email,
                lead.get('website') or None,
                lead.get('industry') or None,
                datetime.now().isoformat()
            ))
            results.append({'email': email, 'status': 'added'})
            added_count += 1
        except sqlite3.IntegrityError:
            results.append({'email': email, 'status': 'duplicate'})
            skipped_count += 1
            
    conn.commit()
    conn.close()
    
    return jsonify({
        'status': 'success',
        'added': added_count,
        'skipped': skipped_count,
        'details': results
    })

@app.route('/import_csv', methods=['POST'])
def import_csv():
    if 'csv_file' not in request.files:
        return jsonify({'status': 'error', 'message': 'No file uploaded'}), 400
    file = request.files['csv_file']
    if file.filename == '':
        return jsonify({'status': 'error', 'message': 'No file selected'}), 400
    
    try:
        stream = io.StringIO(file.stream.read().decode("UTF8"), newline=None)
        csv_input = csv.reader(stream)
        
        # Read header row
        try:
            header = next(csv_input)
        except StopIteration:
            return jsonify({'status': 'error', 'message': 'Empty CSV file'}), 400
            
        header_lower = [h.lower().strip() for h in header]
        
        # Map headers to our fields
        col_mapping = {
            'company_name': -1,
            'contact_name': -1,
            'contact_email': -1,
            'website': -1,
            'practice_areas': -1
        }
        
        for idx, h in enumerate(header_lower):
            if 'company' in h or 'business' in h:
                col_mapping['company_name'] = idx
            elif 'contact_name' in h or 'contact name' in h or h == 'name':
                col_mapping['contact_name'] = idx
            elif 'email' in h or 'mail' in h:
                col_mapping['contact_email'] = idx
            elif 'website' in h or 'url' in h or 'site' in h:
                col_mapping['website'] = idx
            elif 'practice' in h or 'industry' in h or 'specialty' in h or 'city' in h:
                col_mapping['practice_areas'] = idx
                
        # Positional guess fallbacks
        if col_mapping['company_name'] == -1 and len(header) > 0: col_mapping['company_name'] = 0
        if col_mapping['contact_name'] == -1 and len(header) > 1: col_mapping['contact_name'] = 1
        if col_mapping['contact_email'] == -1 and len(header) > 2: col_mapping['contact_email'] = 2
        if col_mapping['website'] == -1 and len(header) > 3: col_mapping['website'] = 3
        if col_mapping['practice_areas'] == -1 and len(header) > 4: col_mapping['practice_areas'] = 4
        
        # Ensure company and email mapped
        if col_mapping['contact_email'] == -1 or col_mapping['company_name'] == -1:
            col_mapping['company_name'] = 0
            col_mapping['contact_email'] = min(2, len(header)-1)
            
        conn = get_db_connection()
        added_count = 0
        dup_count = 0
        
        for row in csv_input:
            if not row:
                continue
            try:
                c_name = row[col_mapping['company_name']].strip() if col_mapping['company_name'] < len(row) else ''
                c_email = row[col_mapping['contact_email']].strip() if col_mapping['contact_email'] < len(row) else ''
                
                if not c_name or not c_email:
                    continue
                    
                cnt_name = row[col_mapping['contact_name']].strip() if (col_mapping['contact_name'] != -1 and col_mapping['contact_name'] < len(row)) else ''
                web = row[col_mapping['website']].strip() if (col_mapping['website'] != -1 and col_mapping['website'] < len(row)) else ''
                prac = row[col_mapping['practice_areas']].strip() if (col_mapping['practice_areas'] != -1 and col_mapping['practice_areas'] < len(row)) else ''
                
                conn.execute('''
                    INSERT INTO leads (company_name, contact_name, contact_email, website, practice_areas, created_at, status)
                    VALUES (?, ?, ?, ?, ?, ?, 'pending')
                ''', (c_name, cnt_name, c_email, web, prac, datetime.now()))
                added_count += 1
            except sqlite3.IntegrityError:
                dup_count += 1
            except Exception:
                continue
                
        conn.commit()
        conn.close()
        
        return jsonify({'status': 'success', 'added': added_count, 'duplicates': dup_count})
    except Exception as e:
        return jsonify({'status': 'error', 'message': f'CSV parsing failed: {str(e)}'}), 500

def load_templates():
    import json
    template_path = "templates.json"
    if not os.path.exists(template_path):
        from prompt_templates import DEFAULT_OLLAMA_PROMPT, DEFAULT_SUBJECT
        default_templates = [
            {
                "id": 1,
                "name": "Standard Outreach",
                "subject": DEFAULT_SUBJECT,
                "body": DEFAULT_OLLAMA_PROMPT,
                "active": True
            }
        ]
        with open(template_path, "w") as f:
            json.dump(default_templates, f, indent=4)
        return default_templates
    try:
        with open(template_path, "r") as f:
            return json.load(f)
    except Exception:
        return []

def mask_key(val):
    if not val:
        return ""
    if len(val) <= 8:
        return "••••"
    return val[:4] + "••••" + val[-4:]

def is_masked(val):
    return "••" in val or "•••" in val

def update_dotenv_file(updates: dict):
    from dotenv import load_dotenv
    env_path = ".env"
    lines = []
    existing = {}
    if os.path.exists(env_path):
        with open(env_path, "r") as f:
            lines = f.readlines()
    
    # Parse existing
    for line in lines:
        if "=" in line and not line.strip().startswith("#"):
            parts = line.split("=", 1)
            if len(parts) == 2:
                existing[parts[0].strip()] = parts[1].strip()
            
    # Apply updates
    for k, v in updates.items():
        existing[k] = str(v)
        
    # Write back
    with open(env_path, "w") as f:
        for k, v in existing.items():
            f.write(f"{k}={v}\n")
    load_dotenv()

@app.route('/api/get_settings', methods=['GET'])
def get_settings():
    from dotenv import load_dotenv
    load_dotenv()
    
    templates = load_templates()
    
    settings = {
        'daily_send_limit': int(os.getenv("DAILY_SEND_LIMIT", "20")),
        'cooldown_minutes': int(os.getenv("COOLDOWN_MINUTES", "4")),
        'llm_provider': os.getenv("LLM_PROVIDER", "ollama"),
        'ollama_url': os.getenv("OLLAMA_URL", "http://localhost:11434/api/generate"),
        'ollama_model': os.getenv("OLLAMA_MODEL", "llama3.2:3b"),
        
        'openai_key': mask_key(os.getenv("OPENAI_API_KEY")),
        'openai_model': os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
        
        'anthropic_key': mask_key(os.getenv("ANTHROPIC_API_KEY")),
        'anthropic_model': os.getenv("ANTHROPIC_MODEL", "claude-3-5-haiku-20241022"),
        
        'google_key': mask_key(os.getenv("GOOGLE_API_KEY")),
        'google_model': os.getenv("GOOGLE_MODEL", "gemini-1.5-flash"),
        
        'groq_key': mask_key(os.getenv("GROQ_API_KEY")),
        'groq_model': os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile"),
        
        'deepseek_key': mask_key(os.getenv("DEEPSEEK_API_KEY")),
        'deepseek_model': os.getenv("DEEPSEEK_MODEL", "deepseek-chat"),
        
        'llm_custom_name': os.getenv("LLM_CUSTOM_NAME", ""),
        'llm_custom_key': mask_key(os.getenv("LLM_CUSTOM_API_KEY")),
        'llm_custom_base_url': os.getenv("LLM_CUSTOM_BASE_URL", ""),
        'llm_custom_model': os.getenv("LLM_CUSTOM_MODEL", ""),
        
        'google_places_api_key': mask_key(os.getenv("GOOGLE_PLACES_API_KEY")),
        'templates': templates
    }
    return jsonify(settings)

@app.route('/api/save_settings', methods=['POST'])
def save_settings():
    from dotenv import load_dotenv
    data = request.json or {}
    
    updates = {}
    
    if 'daily_send_limit' in data:
        updates['DAILY_SEND_LIMIT'] = str(data['daily_send_limit'])
    if 'cooldown_minutes' in data:
        updates['COOLDOWN_MINUTES'] = str(data['cooldown_minutes'])
    if 'llm_provider' in data:
        updates['LLM_PROVIDER'] = str(data['llm_provider']).lower().strip()
        
    if 'ollama_url' in data:
        updates['OLLAMA_URL'] = str(data['ollama_url']).strip()
    if 'ollama_model' in data:
        updates['OLLAMA_MODEL'] = str(data['ollama_model']).strip()
        
    op_key = data.get('openai_key', '').strip()
    if op_key and not is_masked(op_key):
        updates['OPENAI_API_KEY'] = op_key
    elif op_key == "":
        updates['OPENAI_API_KEY'] = ""
    if 'openai_model' in data:
        updates['OPENAI_MODEL'] = str(data['openai_model']).strip()
        
    ant_key = data.get('anthropic_key', '').strip()
    if ant_key and not is_masked(ant_key):
        updates['ANTHROPIC_API_KEY'] = ant_key
    elif ant_key == "":
        updates['ANTHROPIC_API_KEY'] = ""
    if 'anthropic_model' in data:
        updates['ANTHROPIC_MODEL'] = str(data['anthropic_model']).strip()
        
    g_key = data.get('google_key', '').strip()
    if g_key and not is_masked(g_key):
        updates['GOOGLE_API_KEY'] = g_key
    elif g_key == "":
        updates['GOOGLE_API_KEY'] = ""
    if 'google_model' in data:
        updates['GOOGLE_MODEL'] = str(data['google_model']).strip()
        
    gr_key = data.get('groq_key', '').strip()
    if gr_key and not is_masked(gr_key):
        updates['GROQ_API_KEY'] = gr_key
    elif gr_key == "":
        updates['GROQ_API_KEY'] = ""
    if 'groq_model' in data:
        updates['GROQ_MODEL'] = str(data['groq_model']).strip()
        
    ds_key = data.get('deepseek_key', '').strip()
    if ds_key and not is_masked(ds_key):
        updates['DEEPSEEK_API_KEY'] = ds_key
    elif ds_key == "":
        updates['DEEPSEEK_API_KEY'] = ""
    if 'deepseek_model' in data:
        updates['DEEPSEEK_MODEL'] = str(data['deepseek_model']).strip()
        
    if 'llm_custom_name' in data:
        updates['LLM_CUSTOM_NAME'] = str(data['llm_custom_name']).strip()
    c_key = data.get('llm_custom_key', '').strip()
    if c_key and not is_masked(c_key):
        updates['LLM_CUSTOM_API_KEY'] = c_key
    elif c_key == "":
        updates['LLM_CUSTOM_API_KEY'] = ""
    if 'llm_custom_base_url' in data:
        updates['LLM_CUSTOM_BASE_URL'] = str(data['llm_custom_base_url']).strip()
    if 'llm_custom_model' in data:
        updates['LLM_CUSTOM_MODEL'] = str(data['llm_custom_model']).strip()
        
    gp_key = data.get('google_places_api_key', '').strip()
    if gp_key and not is_masked(gp_key):
        updates['GOOGLE_PLACES_API_KEY'] = gp_key
    elif gp_key == "":
        updates['GOOGLE_PLACES_API_KEY'] = ""
        
    update_dotenv_file(updates)
    load_dotenv()
    
    if 'templates' in data:
        templates_to_save = data['templates'][:5]
        active_found = False
        for t in templates_to_save:
            if t.get('active'):
                active_found = True
                break
        if not active_found and templates_to_save:
            templates_to_save[0]['active'] = True
            
        with open("templates.json", "w") as f:
            import json
            json.dump(templates_to_save, f, indent=4)
            
    return jsonify({'status': 'success', 'message': 'Settings saved successfully!'})

@app.route('/api/test_llm', methods=['POST'])
def test_llm():
    import requests
    from dotenv import load_dotenv
    load_dotenv()
    
    data = request.json or {}
    provider = data.get('provider', '').strip().lower()
    key = data.get('api_key', '').strip()
    
    if not key or is_masked(key):
        env_vars = {
            "openai": "OPENAI_API_KEY",
            "anthropic": "ANTHROPIC_API_KEY",
            "google": "GOOGLE_API_KEY",
            "groq": "GROQ_API_KEY",
            "deepseek": "DEEPSEEK_API_KEY",
            "custom": "LLM_CUSTOM_API_KEY"
        }
        env_var = env_vars.get(provider)
        if env_var:
            key = os.getenv(env_var, "").strip()
            
    if provider == "ollama":
        try:
            ollama_url = data.get('ollama_url') or os.getenv("OLLAMA_URL", "http://localhost:11434/api/generate")
            base = ollama_url.replace("/api/generate", "")
            r = requests.get(f"{base}/api/tags", timeout=5)
            if r.status_code == 200:
                return jsonify({'status': 'success', 'message': 'Ollama connected successfully!'})
            return jsonify({'status': 'error', 'message': f'Ollama returned status {r.status_code}'})
        except Exception as e:
            return jsonify({'status': 'error', 'message': f'Failed to connect to Ollama: {str(e)}'})
            
    if not key:
        return jsonify({'status': 'error', 'message': f'API Key is empty/not configured for {provider.capitalize()}.'})
        
    try:
        if provider == "openai":
            r = requests.post(
                "https://api.openai.com/v1/chat/completions",
                headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
                json={"model": "gpt-4o-mini", "messages": [{"role": "user", "content": "ping"}], "max_tokens": 1},
                timeout=10
            )
            if r.status_code == 200:
                return jsonify({'status': 'success', 'message': 'OpenAI API key is valid!'})
            return jsonify({'status': 'error', 'message': r.json().get('error', {}).get('message', 'Validation failed.')})
            
        elif provider == "anthropic":
            r = requests.post(
                "https://api.anthropic.com/v1/messages",
                headers={"x-api-key": key, "anthropic-version": "2023-06-01", "Content-Type": "application/json"},
                json={"model": "claude-3-5-haiku-20241022", "max_tokens": 1, "messages": [{"role": "user", "content": "ping"}]},
                timeout=10
            )
            if r.status_code == 200:
                return jsonify({'status': 'success', 'message': 'Anthropic API key is valid!'})
            return jsonify({'status': 'error', 'message': r.json().get('error', {}).get('message', 'Validation failed.')})
            
        elif provider == "google":
            model = data.get('model') or "gemini-1.5-flash"
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}"
            r = requests.post(
                url,
                headers={"Content-Type": "application/json"},
                json={"contents": [{"parts": [{"text": "ping"}]}]},
                timeout=10
            )
            if r.status_code == 200:
                return jsonify({'status': 'success', 'message': 'Google Gemini API key is valid!'})
            return jsonify({'status': 'error', 'message': r.json().get('error', {}).get('message', 'Validation failed.')})
            
        elif provider == "groq":
            r = requests.post(
                "https://api.groq.com/openai/v1/chat/completions",
                headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
                json={"model": "llama-3.3-70b-versatile", "messages": [{"role": "user", "content": "ping"}], "max_tokens": 1},
                timeout=10
            )
            if r.status_code == 200:
                return jsonify({'status': 'success', 'message': 'Groq API key is valid!'})
            return jsonify({'status': 'error', 'message': r.json().get('error', {}).get('message', 'Validation failed.')})
            
        elif provider == "deepseek":
            r = requests.post(
                "https://api.deepseek.com/chat/completions",
                headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
                json={"model": "deepseek-chat", "messages": [{"role": "user", "content": "ping"}], "max_tokens": 1},
                timeout=10
            )
            if r.status_code == 200:
                return jsonify({'status': 'success', 'message': 'DeepSeek API key is valid!'})
            return jsonify({'status': 'error', 'message': r.json().get('error', {}).get('message', 'Validation failed.')})
            
        elif provider == "custom":
            base_url = data.get('base_url', '').strip()
            custom_model = data.get('model', '').strip()
            if not base_url:
                return jsonify({'status': 'error', 'message': 'Base URL is required for Custom provider.'})
            r = requests.post(
                f"{base_url.rstrip('/')}/chat/completions",
                headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
                json={"model": custom_model or "gpt-3.5-turbo", "messages": [{"role": "user", "content": "ping"}], "max_tokens": 1},
                timeout=10
            )
            if r.status_code == 200:
                return jsonify({'status': 'success', 'message': 'Custom provider connected successfully!'})
            return jsonify({'status': 'error', 'message': f'Validation failed: Status {r.status_code}'})
            
    except Exception as e:
        return jsonify({'status': 'error', 'message': f'Connection error: {str(e)}'})
        
    return jsonify({'status': 'error', 'message': 'Unsupported provider.'})

@app.route('/api/daily_brief', methods=['GET'])
def daily_brief():
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT id, company_name, contact_name, contact_email, website, reply_body, reply_received_at FROM leads WHERE status = 'replied' ORDER BY reply_received_at DESC LIMIT 10")
        rows = cursor.fetchall()
    except sqlite3.OperationalError:
        rows = []
        
    replies = []
    for r in rows:
        replies.append({
            'id': r[0],
            'company_name': r[1],
            'contact_name': r[2],
            'contact_email': r[3],
            'website': r[4],
            'reply_body': r[5] or "No reply body saved. Run inbox checks to retrieve content.",
            'reply_received_at': format_dt(r[6]) or "Unknown Date"
        })
    conn.close()
    return jsonify({'replies': replies})

@app.route('/api/ai_coach', methods=['POST'])
def ai_coach():
    data = request.json or {}
    user_message = data.get('message', '').strip()
    
    if not user_message:
        return jsonify({'status': 'error', 'message': 'Message is empty.'}), 400
        
    from prompt_templates import get_active_template
    _, active_body = get_active_template()
    
    conn = get_db_connection()
    recent_replies_str = ""
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT company_name, reply_body FROM leads WHERE status = 'replied' ORDER BY reply_received_at DESC LIMIT 3")
        rows = cursor.fetchall()
        for idx, r in enumerate(rows):
            recent_replies_str += f"\nReply {idx+1} from {r[0]}:\n{r[1] or 'No content'}\n"
    except Exception:
        pass
    conn.close()
    
    system_prompt = f"""You are the ProMailer AI Coach. You help the user write better cold email templates, summarize replies from prospects, and suggest personalized follow-up emails.

Current Active Email Template:
\"\"\"
{active_body}
\"\"\"

Recent Replies Received:
{recent_replies_str or "No replies received yet."}

Provide helpful, concise, and professional responses. Keep suggestions realistic, non-salesy, and warm. Use Markdown for styling (such as headers, lists, code blocks)."""

    try:
        from llm import generate_text
        reply = generate_text(user_message, system_prompt=system_prompt)
        return jsonify({'status': 'success', 'response': reply})
    except Exception as e:
        return jsonify({'status': 'error', 'message': f'AI generation failed: {str(e)}'}), 500

@app.route('/api/restart', methods=['POST'])
def restart_app():
    import sys
    import os
    import time
    def perform_restart():
        time.sleep(1)
        os.execv(sys.executable, [sys.executable] + sys.argv)
        
    threading.Thread(target=perform_restart).start()
    return jsonify({'status': 'success', 'message': 'Restarting ProMailer backend...'})

import threading
import time

def start_background_threads():
    if os.environ.get('PROMAILER_THREADS_STARTED') == 'true':
        return
    os.environ['PROMAILER_THREADS_STARTED'] = 'true'
    
    def run_campaign():
        print("[ProMailer] Starting outreach campaign background thread...")
        time.sleep(5)
        from main import process_pipeline
        while True:
            state = 'running'
            if os.path.exists("campaign_state.txt"):
                try:
                    with open("campaign_state.txt", "r") as f:
                        state = f.read().strip().lower()
                except Exception:
                    pass
            if state == 'running':
                try:
                    process_pipeline()
                except Exception as e:
                    print(f"[ProMailer] Campaign thread error: {e}")
            time.sleep(30)
            
    def run_reply_detector():
        print("[ProMailer] Starting reply detector background thread...")
        time.sleep(10)
        from reply_detector import check_for_replies
        while True:
            state = 'running'
            if os.path.exists("campaign_state.txt"):
                try:
                    with open("campaign_state.txt", "r") as f:
                        state = f.read().strip().lower()
                except Exception:
                    pass
            if state == 'running':
                try:
                    check_for_replies()
                except Exception as e:
                    print(f"[ProMailer] Reply detector thread error: {e}")
            time.sleep(900) # 15 minutes
            
    threading.Thread(target=run_campaign, daemon=True).start()
    threading.Thread(target=run_reply_detector, daemon=True).start()

# Launch background threads unconditionally on import/startup
start_background_threads()

if __name__ == '__main__':
    # Launch Flask on port 5050
    app.run(port=5050, debug=True)
