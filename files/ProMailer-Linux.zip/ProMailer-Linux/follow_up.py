#!/usr/bin/env python3
"""
ProMailer - Follow-up Engine
Handles scheduled follow-ups for prospects who haven't replied

THREAD-SAFE: Uses locks for shared state
NO CIRCULAR IMPORTS: send_email passed as parameter
CROSS-PLATFORM: Works on macOS, Windows, Linux
"""

import sqlite3
import time
import threading
from datetime import datetime, timedelta
from typing import Optional, Dict, List, Callable

from config import config
from logger import get_logger

logger = get_logger(__name__)

# Thread-safe followup state
_state_lock = threading.RLock()
_followup_state = {
    'running': False,
    'followup_thread': None,
}


def get_db_connection() -> sqlite3.Connection:
    """Get database connection with WAL mode enabled"""
    conn = sqlite3.connect(config.db_path, timeout=30.0)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.row_factory = sqlite3.Row
    return conn


def get_prospects_needing_followup() -> List[Dict]:
    """
    Get leads that:
    1. Are in 'sent' status (not replied yet)
    2. Last sent >= followup_days ago
    3. Haven't exceeded max followups
    """
    try:
        cutoff_date = datetime.now() - timedelta(days=config.followup_days)
        cutoff_str = cutoff_date.isoformat()

        with get_db_connection() as conn:
            cursor = conn.execute("""
                SELECT id, company_name AS business_name, contact_name, contact_email AS email, website, 
                       practice_areas, sent_at AS last_sent, followup_count
                FROM leads
                WHERE status = 'sent'
                AND reply_received_at IS NULL
                AND sent_at <= ?
                AND followup_count < ?
                ORDER BY sent_at ASC
            """, (cutoff_str, config.max_followups))
            rows = cursor.fetchall()
            return [dict(row) for row in rows]
    except Exception as e:
        logger.error(f"Failed to get prospects needing followup: {e}")
        return []


def update_followup_count(prospect_id: int) -> None:
    """Increment followup count and update sent_at timestamp"""
    try:
        with get_db_connection() as conn:
            conn.execute("""
                UPDATE leads
                SET followup_count = followup_count + 1,
                    sent_at = ?
                WHERE id = ?
            """, (datetime.now().isoformat(), prospect_id))
            conn.commit()
        logger.debug(f"Updated followup count for lead {prospect_id}")
    except Exception as e:
        logger.error(f"Failed to update followup count: {e}")


def generate_followup_email(prospect: Dict, original_subject: str = "") -> tuple:
    """Generate follow-up email using LLM or fallback"""
    try:
        from llm_client import get_llm_client
        llm = get_llm_client()
        
        if not llm.is_available():
            raise Exception("LLM provider not available")
        
        subject, body = llm.generate_followup(
            business_name=prospect['business_name'],
            contact_name=prospect.get('contact_name'),
            followup_number=prospect['followup_count'] + 1,
            original_subject=original_subject
        )
        logger.info(f"Generated followup #{prospect['followup_count'] + 1} for {prospect['business_name']}")
        return subject, body
        
    except Exception as e:
        logger.warning(f"LLM followup failed, using fallback: {e}")
        # Simple fallback
        subject = f"Following up - {original_subject}"
        body = f"""Hi {prospect.get('contact_name') or 'there'},

Just wanted to follow up on my previous message about {prospect['business_name']}.

Would you have a few minutes to discuss?

Best regards,
{config.sender_name or 'ProMailer'}"""
        
        return subject[:100], body.strip()


def _followup_loop(send_email_func: Callable) -> None:
    """
    Main follow-up loop - runs in background thread
    
    Args:
        send_email_func: Callable that sends email (from main module)
    """
    logger.info(f"Follow-up engine started (days: {config.followup_days}, max: {config.max_followups})")

    try:
        while True:
            with _state_lock:
                if not _followup_state['running']:
                    break
            
            try:
                # Check for prospects needing followup
                prospects = get_prospects_needing_followup()

                if prospects:
                    logger.info(f"Found {len(prospects)} prospect(s) needing followup")

                    for prospect in prospects:
                        with _state_lock:
                            if not _followup_state['running']:
                                break

                        try:
                            logger.info(f"Sending followup to {prospect['business_name']} "
                                      f"(attempt {prospect['followup_count'] + 1}/{config.max_followups})")
                            
                            # Get original email subject (simplified)
                            original_subject = f"Regarding {prospect['business_name']}"
                            subject, body = generate_followup_email(prospect, original_subject)

                            # Send using provided function
                            success = send_email_func(prospect['email'], subject, body)

                            if success:
                                update_followup_count(prospect['id'])
                                logger.info(f"Sent followup #{prospect['followup_count'] + 1} to {prospect['business_name']}")
                            else:
                                logger.error(f"Failed to send followup to {prospect['business_name']}")

                            # Respect cooldown between followups
                            time.sleep(config.cooldown_seconds)
                            
                        except Exception as e:
                            logger.error(f"Error sending followup: {e}", exc_info=True)
                            continue
                else:
                    # No followups needed, check every hour
                    logger.debug("No followups needed. Sleeping...")
                    time.sleep(3600)

            except Exception as e:
                logger.error(f"Follow-up loop error: {e}", exc_info=True)
                time.sleep(60)

    except Exception as e:
        logger.error(f"Follow-up thread fatal error: {e}", exc_info=True)
    finally:
        logger.info("Follow-up engine stopped")


def start_followup_engine(send_email_func: Callable) -> bool:
    """
    Start follow-up engine in background thread
    
    Args:
        send_email_func: Function to call for sending emails (from main module)
    
    Returns:
        True if started, False if already running
    """
    with _state_lock:
        if _followup_state['running']:
            logger.warning("Follow-up engine already running")
            return False
        
        _followup_state['running'] = True
        thread = threading.Thread(
            target=_followup_loop, 
            args=(send_email_func,),
            daemon=True, 
            name="ProMailer-Followup"
        )
        _followup_state['followup_thread'] = thread
        thread.start()
    
    logger.info("Follow-up engine started")
    return True


def stop_followup_engine() -> bool:
    """Signal follow-up engine to stop. Returns True if was running."""
    with _state_lock:
        if not _followup_state['running']:
            logger.warning("Follow-up engine not running")
            return False
        
        _followup_state['running'] = False
    
    logger.info("Follow-up stop signal sent")
    return True


def is_followup_running() -> bool:
    """Check if follow-up engine is currently running"""
    with _state_lock:
        return _followup_state['running']


if __name__ == "__main__":
    # For testing standalone - need to provide a send_email function
    def dummy_send(email, subject, body):
        print(f"Would send to {email}: {subject}")
        return True
    
    logger.info("Starting follow-up engine in foreground...")
    start_followup_engine(dummy_send)
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        stop_followup_engine()
        logger.info("Shutdown complete")
