import os
import requests
from dotenv import load_dotenv

load_dotenv()

GREEN  = "\033[92m"
YELLOW = "\033[93m"
RED    = "\033[91m"
RESET  = "\033[0m"

def generate_text(prompt: str, system_prompt: str = None) -> str:
    """
    Unified LLM text generation with graceful cascade fallback.
    Tries the configured provider first, then falls back to any
    other available provider before raising a user-friendly error.
    """
    load_dotenv()
    provider = os.getenv("LLM_PROVIDER", "ollama").lower().strip()

    # Build ordered list: configured provider first, then fallbacks
    all_providers = ["ollama", "openai", "anthropic", "google", "groq", "deepseek", "custom"]
    order = [provider] + [p for p in all_providers if p != provider]

    last_error = None
    for attempt in order:
        try:
            if attempt == "ollama":
                result = _generate_ollama(prompt)
            elif attempt == "openai":
                result = _generate_openai(prompt, system_prompt)
            elif attempt == "anthropic":
                result = _generate_anthropic(prompt, system_prompt)
            elif attempt == "google":
                result = _generate_google(prompt, system_prompt)
            elif attempt == "groq":
                result = _generate_groq(prompt, system_prompt)
            elif attempt == "deepseek":
                result = _generate_deepseek(prompt, system_prompt)
            elif attempt == "custom":
                result = _generate_custom(prompt, system_prompt)
            else:
                continue

            # If we fell back to a different provider, log it clearly
            if attempt != provider:
                print(f"{YELLOW}[ProMailer] Notice: '{provider}' unavailable — used '{attempt}' as fallback.{RESET}")
            return result

        except _SkipProvider:
            # Provider has no credentials configured — skip silently
            continue
        except Exception as e:
            last_error = e
            print(f"{YELLOW}[ProMailer] Provider '{attempt}' failed: {e}{RESET}")
            continue

    # All providers exhausted
    print(f"\n{RED}[ProMailer] ✗ All AI providers failed. Cannot generate email.{RESET}")
    print(f"{YELLOW}[ProMailer] → Open Settings in Dashboard to configure your API keys.{RESET}\n")
    raise RuntimeError(
        "No AI provider available. Check your settings in the dashboard to fix your configuration."
    )


class _SkipProvider(Exception):
    """Raised when a provider has no credentials — skip without logging."""
    pass


def _generate_ollama(prompt: str) -> str:
    ollama_url   = os.getenv("OLLAMA_URL",   "http://localhost:11434/api/generate")
    ollama_model = os.getenv("OLLAMA_MODEL", "llama3.2:3b")

    payload = {"model": ollama_model, "prompt": prompt, "stream": False}

    try:
        response = requests.post(ollama_url, json=payload, timeout=60)
        response.raise_for_status()
        return response.json().get("response", "").strip()
    except requests.exceptions.ConnectionError:
        raise Exception("Ollama is not running. Start Ollama.app or install from https://ollama.com")
    except requests.exceptions.Timeout:
        raise Exception("Ollama timed out. The model may still be loading — try again in a moment.")
    except Exception as e:
        raise Exception(f"Ollama error: {e}")


def _generate_openai_compatible(prompt: str, system_prompt: str, api_key_env: str, model_env: str, default_model: str, default_base_url: str) -> str:
    api_key = os.getenv(api_key_env, "").strip()
    if not api_key:
        raise _SkipProvider(f"No {api_key_env} configured.")

    model = os.getenv(model_env, default_model).strip()
    
    # For custom, let's read the base URL dynamically
    if api_key_env == "LLM_CUSTOM_API_KEY":
        base_url = os.getenv("LLM_CUSTOM_BASE_URL", default_base_url).strip()
        if not base_url:
            base_url = default_base_url
    else:
        base_url = default_base_url
        
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt or "You are a professional outreach assistant."},
            {"role": "user",   "content": prompt}
        ],
        "temperature": 0.7
    }

    try:
        response = requests.post(
            f"{base_url.rstrip('/')}/chat/completions",
            headers=headers, json=payload, timeout=30
        )
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"].strip()
    except requests.exceptions.HTTPError as e:
        err_msg = ""
        try:
            err_msg = response.json().get("error", {}).get("message", "")
        except Exception:
            pass
        raise Exception(f"{api_key_env.replace('_API_KEY', '')} API error: {err_msg or e}")
    except Exception as e:
        raise Exception(f"{api_key_env.replace('_API_KEY', '')} error: {e}")


def _generate_openai(prompt: str, system_prompt: str = None) -> str:
    return _generate_openai_compatible(
        prompt, system_prompt,
        api_key_env="OPENAI_API_KEY",
        model_env="OPENAI_MODEL",
        default_model="gpt-4o-mini",
        default_base_url="https://api.openai.com/v1"
    )


def _generate_anthropic(prompt: str, system_prompt: str = None) -> str:
    api_key = os.getenv("ANTHROPIC_API_KEY", "").strip()
    if not api_key:
        raise _SkipProvider("No ANTHROPIC_API_KEY configured.")

    model = os.getenv("ANTHROPIC_MODEL", "claude-3-5-haiku-20241022")
    headers = {
        "x-api-key": api_key,
        "anthropic-version": "2023-06-01",
        "Content-Type": "application/json"
    }
    payload = {
        "model": model,
        "max_tokens": 1024,
        "messages": [{"role": "user", "content": prompt}]
    }
    if system_prompt:
        payload["system"] = system_prompt

    try:
        response = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers=headers, json=payload, timeout=30
        )
        response.raise_for_status()
        return response.json()["content"][0]["text"].strip()
    except requests.exceptions.HTTPError as e:
        err_msg = ""
        try:
            err_msg = response.json().get("error", {}).get("message", "")
        except Exception:
            pass
        raise Exception(f"Anthropic API error: {err_msg or e}")
    except Exception as e:
        raise Exception(f"Anthropic error: {e}")


def _generate_google(prompt: str, system_prompt: str = None) -> str:
    api_key = os.getenv("GOOGLE_API_KEY", "").strip()
    if not api_key:
        raise _SkipProvider("No GOOGLE_API_KEY configured.")

    model = os.getenv("GOOGLE_MODEL", "gemini-1.5-flash").strip()
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key}"
    headers = {"Content-Type": "application/json"}
    
    payload = {
        "contents": [{"parts": [{"text": prompt}]}]
    }
    if system_prompt:
        payload["systemInstruction"] = {"parts": [{"text": system_prompt}]}

    try:
        response = requests.post(url, headers=headers, json=payload, timeout=30)
        response.raise_for_status()
        res_data = response.json()
        return res_data["candidates"][0]["content"]["parts"][0]["text"].strip()
    except Exception as e:
        raise Exception(f"Google Gemini error: {e}")


def _generate_groq(prompt: str, system_prompt: str = None) -> str:
    return _generate_openai_compatible(
        prompt, system_prompt,
        api_key_env="GROQ_API_KEY",
        model_env="GROQ_MODEL",
        default_model="llama-3.3-70b-versatile",
        default_base_url="https://api.groq.com/openai/v1"
    )


def _generate_deepseek(prompt: str, system_prompt: str = None) -> str:
    return _generate_openai_compatible(
        prompt, system_prompt,
        api_key_env="DEEPSEEK_API_KEY",
        model_env="DEEPSEEK_MODEL",
        default_model="deepseek-chat",
        default_base_url="https://api.deepseek.com/v1"
    )


def _generate_custom(prompt: str, system_prompt: str = None) -> str:
    return _generate_openai_compatible(
        prompt, system_prompt,
        api_key_env="LLM_CUSTOM_API_KEY",
        model_env="LLM_CUSTOM_MODEL",
        default_model="gpt-3.5-turbo",
        default_base_url="https://api.openai.com/v1"
    )
