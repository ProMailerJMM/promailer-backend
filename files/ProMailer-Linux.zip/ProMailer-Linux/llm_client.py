#!/usr/bin/env python3
"""
ProMailer - Multi-Provider LLM Client
Supports: OpenAI, Anthropic, Groq, DeepSeek, Google Gemini, Custom (OpenAI-compatible)

THREAD-SAFE: Uses singleton pattern with locks
GRACEFUL FALLBACK: All API errors have fallbacks
CROSS-PLATFORM: Works on macOS, Windows, Linux
"""

import json
import threading
from typing import Optional, Tuple, Dict, Any
import requests

from config import config
from logger import get_logger

logger = get_logger(__name__)


class LLMClient:
    """Unified client for multiple LLM providers with graceful fallback"""

    def __init__(self):
        self.provider = config.llm_provider
        self.api_key = self._get_api_key()
        self.model = self._get_model()
        self.base_url = self._get_base_url()
        self._available = self.api_key is not None

        logger.info(f"LLM Client initialized: provider={self.provider}, model={self.model}, available={self._available}")

    def is_available(self) -> bool:
        """Check if LLM provider is configured and available"""
        return self._available

    def _get_api_key(self) -> Optional[str]:
        """Get API key based on selected provider"""
        key_map = {
            'openai': config.openai_api_key,
            'anthropic': config.anthropic_api_key,
            'groq': config.groq_api_key,
            'deepseek': config.deepseek_api_key,
            'google': config.google_api_key,
            'custom': config.custom_llm_api_key,
            'ollama': None  # Ollama doesn't need API key
        }
        return key_map.get(self.provider)

    def _get_model(self) -> str:
        """Get default model for selected provider"""
        models = {
            'openai': 'gpt-4o-mini',
            'anthropic': 'claude-3-5-haiku-20241022',
            'groq': 'llama3-8b-8192',
            'deepseek': 'deepseek-chat',
            'google': 'gemini-1.5-flash',
            'ollama': 'llama2',
            'custom': config.custom_llm_model or 'gpt-3.5-turbo'
        }
        return models.get(self.provider, 'gpt-3.5-turbo')

    def _get_base_url(self) -> str:
        """Get API base URL for selected provider"""
        urls = {
            'openai': 'https://api.openai.com/v1',
            'anthropic': 'https://api.anthropic.com/v1',
            'groq': 'https://api.groq.com/openai/v1',
            'deepseek': 'https://api.deepseek.com/v1',
            'google': 'https://generativelanguage.googleapis.com/v1',
            'ollama': 'http://localhost:11434/api',
            'custom': config.custom_llm_base_url or 'https://api.openai.com/v1'
        }
        return urls.get(self.provider, 'https://api.openai.com/v1')

    def _call_openai_compatible(self, messages: list, temperature: float = 0.7) -> Optional[str]:
        """Call any OpenAI-compatible API endpoint with error handling"""
        if not self.api_key:
            logger.error(f"No API key for {self.provider}")
            return None

        headers = {
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json'
        }

        # Anthropic uses different header format
        if self.provider == 'anthropic':
            headers = {
                'x-api-key': self.api_key,
                'anthropic-version': '2023-06-01',
                'Content-Type': 'application/json'
            }
            payload = {
                'model': self.model,
                'messages': messages,
                'max_tokens': 500,
                'temperature': temperature
            }
            url = f"{self.base_url}/messages"
        else:
            payload = {
                'model': self.model,
                'messages': messages,
                'temperature': temperature,
                'max_tokens': 500
            }
            url = f"{self.base_url}/chat/completions"

        try:
            response = requests.post(url, headers=headers, json=payload, timeout=30)
            response.raise_for_status()

            if self.provider == 'anthropic':
                content = response.json().get('content', [])
                if content and isinstance(content, list):
                    return content[0].get('text', '')
                return ''
            else:
                choices = response.json().get('choices', [])
                if choices and len(choices) > 0:
                    return choices[0]['message']['content']
                return ''

        except requests.exceptions.Timeout:
            logger.error(f"LLM API timeout: {self.provider}")
            return None
        except requests.exceptions.ConnectionError:
            logger.error(f"LLM API connection failed: {self.provider}")
            return None
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 401:
                logger.error(f"Invalid API key for {self.provider}")
            elif e.response.status_code == 429:
                logger.warning(f"Rate limited by {self.provider} (free tier may have limits)")
            else:
                logger.error(f"LLM API error {e.response.status_code}: {e}")
            return None
        except Exception as e:
            logger.error(f"LLM API call failed: {e}")
            return None

    def _call_google_gemini(self, prompt: str) -> Optional[str]:
        """Call Google Gemini API (different format from OpenAI-compatible)"""
        if not self.api_key:
            logger.error("No Google API key")
            return None

        url = f"{self.base_url}/models/{self.model}:generateContent?key={self.api_key}"
        payload = {
            'contents': [{
                'parts': [{'text': prompt}]
            }]
        }

        try:
            response = requests.post(url, json=payload, timeout=30)
            response.raise_for_status()
            
            data = response.json()
            candidates = data.get('candidates', [])
            if candidates and 'content' in candidates[0]:
                parts = candidates[0]['content'].get('parts', [])
                if parts and 'text' in parts[0]:
                    return parts[0]['text']
            return None
            
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 429:
                logger.warning("Google Gemini rate limited")
            else:
                logger.error(f"Google Gemini API error: {e}")
            return None
        except Exception as e:
            logger.error(f"Google Gemini API failed: {e}")
            return None

    def _extract_json_from_response(self, response_text: str) -> Optional[Dict]:
        """
        Safely extract JSON from response, handling various formats
        """
        if not response_text:
            return None
        
        try:
            # Try direct JSON parsing first
            return json.loads(response_text)
        except json.JSONDecodeError:
            pass
        
        try:
            # Try to find JSON block in response (common with Gemini)
            import re
            json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
        except Exception:
            pass
        
        # No JSON found - return None to trigger fallback
        return None

    def generate_outreach(self, business_name: str, contact_name: Optional[str] = None,
                          practice_areas: Optional[str] = None, website: Optional[str] = None,
                          template: Optional[str] = None) -> Tuple[str, str]:
        """Generate personalized outreach email"""
        
        # Use default template if none provided
        if not template:
            template = config.email_template
        
        prompt = f"""You are a professional cold email writer. Personalize this template for the prospect.

TEMPLATE:
{template}

PROSPECT INFO:
- Business: {business_name}
- Contact Name: {contact_name or 'Not provided'}
- Practice Areas: {practice_areas or 'Not provided'}
- Website: {website or 'Not provided'}

RULES:
1. Keep it concise (max 150 words)
2. Sound human, not salesy
3. Use the contact name if provided
4. Return ONLY valid JSON: {{"subject": "Subject line here", "body": "Email body here"}}

Generate the email:"""

        try:
            if not self.is_available():
                raise Exception("LLM not available")
            
            # Call LLM
            if self.provider == 'google':
                result = self._call_google_gemini(prompt)
            else:
                result = self._call_openai_compatible([{'role': 'user', 'content': prompt}])

            if result:
                # Try to parse JSON response
                data = self._extract_json_from_response(result)
                
                if data and 'subject' in data and 'body' in data:
                    subject = str(data.get('subject', ''))[:100]
                    body = str(data.get('body', ''))
                    return subject, body
                else:
                    # JSON parsing failed but we got text - use as body
                    logger.warning(f"LLM response wasn't properly formatted JSON, using as body")
                    return "Checking in", result[:500]

        except Exception as e:
            logger.warning(f"LLM generation failed: {e}")

        # Ultimate fallback: simple placeholder replacement
        subject = f"Quick question regarding {business_name}"
        body = template
        body = body.replace('{company_name}', business_name or 'there')
        body = body.replace('{contact_name}', contact_name or '')
        body = body.replace('{practice_areas}', practice_areas or '')
        body = body.replace('{website}', website or '')
        return subject[:100], body

    def generate_followup(self, business_name: str, contact_name: Optional[str] = None,
                          followup_number: int = 1, original_subject: str = "") -> Tuple[str, str]:
        """Generate follow-up email"""
        
        prompt = f"""Write a short follow-up email (max 100 words).

Context:
- Business: {business_name}
- Contact: {contact_name or 'Not provided'}
- This is followup #{followup_number}
- Original subject: {original_subject}

Tone: Professional, polite, not pushy.

Return JSON: {{"subject": "Subject line", "body": "Email body"}}"""

        try:
            if not self.is_available():
                raise Exception("LLM not available")
            
            if self.provider == 'google':
                result = self._call_google_gemini(prompt)
            else:
                result = self._call_openai_compatible([{'role': 'user', 'content': prompt}])

            if result:
                data = self._extract_json_from_response(result)
                
                if data and 'subject' in data and 'body' in data:
                    subject = str(data.get('subject', ''))[:100]
                    body = str(data.get('body', ''))
                    return subject, body
                else:
                    return "Following up", result[:500]

        except Exception as e:
            logger.warning(f"LLM followup generation failed: {e}")

        # Fallback
        return (f"Following up on {business_name}", 
                f"Hi {contact_name or 'there'},\n\nJust following up on my previous message.\n\nBest")

    def test_connection(self) -> Dict[str, Any]:
        """Test if API key works and return status"""
        if not self.is_available():
            return {
                'success': False, 
                'message': f'No API key configured for {self.provider}'
            }
        
        test_prompt = "Say 'OK' in one word."

        try:
            if self.provider == 'google':
                result = self._call_google_gemini(test_prompt)
            else:
                result = self._call_openai_compatible([{'role': 'user', 'content': test_prompt}])

            if result and len(result.strip()) > 0:
                return {
                    'success': True, 
                    'message': f'✅ Connected to {self.provider} ({self.model})'
                }
            else:
                return {
                    'success': False, 
                    'message': 'API returned empty response'
                }

        except Exception as e:
            error_msg = str(e)[:100]
            return {
                'success': False, 
                'message': f'Connection failed: {error_msg}'
            }


# Singleton instance with thread safety
_client = None
_client_lock = threading.Lock()


def get_llm_client() -> LLMClient:
    """Get or create default LLM client (singleton, thread-safe)"""
    global _client
    
    if _client is None:
        with _client_lock:
            if _client is None:
                _client = LLMClient()
    
    return _client


if __name__ == "__main__":
    # Test the LLM client
    client = get_llm_client()
    
    logger.info(f"Testing LLM client: {client.provider}")
    
    result = client.test_connection()
    logger.info(f"Connection test: {result}")
    
    if result['success']:
        subject, body = client.generate_outreach(
            business_name="Example Law Firm",
            contact_name="John Doe",
            practice_areas="Criminal Defense"
        )
        logger.info(f"Generated email:\nSubject: {subject}\nBody: {body[:100]}...")
