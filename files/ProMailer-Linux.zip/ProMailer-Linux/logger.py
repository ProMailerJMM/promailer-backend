"""
ProMailer — Structured Logging Module

Provides consistent logging across the application with file rotation,
log levels, and colored console output.
"""

import logging
import logging.handlers
import os
from pathlib import Path
from datetime import datetime

# ANSI color codes for terminal output
_COLORS = {
    'DEBUG': '\033[36m',      # Cyan
    'INFO': '\033[92m',       # Green
    'WARNING': '\033[93m',    # Yellow
    'ERROR': '\033[91m',      # Red
    'CRITICAL': '\033[91m',   # Red
    'RESET': '\033[0m',
    'BOLD': '\033[1m',
}

# Determine log directory (next to executable or in current directory)
def _get_log_dir():
    if getattr(__import__('sys'), 'frozen', False):
        # Running as PyInstaller executable
        log_dir = Path(__import__('sys').executable).parent / 'logs'
    else:
        # Running from source
        log_dir = Path(__file__).parent / 'logs'
    
    log_dir.mkdir(exist_ok=True)
    return log_dir


class _ColoredFormatter(logging.Formatter):
    """Custom formatter with colored output for console."""
    
    def format(self, record):
        if record.levelname in _COLORS:
            color = _COLORS[record.levelname]
            reset = _COLORS['RESET']
            record.levelname = f"{color}{record.levelname}{reset}"
            record.name = f"{_COLORS['BOLD']}{record.name}{reset}"
        return super().format(record)


def setup_logging(name: str = 'ProMailer', level=logging.INFO):
    """
    Configure logging for a module.
    
    Args:
        name: Logger name (usually __name__)
        level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
    
    Returns:
        Logger instance
    """
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # Avoid duplicate handlers if called multiple times
    if logger.handlers:
        return logger
    
    # ── Console Handler (colored, brief) ──────────────────────────────────────
    console_handler = logging.StreamHandler()
    console_handler.setLevel(level)
    console_formatter = _ColoredFormatter(
        '[%(name)s] %(levelname)s — %(message)s'
    )
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)
    
    # ── File Handler (with rotation) ──────────────────────────────────────────
    log_dir = _get_log_dir()
    log_file = log_dir / f'{name}_{datetime.now().strftime("%Y%m%d")}.log'
    
    try:
        file_handler = logging.handlers.RotatingFileHandler(
            str(log_file),
            maxBytes=10 * 1024 * 1024,  # 10 MB
            backupCount=5
        )
        file_handler.setLevel(logging.DEBUG)  # Always log DEBUG to file
        file_formatter = logging.Formatter(
            '%(asctime)s [%(name)s] %(levelname)s — %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        file_handler.setFormatter(file_formatter)
        logger.addHandler(file_handler)
    except Exception as e:
        logger.warning(f"Could not set up file logging: {e}")
    
    return logger


# ═════════════════════════════════════════════════════════════════════════════
# Module-level logger (used throughout ProMailer)
# ═════════════════════════════════════════════════════════════════════════════

logger = setup_logging('ProMailer', logging.INFO)


# Convenience functions for common use
def debug(msg: str):
    """Log debug message"""
    logger.debug(msg)


def info(msg: str):
    """Log info message"""
    logger.info(msg)


def warning(msg: str):
    """Log warning message"""
    logger.warning(msg)


def error(msg: str):
    """Log error message"""
    logger.error(msg)


def critical(msg: str):
    """Log critical message"""
    logger.critical(msg)


def exception(msg: str):
    """Log exception with traceback"""
    logger.exception(msg)


def get_logger(name: str = 'ProMailer', level=logging.INFO):
    """Alias for setup_logging to support legacy imports"""
    return setup_logging(name, level)


if __name__ == "__main__":
    # Test logging
    logger = setup_logging('ProMailer_Test', logging.DEBUG)
    
    logger.debug("This is a debug message")
    logger.info("This is an info message")
    logger.warning("This is a warning message")
    logger.error("This is an error message")
    logger.critical("This is a critical message")
    
    print(f"\n✓ Logs are being written to: {_get_log_dir()}")
