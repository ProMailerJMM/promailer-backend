#!/usr/bin/env python3
"""
ProMailer - Main Campaign Engine
Responsible for: sending emails, respecting rate limits, tracking replies

THREAD-SAFE: Uses locks for all shared state
CROSS-PLATFORM: Works on macOS, Windows, Linux
"""

import smtplib
import time
import sqlite3
import threading
from email.message import EmailMessage
from email.utils import formatdate, make_msgid
from datetime import datetime, date
from typing import Optional, Dict, List, Tuple

from config import config
from logger import get_logger

logger = get_logger(__name__)

# Thread-safe campaign state
_state_lock = threading.RLock()
_campaign_state = {
    'running': False,
    'last_send_time': None,
    'daily_sent_count': 0,
    'last_reset_date': date.today(),
    'campaign_thread': None,
}


def get_db_connection() -> sqlite3.Connection:
    """Get database connection with WAL mode enabled"""
    conn = sqlite3.connect(config.db_path, timeout=30.0)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.row_factory = sqlite3.Row
    return conn


def _reset_daily_counter_if_needed() -> None:
    """Reset daily send count if it's a new day (thread-safe)"""
    with _state_lock:
        today = date.today()
        if today != _campaign_state['last_reset_date']:
            _campaign_state['daily_sent_count'] = 0
            _campaign_state['last_reset_date'] = today
            logger.info(f"Daily counter reset. New day: {today}")


def _can_send_today() -> bool:
    """Check if daily limit has been reached (thread-safe)"""
    with _state_lock:
        return _campaign_state['daily_sent_count'] < config.daily_send_limit


def _can_send_now() -> bool:
    """Check cooldown period between sends (thread-safe)"""
    with _state_lock:
        if _campaign_state['last_send_time'] is None:
            return True
        elapsed = time.time() - _campaign_state['last_send_time']
        return elapsed >= config.cooldown_seconds


def _update_send_time() -> None:
    """Update last send time (thread-safe)"""
    with _state_lock:
        _campaign_state['last_send_time'] = time.time()
        _campaign_state['daily_sent_count'] += 1


def get_next_prospect() -> Optional[Dict]:
    """Get the next lead/prospect that needs an email sent"""
    try:
        with get_db_connection() as conn:
            cursor = conn.execute("""
                SELECT id, company_name AS business_name, contact_name, contact_email AS email, website, practice_areas
                FROM leads
                WHERE status = 'pending'
                AND contact_email IS NOT NULL
                AND contact_email != ''
                ORDER BY created_at ASC
                LIMIT 1
            """)
            row = cursor.fetchone()
            return dict(row) if row else None
    except Exception as e:
        logger.error(f"Failed to get next prospect: {e}")
        return None


def mark_prospect_sent(prospect_id: int, email_body: str = "") -> None:
    """Mark lead as sent in database"""
    try:
        with get_db_connection() as conn:
            conn.execute("""
                UPDATE leads
                SET status = 'sent', sent_at = ?, generated_email = ?
                WHERE id = ?
            """, (datetime.now().isoformat(), email_body, prospect_id))
            conn.commit()
        logger.debug(f"Marked lead {prospect_id} as sent")
    except Exception as e:
        logger.error(f"Failed to mark lead {prospect_id} as sent: {e}")


def mark_prospect_failed(prospect_id: int, error: str) -> None:
    """Mark lead as failed with error"""
    try:
        with get_db_connection() as conn:
            conn.execute("""
                UPDATE leads
                SET status = 'failed', error_message = ?
                WHERE id = ?
            """, (error[:500], prospect_id))
            conn.commit()
        logger.warning(f"Lead {prospect_id} failed: {error[:100]}")
    except Exception as e:
        logger.error(f"Failed to mark lead {prospect_id} as failed: {e}")


def has_replied(prospect_id: int) -> bool:
    """Check if lead has replied (campaign should pause for them)"""
    try:
        with get_db_connection() as conn:
            cursor = conn.execute("""
                SELECT reply_received_at FROM leads WHERE id = ?
            """, (prospect_id,))
            row = cursor.fetchone()
            return row and row['reply_received_at'] is not None
    except Exception as e:
        logger.error(f"Failed to check reply status: {e}")
        return False


def get_sends_today() -> int:
    """Get the number of emails sent today from the database"""
    try:
        with get_db_connection() as conn:
            today = date.today().strftime('%Y-%m-%d')
            cursor = conn.execute("""
                SELECT COUNT(*) FROM leads 
                WHERE status IN ('sent', 'replied') 
                AND sent_at LIKE ?
            """, (f"{today}%",))
            row = cursor.fetchone()
            return row[0] if row else 0
    except Exception as e:
        logger.error(f"Failed to get sends today: {e}")
        return 0


def personalize_email(prospect: Dict, template: str = "") -> Tuple[str, str]:
    """Use LLM to personalize email template or fallback to simple placeholder replacement"""
    
    # Use default template if none provided
    if not template:
        template = config.email_template
    
    try:
        # Try LLM generation
        from llm_client import get_llm_client
        llm = get_llm_client()
        
        if not llm.is_available():
            raise Exception("LLM provider not available")
        
        subject, body = llm.generate_outreach(
            business_name=prospect['business_name'],
            contact_name=prospect.get('contact_name'),
            practice_areas=prospect.get('practice_areas'),
            website=prospect.get('website'),
            template=template
        )
        logger.info(f"Generated personalized email for {prospect['business_name']}")
        return subject, body
        
    except Exception as e:
        logger.warning(f"LLM personalization failed, using fallback: {e}")
        # Fallback: simple placeholder replacement
        subject = "Quick question"
        body = template
        body = body.replace('{company_name}', prospect['business_name'] or 'there')
        body = body.replace('{contact_name}', prospect.get('contact_name') or '')
        body = body.replace('{practice_areas}', prospect.get('practice_areas') or '')
        body = body.replace('{website}', prospect.get('website') or '')
        return subject[:100], body


def send_email(recipient_email: str, subject: str, body: str) -> bool:
    """Send email via SMTP. Returns True if successful."""
    try:
        # Validate inputs
        if not recipient_email or '@' not in recipient_email:
            logger.error(f"Invalid email address: {recipient_email}")
            return False
        
        if not config.smtp_user or not config.smtp_password:
            logger.error("SMTP credentials not configured")
            return False
        
        msg = EmailMessage()
        msg['From'] = f"{config.sender_name} <{config.sender_email}>" if config.sender_name else config.sender_email
        msg['To'] = recipient_email
        msg['Subject'] = subject
        msg['Date'] = formatdate(localtime=True)  # RFC 5321 compliant
        msg['Message-ID'] = make_msgid(domain=config.smtp_host)
        msg.set_content(body)

        # Connect to SMTP
        if config.smtp_port == 465:
            # SSL connection
            server = smtplib.SMTP_SSL(config.smtp_host, config.smtp_port, timeout=10)
        else:
            # TLS connection
            server = smtplib.SMTP(config.smtp_host, config.smtp_port, timeout=10)
            server.starttls()
        
        server.login(config.smtp_user, config.smtp_password)
        server.send_message(msg)
        server.quit()

        logger.info(f"Email sent to {recipient_email}")
        return True
        
    except smtplib.SMTPAuthenticationError as e:
        logger.error(f"SMTP authentication failed: {e}")
        return False
    except smtplib.SMTPException as e:
        logger.error(f"SMTP error: {e}")
        return False
    except Exception as e:
        logger.error(f"Failed to send to {recipient_email}: {e}", exc_info=True)
        return False


def process_prospect(prospect: Dict) -> None:
    """Process a single prospect: personalize and send"""
    
    try:
        # Check if already replied (campaign paused for this lead)
        if has_replied(prospect['id']):
            logger.info(f"Skipping {prospect['business_name']} - already replied")
            return

        # Generate personalized email
        subject, body = personalize_email(prospect)

        # Send
        success = send_email(prospect['email'], subject, body)

        if success:
            mark_prospect_sent(prospect['id'], body)
            _update_send_time()
            
            with _state_lock:
                count = _campaign_state['daily_sent_count']
                limit = config.daily_send_limit
            
            logger.info(f"Sent to {prospect['business_name']} ({count}/{limit} today)")
        else:
            mark_prospect_failed(prospect['id'], "SMTP send failed")
            
    except Exception as e:
        logger.error(f"Error processing prospect {prospect['id']}: {e}", exc_info=True)
        mark_prospect_failed(prospect['id'], str(e)[:100])


def _campaign_loop() -> None:
    """Main campaign loop - runs in background thread"""
    logger.info("Campaign engine started")

    try:
        while True:
            with _state_lock:
                if not _campaign_state['running']:
                    break
            
            # Check campaign_state.txt to see if paused by the user
            import os
            if os.path.exists("campaign_state.txt"):
                try:
                    with open("campaign_state.txt", "r") as f:
                        if f.read().strip().lower() == "paused":
                            logger.info("Campaign paused via campaign_state.txt. Stopping campaign loop thread.")
                            with _state_lock:
                                _campaign_state['running'] = False
                            break
                except Exception:
                    pass
            
            try:
                _reset_daily_counter_if_needed()

                # Rate limiting checks
                if not _can_send_today():
                    logger.debug(f"Daily limit reached ({config.daily_send_limit}). Sleeping...")
                    time.sleep(300)  # Check every 5 minutes
                    continue

                if not _can_send_now():
                    with _state_lock:
                        last_send = _campaign_state['last_send_time'] or 0
                    
                    wait_time = config.cooldown_seconds - (time.time() - last_send)
                    if wait_time > 0:
                        logger.debug(f"Cooldown: waiting {wait_time:.0f} seconds")
                        time.sleep(min(wait_time, 60))
                    continue

                # Get next prospect
                prospect = get_next_prospect()
                if not prospect:
                    logger.debug("No pending prospects. Sleeping...")
                    time.sleep(60)
                    continue

                # Process
                process_prospect(prospect)

            except Exception as e:
                logger.error(f"Campaign loop error: {e}", exc_info=True)
                time.sleep(30)

    except Exception as e:
        logger.error(f"Campaign thread fatal error: {e}", exc_info=True)
    finally:
        logger.info("Campaign engine stopped")


def start_campaign() -> bool:
    """Start the campaign in a background thread. Returns True if started."""
    global _campaign_state
    
    with _state_lock:
        if _campaign_state['running']:
            logger.warning("Campaign already running")
            return False
        
        _campaign_state['running'] = True
        _campaign_state['daily_sent_count'] = get_sends_today()
        _campaign_state['last_reset_date'] = date.today()
        
        thread = threading.Thread(target=_campaign_loop, daemon=True, name="ProMailer-Campaign")
        _campaign_state['campaign_thread'] = thread
        thread.start()
    
    logger.info("Campaign started")
    return True


def stop_campaign() -> bool:
    """Signal campaign to stop. Returns True if was running."""
    with _state_lock:
        if not _campaign_state['running']:
            logger.warning("Campaign not running")
            return False
        
        _campaign_state['running'] = False
    
    logger.info("Campaign stop signal sent")
    return True


def is_campaign_running() -> bool:
    """Check if campaign is currently running"""
    with _state_lock:
        return _campaign_state['running']


def get_campaign_stats() -> Dict:
    """Get current campaign statistics"""
    with _state_lock:
        return {
            'running': _campaign_state['running'],
            'sent_today': _campaign_state['daily_sent_count'],
            'daily_limit': config.daily_send_limit,
            'last_send': _campaign_state['last_send_time'],
        }


def process_pipeline():
    """Legacy wrapper for dashboard.py background thread.
    Ensures that the thread-safe background campaign is running if state is set to running.
    """
    import os
    state = 'running'
    if os.path.exists("campaign_state.txt"):
        try:
            with open("campaign_state.txt", "r") as f:
                state = f.read().strip().lower()
        except Exception:
            pass
            
    if state == 'running':
        if not is_campaign_running():
            logger.info("Auto-starting campaign thread-safe background engine via legacy process_pipeline.")
            start_campaign()


if __name__ == "__main__":
    # For testing standalone
    logger.info("Starting campaign engine in foreground...")
    start_campaign()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        stop_campaign()
        logger.info("Shutdown complete")
