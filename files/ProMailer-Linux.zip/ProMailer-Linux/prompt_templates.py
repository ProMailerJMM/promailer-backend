import json
import os

DEFAULT_SUBJECT = "Quick question regarding {company_name}"
DEFAULT_OLLAMA_PROMPT = """Hi {contact_name},

I came across {company_name} and wanted to introduce you to LexSort — a communication and case management tool built specifically for Ontario criminal defence lawyers, including solo practitioners.

LexSort runs entirely on your own hardware. No cloud. No third party ever touches client data. It automatically ingests your emails and messages, matches them to active matters, and delivers a structured daily brief — saving lawyers up to two days of manual work every two weeks.

LexSort also includes an integrated billing system that tracks time and matter activity automatically, reducing the administrative burden of invoicing so you can focus on your clients.

You can learn more at lexsort.com.

I'd love to show you a quick demo. Prior to any demonstration a standard NDA is required — happy to send that over at your request.

Best regards,

William Commu
Founder, LexSort / Just Me Media
william@justmemedia.ca
647-554-0219
lexsort.com | justmemedia.ca

--
IMPORTANT - Confidential information: This message is intended only for the use of the individual or entity to which it is addressed and may contain information that is privileged, confidential and exempt from disclosure under applicable law. Any other distribution, copying or disclosure is strictly prohibited. If you have received this message in error, please notify us immediately by telephone (647) 554-0219 and return the original."""

OLLAMA_PROMPT = DEFAULT_OLLAMA_PROMPT

FOLLOW_UP_PROMPT = """You are an email formatting assistant.
Output EXACTLY the following email text, substituting the variables below. Do not change any other words, and do not add any conversational text before or after the email.

Hi {contact_name},

Just following up on my note about LexSort.

I'm looking for one Ontario criminal defence lawyer to work closely with me as the product moves toward a wider release — someone whose real practice shapes how it works. It's a paid advisory role, with equity available for the right fit.

Worth a 15-minute call?

William

William Commu
Founder, LexSort / Just Me Media
william@justmemedia.ca
647-554-0219
lexsort.com | justmemedia.ca

--
IMPORTANT - Confidential information: This message is intended only for the use of the individual or entity to which it is addressed and may contain information that is privileged, confidential and exempt from disclosure under applicable law. Any other distribution, copying or disclosure is strictly prohibited. If you have received this message in error, please notify us immediately by telephone (647) 554-0219 and return the original."""

def get_active_template():
    template_path = os.path.join(os.path.dirname(__file__), "templates.json")
    if os.path.exists(template_path):
        try:
            with open(template_path, "r") as f:
                data = json.load(f)
                for t in data:
                    if t.get("active"):
                        return t.get("subject", DEFAULT_SUBJECT), t.get("body", DEFAULT_OLLAMA_PROMPT)
        except Exception as e:
            print(f"Error loading templates: {e}")
    return DEFAULT_SUBJECT, DEFAULT_OLLAMA_PROMPT

def safe_format(template_str, **kwargs):
    import re
    if not template_str:
        return ""
    def repl(match):
        key = match.group(1)
        if key in kwargs:
            return str(kwargs[key])
        return match.group(0)
    return re.sub(r'\{([^{}]+)\}', repl, template_str)
