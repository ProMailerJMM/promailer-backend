import os
import imaplib
import email
import sqlite3
import time
from datetime import datetime
from dotenv import load_dotenv
from database import DB_NAME, update_lead_status

load_dotenv()

GMAIL_USER = os.getenv("GMAIL_USER") or os.getenv("SMTP_USER")
GMAIL_APP_PASSWORD = os.getenv("GMAIL_APP_PASSWORD") or os.getenv("SMTP_PASSWORD")
IMAP_SERVER = os.getenv("IMAP_SERVER", "imap.gmail.com")
try:
    IMAP_PORT = int(os.getenv("IMAP_PORT", "993"))
except (ValueError, TypeError):
    IMAP_PORT = 993

def extract_email_body(msg):
    body = ""
    if msg.is_multipart():
        for part in msg.walk():
            content_type = part.get_content_type()
            content_disposition = str(part.get("Content-Disposition"))
            if content_type == "text/plain" and "attachment" not in content_disposition:
                try:
                    payload = part.get_payload(decode=True)
                    if payload:
                        body = payload.decode(errors='ignore')
                        break
                except Exception:
                    pass
    else:
        try:
            payload = msg.get_payload(decode=True)
            if payload:
                body = payload.decode(errors='ignore')
        except Exception:
            pass
    return body.strip()

def check_for_replies():
    try:
        # Connect to IMAP
        mail = imaplib.IMAP4_SSL(IMAP_SERVER, IMAP_PORT)
        mail.login(GMAIL_USER, GMAIL_APP_PASSWORD)
        mail.select('INBOX')

        # Search for UNSEEN messages (more efficient than fetching entire mailbox)
        status, data = mail.search(None, 'UNSEEN')
        mail_ids = data[0].split()

        if not mail_ids:
            print("[ProMailer] No new unread emails to check.")
            return 0

        conn = sqlite3.connect(DB_NAME, timeout=30.0)
        conn.execute("PRAGMA journal_mode=WAL")
        cursor = conn.cursor()
        
        # Get all emails we've contacted
        cursor.execute("SELECT contact_email, company_name FROM leads WHERE status IN ('sent', 'followed_up')")
        active_leads = {email.lower(): company for email, company in cursor.fetchall()}
        
        replies_found = 0

        for m_id in mail_ids[-20:]:  # Check only the last 20 to avoid huge processing
            try:
                status, data = mail.fetch(m_id, '(RFC822)')
                if not data[0]:
                    continue
                    
                raw_email = data[0][1]
                msg = email.message_from_bytes(raw_email)
                
                from_header = msg.get('From', '')
                # Extract email address from "Name <email@example.com>"
                from_email = email.utils.parseaddr(from_header)[1].lower()
                
                if from_email in active_leads:
                    company_name = active_leads[from_email]
                    print(f"!!! REPLY DETECTED from {company_name} ({from_email}) !!!")
                    
                    # Extract plaintext email body
                    reply_body = extract_email_body(msg)
                    
                    # Update database
                    cursor.execute(
                        "UPDATE leads SET status = 'replied', reply_body = ?, reply_received_at = ? WHERE contact_email = ?",
                        (reply_body, datetime.now(), from_email)
                    )
                    conn.commit()
                    
                    print(f"Notification: {company_name} has replied! Switching to manual mode for this lead.")
                    replies_found += 1
                    
                    # Mark as read after processing
                    mail.store(m_id, '+FLAGS', '\\Seen')
            except Exception as e:
                print(f"[ProMailer] Error processing email {m_id}: {e}")
                continue
                    
        conn.close()
        mail.logout()
        return replies_found

    except Exception as e:
        print(f"Error checking for replies: {e}")
        return 0

if __name__ == "__main__":
    print(f"Starting Reply Detector for {GMAIL_USER}...")
    while True:
        print(f"[{datetime.now().strftime('%H:%M:%S')}] Checking for new replies...")
        found = check_for_replies()
        if found > 0:
            print(f"Processed {found} new replies.")
        else:
            print("No new replies detected.")
            
        print("Waiting 15 minutes for the next check...")
        time.sleep(900) # 15 minutes
