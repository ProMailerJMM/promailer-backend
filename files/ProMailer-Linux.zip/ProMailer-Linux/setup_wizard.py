import os
import sys
import requests
import platform

# ── CLI colour codes ──────────────────────────────────────────────────────────
GREEN  = "\033[92m"
YELLOW = "\033[93m"
RED    = "\033[91m"
BLUE   = "\033[94m"
CYAN   = "\033[96m"
BOLD   = "\033[1m"
RESET  = "\033[0m"

# ── Helpers ───────────────────────────────────────────────────────────────────

def print_header():
    print(f"\n{BOLD}{BLUE}╔══════════════════════════════════════════════════╗{RESET}")
    print(f"{BOLD}{BLUE}║      PROMAILER — SOVEREIGN SETUP WIZARD          ║{RESET}")
    print(f"{BOLD}{BLUE}╚══════════════════════════════════════════════════╝{RESET}")
    print("Welcome to your local-first cold outreach workstation.\n")

def section(title):
    print(f"\n{BOLD}{CYAN}── {title} {'─' * max(0, 46 - len(title))}{RESET}")

def ok(msg):    print(f"{GREEN}  ✓ {msg}{RESET}")
def warn(msg):  print(f"{YELLOW}  ! {msg}{RESET}")
def err(msg):   print(f"{RED}  ✗ {msg}{RESET}")


# ── Provider validators ───────────────────────────────────────────────────────

def validate_openai(key):
    print("  Validating OpenAI key...")
    try:
        r = requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
            json={"model": "gpt-4o-mini", "messages": [{"role": "user", "content": "ping"}], "max_tokens": 1},
            timeout=10
        )
        if r.status_code == 200:
            ok("OpenAI API key is valid.")
            return True
        err(f"OpenAI rejected key: {r.json().get('error',{}).get('message','Unknown error')}")
        return False
    except Exception as e:
        err(f"OpenAI connection error: {e}")
        return False


def validate_anthropic(key):
    print("  Validating Anthropic key...")
    try:
        r = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers={"x-api-key": key, "anthropic-version": "2023-06-01", "Content-Type": "application/json"},
            json={"model": "claude-3-5-haiku-20241022", "max_tokens": 1,
                  "messages": [{"role": "user", "content": "ping"}]},
            timeout=10
        )
        if r.status_code == 200:
            ok("Anthropic API key is valid.")
            return True
        err(f"Anthropic rejected key: {r.json().get('error',{}).get('message','Unknown error')}")
        return False
    except Exception as e:
        err(f"Anthropic connection error: {e}")
        return False


def validate_ollama(url, model):
    print(f"  Connecting to Ollama at {url}...")
    try:
        base = url.replace("/api/generate", "")
        r = requests.get(f"{base}/api/tags", timeout=5)
        if r.status_code == 200:
            ok("Ollama is running.")
            models = [m["name"] for m in r.json().get("models", [])]
            if any(model in m for m in models):
                ok(f"Model '{model}' found locally.")
            else:
                warn(f"Model '{model}' not downloaded yet.")
                warn(f"Run this before starting: ollama pull {model}")
            return True
        err(f"Ollama returned status {r.status_code}.")
        return False
    except Exception:
        warn("Could not reach Ollama. Make sure Ollama.app is running on port 11434.")
        warn("Download Ollama free from: https://ollama.com")
        cont = input("  Continue anyway (you can start Ollama later)? [Y/n]: ").strip().lower()
        return cont != "n"


# ── Main wizard ───────────────────────────────────────────────────────────────

def run_wizard():
    print_header()

    # ── Step 1: SMTP ──────────────────────────────────────────────────────────
    section("1. Configure SMTP Outbox")
    print(f"""
  {CYAN}[1] Gmail SMTP{RESET}   — Requires a 16-character App Password
                  (not your Gmail login password)
                  Guide: myaccount.google.com → Security → App Passwords

  {CYAN}[2] Custom SMTP{RESET}  — SendGrid, Mailgun, Brevo, Resend, Amazon SES, etc.
""")
    smtp_choice = input("  Choose option [1/2] (Default: 1 — Gmail): ").strip()
    if not smtp_choice:
        smtp_choice = "1"

    smtp_server   = "smtp.gmail.com"
    smtp_port     = "587"
    smtp_user     = ""
    smtp_password = ""
    sender_name   = ""
    imap_server   = "imap.gmail.com"
    imap_port     = "993"

    if smtp_choice == "1":
        print(f"\n  {BOLD}Gmail Setup{RESET}")
        print(f"  {YELLOW}Use your Gmail App Password — NOT your Gmail account password.{RESET}")
        print(f"  Create one at: {CYAN}https://myaccount.google.com/apppasswords{RESET}\n")

        while not smtp_user:
            smtp_user = input("  Gmail address (sender): ").strip()
            if not smtp_user: err("Email address is required.")

        while not smtp_password:
            smtp_password = input("  Gmail App Password (16 chars, no spaces): ").strip().replace(" ", "")
            if not smtp_password:
                err("App Password is required.")
            elif len(smtp_password) < 16:
                warn("App Passwords are 16 characters. Double-check you copied it correctly.")

        sender_name = input("  Sender display name [e.g. William from ProMailer]: ").strip()
        if not sender_name:
            sender_name = smtp_user.split("@")[0].capitalize()
            warn(f"No name entered — using '{sender_name}'")

    else:
        print(f"\n  {BOLD}Custom SMTP Setup{RESET}")
        while not smtp_server or smtp_server == "smtp.gmail.com":
            v = input("  SMTP host (e.g. smtp.sendgrid.net): ").strip()
            if v: smtp_server = v
            else: err("SMTP host is required.")

        port_in = input(f"  SMTP port [Default: 587]: ").strip()
        if port_in: smtp_port = port_in

        while not smtp_user:
            smtp_user = input("  SMTP username: ").strip()
            if not smtp_user: err("Username is required.")

        while not smtp_password:
            smtp_password = input("  SMTP password: ").strip()
            if not smtp_password: err("Password is required.")

        while not sender_name:
            sender_name = input("  Sender display name: ").strip()
            if not sender_name: err("Display name is required.")

        # IMAP auto-derivation
        domain = smtp_user.split("@")[-1].lower()
        if domain in ["gmail.com", "googlemail.com"] or smtp_server == "smtp.gmail.com":
            default_imap = "imap.gmail.com"
            default_imap_port = "993"
        else:
            default_imap = f"imap.{domain}"
            default_imap_port = "993"

        print(f"\n  {BOLD}Custom IMAP Setup (for Reply Tracking){RESET}")
        imap_server_in = input(f"  IMAP host [Default: {default_imap}]: ").strip()
        imap_server = imap_server_in if imap_server_in else default_imap

        imap_port_in = input(f"  IMAP port [Default: {default_imap_port}]: ").strip()
        imap_port = imap_port_in if imap_port_in else default_imap_port

    reply_to = input(f"\n  Reply-To address [Default: {smtp_user}]: ").strip()
    if not reply_to:
        reply_to = smtp_user

    # ── Step 2: LLM Provider ──────────────────────────────────────────────────
    section("2. AI Text Generation Provider")
    print(f"""
  {BOLD}Choose how ProMailer generates personalised outreach emails:{RESET}

  {CYAN}[1] OpenAI API{RESET}     — Cloud engine. Highly intelligent.
                   Requires a developer key (platform.openai.com)

  {CYAN}[2] Anthropic API{RESET}  — Cloud engine. Outstanding writing quality.
                   Requires a developer key (console.anthropic.com)

  {CYAN}[3] Ollama (Local){RESET} — 100% free · runs entirely on your machine · private
                   Requires Ollama installed: https://ollama.com

  {YELLOW}No API key yet? Choose [1] or [2] — key accounts are free to register.{RESET}
  {YELLOW}Don't have Ollama installed? Avoid [3] for now.{RESET}
""")

    provider = ""
    while provider not in ["1", "2", "3"]:
        provider = input("  Choose option [1/2/3] (Default: 1 — OpenAI): ").strip()
        if not provider:
            provider = "1"
        if provider not in ["1", "2", "3"]:
            err("Please enter 1, 2, or 3.")

    provider_map = {"1": "openai", "2": "anthropic", "3": "ollama"}
    llm_provider = provider_map[provider]

    openai_key    = ""
    anthropic_key = ""
    ollama_url    = "http://localhost:11434/api/generate"
    ollama_model  = "llama3.2:3b"

    # Configure & Validate chosen provider
    if llm_provider == "openai":
        print(f"  Get your key at: {CYAN}https://platform.openai.com/api-keys{RESET}\n")
        validated = False
        while not validated:
            openai_key = input("  Paste your OpenAI API key (sk-...): ").strip()
            if not openai_key:
                err("API key cannot be empty.")
                continue
            validated = validate_openai(openai_key)
            if not validated:
                retry = input("  Try a different key? [Y/n]: ").strip().lower()
                if retry == "n":
                    err("Cannot proceed without a valid OpenAI key.")
                    sys.exit(1)

    elif llm_provider == "anthropic":
        print(f"  Get your key at: {CYAN}https://console.anthropic.com/settings/keys{RESET}\n")
        validated = False
        while not validated:
            anthropic_key = input("  Paste your Anthropic API key (sk-ant-...): ").strip()
            if not anthropic_key:
                err("API key cannot be empty.")
                continue
            validated = validate_anthropic(anthropic_key)
            if not validated:
                retry = input("  Try a different key? [Y/n]: ").strip().lower()
                if retry == "n":
                    err("Cannot proceed without a valid Anthropic key.")
                    sys.exit(1)

    else:  # Ollama
        print(f"  {YELLOW}Ollama must be running before you start a campaign.{RESET}")
        print(f"  Download free from: {CYAN}https://ollama.com{RESET}\n")
        url_in   = input(f"  Ollama endpoint [Default: {ollama_url}]: ").strip()
        model_in = input(f"  Ollama model    [Default: {ollama_model}]: ").strip()
        if url_in:   ollama_url   = url_in
        if model_in: ollama_model = model_in
        validate_ollama(ollama_url, ollama_model)

    # ── Step 3: Google Places API Key ─────────────────────────────────────────
    section("3. Google Places API Key (Optional)")
    print(f"""
  {BOLD}Optional — enables the Lead Finder feature{RESET}
  {YELLOW}Includes a free $200/month credit (approx. 11,000 searches){RESET}
  {CYAN}Get your key: console.cloud.google.com{RESET}
""")
    google_places_key = input("  Google Places API Key: ").strip()

    # ── Step 4: Write .env ────────────────────────────────────────────────────
    section("4. Saving Configuration")

    with open(".env", "w") as f:
        f.write("# ProMailer Configuration\n")
        f.write("# Generated by setup_wizard.py — do not share this file.\n\n")

        f.write(f"SMTP_SERVER={smtp_server}\n")
        f.write(f"SMTP_PORT={smtp_port}\n")
        f.write(f"SMTP_USER={smtp_user}\n")
        f.write(f"SMTP_PASSWORD={smtp_password}\n")
        f.write(f"SENDER_NAME={sender_name}\n")
        f.write(f"REPLY_TO={reply_to}\n\n")

        # IMAP configuration
        f.write(f"IMAP_SERVER={imap_server}\n")
        f.write(f"IMAP_PORT={imap_port}\n\n")

        # Backward-compatibility aliases
        f.write(f"GMAIL_USER={smtp_user}\n")
        f.write(f"GMAIL_APP_PASSWORD={smtp_password}\n\n")

        f.write(f"DAILY_SEND_LIMIT=20\n")
        f.write(f"COOLDOWN_MINUTES=4\n")
        f.write(f"LLM_PROVIDER={llm_provider}\n\n")

        f.write(f"OLLAMA_URL={ollama_url}\n")
        f.write(f"OLLAMA_MODEL={ollama_model}\n\n")

        f.write(f"OPENAI_API_KEY={openai_key}\n")
        f.write(f"OPENAI_MODEL=gpt-4o-mini\n\n")

        f.write(f"ANTHROPIC_API_KEY={anthropic_key}\n")
        f.write(f"ANTHROPIC_MODEL=claude-3-5-haiku-20241022\n\n")

        f.write(f"GOOGLE_PLACES_API_KEY={google_places_key}\n")

    # Secure permissions on Mac/Linux
    if platform.system() != "Windows":
        try:
            os.chmod(".env", 0o600)
            ok("Secured .env file permissions (chmod 600).")
        except Exception as e:
            warn(f"Could not set file permissions: {e}")
    else:
        ok("Configuration saved under your Windows user profile.")

    print(f"\n{GREEN}{BOLD}  ✓ ProMailer is configured and ready!{RESET}")
    print(f"""
  {BOLD}Next steps:{RESET}
    1. Load your leads:    python3 prospect_loader.py leads.csv
    2. Run a campaign:     python3 main.py
    3. View dashboard:     python3 dashboard.py  →  http://localhost:5050
    4. Reconfigure later:  python3 main.py --reconfigure
""")


if __name__ == "__main__":
    run_wizard()
