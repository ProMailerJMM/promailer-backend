#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR" || exit 1
echo "[ProMailer] Launching campaign loop..."
python3 main.py
echo ""
echo "[ProMailer] Campaign runner exited. Press Enter to close."
read
