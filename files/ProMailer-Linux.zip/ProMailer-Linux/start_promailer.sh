#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR" || exit 1

echo "==================================================="
echo "             PROMAILER CAMPAIGN RUNNER"
echo "==================================================="
echo ""

# Check python3 installation
if ! command -v python3 &> /dev/null; then
    echo -e "\033[91m[Error] Python 3 is not installed on your system!\033[0m"
    echo "ProMailer requires Python 3 to run."
    echo "Please install it using your distribution package manager (e.g. apt install python3)."
    echo ""
    echo "Press Enter to close."
    read
    exit 1
fi

# Check and install dependencies automatically
echo "[ProMailer] Verifying required Python modules..."
python3 -c "import flask, dotenv, requests, bs4" >/dev/null 2>&1
if [ $? -ne 0 ]; then
    echo "[ProMailer] Dependencies missing. Installing now..."
    pip3 install -r requirements.txt
    if [ $? -ne 0 ]; then
        echo -e "\033[91m[Error] Failed to install dependencies via pip3.\033[0m"
        echo "Press Enter to close."
        read
        exit 1
    fi
    echo "[ProMailer] Dependencies installed successfully!"
    echo ""
fi

python3 main.py
echo ""
echo "[ProMailer] Campaign runner exited. Press Enter to close."
read
