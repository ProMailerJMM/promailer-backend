#!/bin/bash
export PATH=$PATH:/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SCRIPT_PATH="$SCRIPT_DIR/PROMAILER_DASHBOARD.command"

# Detect if running inside Terminal
if [ -z "$TERM_PROGRAM" ]; then
    # Launched via Finder (double-click)
    osascript <<EOF
tell application "Terminal"
    activate
    do script "cd \"$SCRIPT_DIR\" && bash \"$SCRIPT_PATH\""
end tell
EOF
    exit 0
fi

cd "$SCRIPT_DIR" || exit 1

# Kill any existing flask instances running on port 5050 to prevent address-in-use errors
PID=$(lsof -t -i:5050)
if [ ! -z "$PID" ]; then
    echo "[ProMailer] Reclaiming dashboard port 5050 (killing old process $PID)..."
    kill -9 $PID > /dev/null 2>&1
fi

echo -e "\033[94m\033[1m"
echo "================================================"
echo "          PROMAILER SOVEREIGN DASHBOARD         "
echo "================================================"
echo -e "\033[0m"

# Check python3 installation
if ! command -v python3 &> /dev/null; then
    echo -e "\033[91m[Error] Python 3 is not installed on your system!\033[0m"
    echo "ProMailer requires Python 3. Please install it from:"
    echo "👉 https://www.python.org/downloads/macos/"
    echo ""
    echo "Press any key to close this window."
    read -n 1 -s -r
    exit 1
fi

# Check and install dependencies automatically
echo "[ProMailer] Verifying required Python modules..."
python3 -c "import flask, dotenv, requests, bs4" >/dev/null 2>&1
if [ $? -ne 0 ]; then
    echo "[ProMailer] Dependencies missing. Installing now..."
    pip3 install -r requirements.txt
    if [ $? -ne 0 ]; then
        echo -e "\033[91m[Error] Failed to install dependencies via pip3.\033[0m"
        echo "Press any key to close."
        read -n 1 -s -r
        exit 1
    fi
    echo "[ProMailer] Dependencies installed successfully!"
    echo ""
fi

echo "[ProMailer] Starting dashboard Flask server..."
echo "[ProMailer] Connected to pipeline database..."
echo "[ProMailer] Opening web console at http://localhost:5050"

# Open the browser automatically
sleep 1.5
open http://localhost:5050

# Execute flask
python3 dashboard.py

echo "[ProMailer] Dashboard stopped. Press any key to close."
read -n 1
