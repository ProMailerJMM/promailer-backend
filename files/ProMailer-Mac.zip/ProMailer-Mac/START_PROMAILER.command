#!/bin/bash
export PATH=$PATH:/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SCRIPT_PATH="$SCRIPT_DIR/START_PROMAILER.command"

if [ -z "$TERM_PROGRAM" ]; then
    osascript <<EOF
tell application "Terminal"
    activate
    do script "cd \"$SCRIPT_DIR\" && bash \"$SCRIPT_PATH\""
end tell
EOF
    exit 0
fi

cd "$SCRIPT_DIR" || exit 1

echo "==================================================="
echo "             PROMAILER CAMPAIGN RUNNER"
echo "==================================================="
echo ""

# Check python3 installation
if ! command -v python3 &> /dev/null; then
    echo -e "\033[91m[Error] Python 3 is not installed on your system!\033[0m"
    echo "ProMailer requires Python 3. Please install it from:"
    echo "👉 https://www.python.org/downloads/macos/"
    echo ""
    echo "Press any key to close this window."
    read -n 1 -s -r
    exit 1
fi

# Check and install dependencies automatically
echo "[ProMailer] Verifying required Python modules..."
python3 -c "import flask, dotenv, requests, bs4" >/dev/null 2>&1
if [ $? -ne 0 ]; then
    echo "[ProMailer] Dependencies missing. Installing now..."
    pip3 install -r requirements.txt
    if [ $? -ne 0 ]; then
        echo -e "\033[91m[Error] Failed to install dependencies via pip3.\033[0m"
        echo "Press any key to close."
        read -n 1 -s -r
        exit 1
    fi
    echo "[ProMailer] Dependencies installed successfully!"
    echo ""
fi

python3 main.py
echo ""
echo "[ProMailer] Campaign runner exited. Press any key to close this terminal."
read -n 1 -s -r
