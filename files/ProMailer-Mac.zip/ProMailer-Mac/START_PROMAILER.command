#!/bin/bash
export PATH=$PATH:/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SCRIPT_PATH="$SCRIPT_DIR/START_PROMAILER.command"

if [ -z "$TERM_PROGRAM" ]; then
    osascript <<EOF
tell application "Terminal"
    activate
    do script "cd \"$SCRIPT_DIR\" && bash \"$SCRIPT_PATH\""
end tell
EOF
    exit 0
fi

cd "$SCRIPT_DIR" || exit 1
python3 main.py
echo ""
echo "[ProMailer] Campaign runner exited. Press any key to close this terminal."
read -n 1 -s -r
