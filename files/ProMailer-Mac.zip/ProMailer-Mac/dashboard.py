from flask import Flask, render_template_string, request, jsonify
import sqlite3
import os
import csv
import io
from datetime import datetime
from database import DB_NAME

app = Flask(__name__)

# Premium glassmorphic styling, Outfit & Fira Code typography, with rich modals and dynamic Javascript search, sorting, and pagination
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ProMailer — Sovereign Outreach Console</title>
    
    <!-- Modern Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fira+Code:wght@400;500;700&family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --bg-color: #080a0c;
            --surface-color: rgba(15, 20, 28, 0.85);
            --surface-raised: rgba(28, 38, 54, 0.6);
            --border-color: #1c2636;
            --border-glow: rgba(0, 242, 254, 0.15);
            --text-primary: #e6edf3;
            --text-secondary: #8b949e;
            --accent-blue: #58a6ff;
            --accent-cyan: #00f2fe;
            --accent-cyan-glow: rgba(0, 242, 254, 0.4);
            --status-success: #30a14e;
            --status-warning: #d29922;
            --status-danger: #ff5f56;
            --status-pending: #d29922;
            --status-sent: #388bfd;
            --status-replied: #30a14e;
            --status-followed: #bc8cff;
            --status-generated: #565656;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        html, body {
            background-color: var(--bg-color);
            background-image: 
                radial-gradient(var(--border-color) 1px, transparent 0),
                radial-gradient(var(--border-color) 1px, transparent 0);
            background-size: 40px 40px;
            background-position: 0 0, 20px 20px;
            color: var(--text-primary);
            font-family: 'Outfit', sans-serif;
            -webkit-font-smoothing: antialiased;
            min-height: 100vh;
            padding: 40px 20px;
        }

        .monospace {
            font-family: 'Fira Code', 'Courier New', Courier, monospace;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: var(--surface-color);
            backdrop-filter: blur(16px);
            border: 1px solid var(--border-color);
            padding: 35px;
            border-radius: 16px;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.6);
        }

        /* ── Header ── */
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 25px;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 20px;
        }

        h1 {
            color: var(--text-primary);
            font-size: 28px;
            margin: 0;
            font-weight: 800;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        h1 span {
            color: var(--accent-cyan);
            text-shadow: 0 0 12px var(--accent-cyan-glow);
        }

        .tagline {
            font-size: 13px;
            color: var(--text-secondary);
            margin-top: 4px;
        }

        /* ── Action Buttons Header ── */
        .header-actions {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .btn {
            padding: 10px 18px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            font-family: inherit;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s;
            border: 1px solid var(--border-color);
            background: transparent;
            color: var(--text-primary);
        }

        .btn:hover {
            background: rgba(255, 255, 255, 0.03);
            border-color: var(--text-primary);
        }

        .btn-primary {
            background: var(--accent-cyan);
            border-color: var(--accent-cyan);
            color: var(--bg-color);
            box-shadow: 0 4px 15px rgba(0, 242, 254, 0.15);
        }

        .btn-primary:hover {
            background: #00d6e0;
            border-color: #00d6e0;
            box-shadow: 0 4px 20px var(--accent-cyan-glow);
            transform: translateY(-1px);
        }

        /* ── Play / Pause Campaign Switch ── */
        .campaign-switch {
            display: flex;
            align-items: center;
            background: rgba(28, 38, 54, 0.4);
            border: 1px solid var(--border-color);
            padding: 6px 14px;
            border-radius: 30px;
            gap: 10px;
        }

        .switch-indicator {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            display: inline-block;
        }

        .switch-indicator.running {
            background: var(--status-success);
            box-shadow: 0 0 10px var(--status-success);
            animation: pulse 2s infinite;
        }

        .switch-indicator.paused {
            background: var(--status-warning);
            box-shadow: 0 0 8px var(--status-warning);
        }

        .campaign-state-text {
            font-family: 'Fira Code', monospace;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-weight: 700;
        }

        .btn-toggle-state {
            background: transparent;
            border: none;
            cursor: pointer;
            color: var(--accent-cyan);
            font-size: 12px;
            font-weight: 700;
            font-family: inherit;
            padding: 2px 6px;
            display: flex;
            align-items: center;
            gap: 4px;
            text-decoration: underline;
        }

        /* ── Stats Bar ── */
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 20px;
            margin-bottom: 35px;
        }

        .stat-card {
            background: var(--surface-raised);
            border: 1px solid var(--border-color);
            padding: 20px;
            border-radius: 10px;
            position: relative;
            overflow: hidden;
            transition: transform 0.2s, border-color 0.2s, box-shadow 0.2s;
            cursor: pointer;
        }

        .stat-card:hover {
            transform: translateY(-2px);
            border-color: var(--accent-blue);
            box-shadow: 0 5px 15px rgba(88, 166, 255, 0.08);
        }

        .stat-card::after {
            content: '';
            position: absolute;
            top: 0; left: 0; width: 4px; height: 100%;
            background: var(--accent-blue);
        }
        
        .stat-card.total::after { background: var(--accent-cyan); }
        .stat-card.sent::after { background: var(--status-sent); }
        .stat-card.replied::after { background: var(--status-replied); }
        .stat-card.pending::after { background: var(--status-pending); }
        .stat-card.rate::after { background: var(--status-followed); }
        .stat-card.failed::after { background: var(--status-danger); }

        .stat-card h3 {
            margin: 0;
            font-size: 11px;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .stat-card p {
            font-size: 30px;
            font-weight: 800;
            margin: 10px 0 0;
            color: var(--text-primary);
        }

        /* ── Filters and Controls Bar ── */
        .controls-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            flex-wrap: wrap;
            gap: 16px;
        }

        .tabs {
            display: flex;
            background: rgba(28, 38, 54, 0.3);
            border: 1px solid var(--border-color);
            padding: 4px;
            border-radius: 8px;
            gap: 4px;
        }

        .tab-btn {
            background: transparent;
            border: none;
            color: var(--text-secondary);
            padding: 8px 16px;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            font-family: inherit;
            transition: all 0.15s;
        }

        .tab-btn:hover {
            color: var(--text-primary);
        }

        .tab-btn.active {
            background: var(--surface-raised);
            color: var(--accent-cyan);
            border: 1px solid var(--border-color);
        }

        .search-box {
            position: relative;
            max-width: 320px;
            width: 100%;
        }

        .search-input {
            width: 100%;
            background: rgba(15, 20, 28, 0.85);
            border: 1px solid var(--border-color);
            padding: 10px 16px;
            border-radius: 8px;
            color: var(--text-primary);
            font-size: 13px;
            outline: none;
            transition: border-color 0.2s, box-shadow 0.2s;
            font-family: inherit;
        }

        .search-input:focus {
            border-color: var(--accent-cyan);
            box-shadow: 0 0 10px var(--border-glow);
        }

        /* ── Table Layout ── */
        .table-container {
            width: 100%;
            overflow-x: auto;
            border: 1px solid var(--border-color);
            border-radius: 10px;
            background: rgba(10, 14, 20, 0.5);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            text-align: left;
            padding: 14px 18px;
            border-bottom: 1px solid var(--border-color);
            font-size: 13.5px;
        }

        th {
            background: rgba(28, 38, 54, 0.4);
            color: var(--text-secondary);
            font-weight: 600;
            text-transform: uppercase;
            font-size: 11px;
            letter-spacing: 0.5px;
            cursor: pointer;
            user-select: none;
        }

        th:hover {
            color: var(--text-primary);
        }

        tr:last-child td {
            border-bottom: none;
        }

        tr:hover td {
            background: rgba(88, 166, 255, 0.02);
        }

        /* Status Badges */
        .status {
            padding: 4px 10px;
            border-radius: 4px;
            font-size: 10.5px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            display: inline-block;
            font-family: 'Fira Code', monospace;
        }

        .status-pending { background: rgba(210, 153, 34, 0.12); color: var(--status-pending); border: 1px solid rgba(210, 153, 34, 0.25); }
        .status-sent { background: rgba(56, 139, 253, 0.12); color: var(--status-sent); border: 1px solid rgba(56, 139, 253, 0.25); }
        .status-followed_up { background: rgba(188, 140, 255, 0.12); color: var(--status-followed); border: 1px solid rgba(188, 140, 255, 0.25); }
        .status-replied { background: rgba(48, 161, 78, 0.12); color: var(--status-replied); border: 1px solid rgba(48, 161, 78, 0.25); }
        .status-generated { background: rgba(86, 86, 86, 0.12); color: var(--status-generated); border: 1px solid rgba(86, 86, 86, 0.25); }
        .status-failed { background: rgba(255, 95, 86, 0.12); color: var(--status-danger); border: 1px solid rgba(255, 95, 86, 0.25); }

        .website-link {
            color: var(--accent-blue);
            text-decoration: none;
        }

        .website-link:hover {
            text-decoration: underline;
        }

        .actions-cell {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .btn-action {
            background: transparent;
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 11px;
            font-weight: 500;
            font-family: inherit;
            transition: all 0.2s;
        }

        .btn-action:hover {
            border-color: var(--accent-cyan);
            color: var(--accent-cyan);
            box-shadow: 0 0 8px rgba(0, 242, 254, 0.15);
        }

        .btn-replied {
            border-color: rgba(48, 161, 78, 0.3);
            color: var(--status-replied);
        }

        .btn-replied:hover {
            background: rgba(48, 161, 78, 0.1);
            border-color: var(--status-replied);
            color: #ffffff;
            box-shadow: 0 0 8px rgba(48, 161, 78, 0.3);
        }

        .btn-delete {
            border-color: rgba(255, 95, 86, 0.3);
            color: var(--status-danger);
        }

        .btn-delete:hover {
            background: rgba(255, 95, 86, 0.1);
            border-color: var(--status-danger);
            color: #ffffff;
            box-shadow: 0 0 8px rgba(255, 95, 86, 0.3);
        }

        /* ── Pagination ── */
        .pagination-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 20px;
            font-size: 13px;
            color: var(--text-secondary);
        }

        .pagination-buttons {
            display: flex;
            gap: 8px;
        }

        /* ── dialog Native Modals ── */
        dialog {
            background: #080a0c;
            border: 1px solid var(--border-color);
            border-radius: 12px;
            box-shadow: 0 0 30px rgba(0, 242, 254, 0.1), 0 20px 50px rgba(0, 0, 0, 0.8);
            width: calc(100% - 32px);
            max-width: 540px;
            padding: 0;
            margin: auto;
            color: var(--text-primary);
            font-family: inherit;
            outline: none;
            overflow: hidden;
            backdrop-filter: blur(16px);
        }

        dialog::backdrop {
            background-color: rgba(4, 6, 8, 0.85);
            backdrop-filter: blur(6px);
        }

        .modal-header {
            background: rgba(28, 38, 54, 0.4);
            border-bottom: 1px solid var(--border-color);
            height: 46px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
        }

        .modal-title {
            font-weight: 700;
            font-size: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .close-modal-btn {
            background: transparent;
            border: none;
            cursor: pointer;
            color: var(--text-secondary);
            padding: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .close-modal-btn:hover {
            color: var(--text-primary);
        }

        .modal-body {
            padding: 24px;
        }

        .form-group {
            margin-bottom: 18px;
        }

        .form-label {
            display: block;
            font-family: 'Fira Code', monospace;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--accent-blue);
            margin-bottom: 6px;
        }

        .form-input, .form-textarea {
            width: 100%;
            background: rgba(15, 20, 28, 0.85);
            border: 1px solid var(--border-color);
            padding: 11px 14px;
            border-radius: 6px;
            color: var(--text-primary);
            font-size: 13.5px;
            outline: none;
            transition: all 0.2s;
            font-family: inherit;
        }

        .form-input:focus, .form-textarea:focus {
            border-color: var(--accent-cyan);
            box-shadow: 0 0 10px var(--border-glow);
        }

        /* ── Dynamic Toast Notifications ── */
        .toast-container {
            position: fixed;
            bottom: 24px;
            right: 24px;
            z-index: 1000;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .toast {
            background: rgba(15, 20, 28, 0.95);
            border: 1px solid var(--border-color);
            padding: 14px 20px;
            border-radius: 8px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.5);
            font-size: 13px;
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--text-primary);
            min-width: 280px;
            animation: slideIn 0.3s cubic-bezier(0.16, 1, 0.3, 1);
            border-left: 4px solid var(--accent-blue);
            backdrop-filter: blur(10px);
        }

        .toast.success { border-left-color: var(--status-success); }
        .toast.error { border-left-color: var(--status-danger); }
        .toast.warning { border-left-color: var(--status-warning); }

        /* ── Animations ── */
        @keyframes pulse {
            0% { transform: scale(1); opacity: 0.8; }
            50% { transform: scale(1.2); opacity: 1; }
            100% { transform: scale(1); opacity: 0.8; }
        }

        @keyframes slideIn {
            from { transform: translateX(100%) translateY(0); opacity: 0; }
            to { transform: translateX(0) translateY(0); opacity: 1; }
        }

        .footer {
            margin-top: 40px;
            text-align: center;
            font-size: 11.5px;
            color: var(--text-secondary);
        }
        
        .footer a {
            color: var(--accent-cyan);
            text-decoration: none;
        }
        
        .footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Toast Container for Actions -->
        <div class="toast-container" id="toast-container"></div>

        <header>
            <div>
                <h1>⚡ ProMailer <span>Sovereign Outreach</span></h1>
                <div class="tagline">Local-first, air-gapped cold email compiler & engine</div>
            </div>
            
            <div class="header-actions">
                <!-- Play / Pause Campaign state -->
                <div class="campaign-switch">
                    <span class="switch-indicator {% if state == 'running' %}running{% else %}paused{% endif %}" id="campaign-indicator"></span>
                    <span class="campaign-state-text" id="campaign-state-text">{{ state }}</span>
                    <button class="btn-toggle-state" onclick="toggleCampaignState()">
                        [Toggle]
                    </button>
                </div>

                <button class="btn" onclick="openModal('csv-modal')">
                    📤 Load CSV
                </button>
                <button class="btn btn-primary" onclick="openModal('add-modal')">
                    ➕ Add Prospect
                </button>
            </div>
        </header>
        
        <!-- Stats Cards Grid -->
        <div class="stats">
            <div class="stat-card total" onclick="filterByStatus('all')">
                <h3>Total Prospects</h3>
                <p id="stat-total">{{ stats.total }}</p>
            </div>
            <div class="stat-card pending" onclick="filterByStatus('pending')">
                <h3>Pipeline Queue</h3>
                <p id="stat-pending">{{ stats.pending }}</p>
            </div>
            <div class="stat-card sent" onclick="filterByStatus('sent')">
                <h3>Outbox Sent</h3>
                <p id="stat-sent">{{ stats.sent }}</p>
            </div>
            <div class="stat-card replied" onclick="filterByStatus('replied')">
                <h3>Replies</h3>
                <p id="stat-replied">{{ stats.replied }}</p>
            </div>
            <div class="stat-card rate">
                <h3>Reply Rate</h3>
                <p id="stat-rate">{{ stats.reply_rate }}%</p>
            </div>
            <div class="stat-card failed" onclick="filterByStatus('failed')">
                <h3>Failed</h3>
                <p id="stat-failed">{{ stats.failed }}</p>
            </div>
        </div>

        <!-- Filters Bar -->
        <div class="controls-bar">
            <div class="tabs">
                <button class="tab-btn active" id="tab-all" onclick="filterByStatus('all')">All</button>
                <button class="tab-btn" id="tab-pending" onclick="filterByStatus('pending')">Pending</button>
                <button class="tab-btn" id="tab-sent" onclick="filterByStatus('sent')">Sent</button>
                <button class="tab-btn" id="tab-replied" onclick="filterByStatus('replied')">Replied</button>
                <button class="tab-btn" id="tab-followed_up" onclick="filterByStatus('followed_up')">Followed Up</button>
                <button class="tab-btn" id="tab-generated" onclick="filterByStatus('generated')">Generated</button>
            </div>
            
            <div class="search-box">
                <input type="text" id="search-input" class="search-input" placeholder="Search company, name, email..." oninput="handleSearch()">
            </div>
        </div>

        <!-- Leads Table container -->
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th onclick="sortTable('company_name')">Business / Contact Name</th>
                        <th onclick="sortTable('contact_email')">Email Address</th>
                        <th onclick="sortTable('website')">Website</th>
                        <th onclick="sortTable('status')">Outreach Status</th>
                        <th onclick="sortTable('sent_at')">Last Sent / Active</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="leads-tbody">
                    <!-- Loaded dynamically via JavaScript -->
                </tbody>
            </table>
        </div>

        <!-- Pagination Controls -->
        <div class="pagination-container">
            <div id="pagination-info">Showing 0-0 of 0 prospects</div>
            <div class="pagination-buttons">
                <button class="btn btn-action" id="btn-prev" onclick="prevPage()">&lt; Prev</button>
                <button class="btn btn-action" id="btn-next" onclick="nextPage()">Next &gt;</button>
            </div>
        </div>
        
        <div class="footer">
            Sovereign pipeline powered by <a href="https://justmemedia.ca" target="_blank">Just Me Media</a> — © 2026 ProMailer. All Rights Reserved.
        </div>
    </div>

    <!-- ── Add Lead Modal ── -->
    <dialog id="add-modal">
        <div class="modal-header">
            <div class="modal-title">➕ Add Single Prospect</div>
            <button class="close-modal-btn" onclick="closeModal('add-modal')">✕</button>
        </div>
        <div class="modal-body">
            <form id="add-lead-form" onsubmit="submitAddLead(event)">
                <div class="form-group">
                    <label class="form-label" for="add-company">Company Name *</label>
                    <input type="text" id="add-company" class="form-input" placeholder="Acme Corp" required>
                </div>
                <div class="form-group">
                    <label class="form-label" for="add-name">Contact Name</label>
                    <input type="text" id="add-name" class="form-input" placeholder="John Doe">
                </div>
                <div class="form-group">
                    <label class="form-label" for="add-email">Contact Email *</label>
                    <input type="email" id="add-email" class="form-input" placeholder="john@acmecorp.com" required>
                </div>
                <div class="form-group">
                    <label class="form-label" for="add-website">Website (URL)</label>
                    <input type="url" id="add-website" class="form-input" placeholder="https://acmecorp.com">
                </div>
                <div class="form-group">
                    <label class="form-label" for="add-areas">Specialties / Practice Areas</label>
                    <input type="text" id="add-areas" class="form-input" placeholder="SaaS, B2B Software">
                </div>
                <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 24px;">
                    <button type="button" class="btn" onclick="closeModal('add-modal')">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Lead</button>
                </div>
            </form>
        </div>
    </dialog>

    <!-- ── Import CSV Modal ── -->
    <dialog id="csv-modal">
        <div class="modal-header">
            <div class="modal-title">📤 Upload CSV Leads File</div>
            <button class="close-modal-btn" onclick="closeModal('csv-modal')">✕</button>
        </div>
        <div class="modal-body">
            <form id="csv-form" onsubmit="submitCSVImport(event)">
                <div class="form-group">
                    <label class="form-label" for="csv-file">Select CSV File</label>
                    <input type="file" id="csv-file" class="form-input" accept=".csv" required style="padding: 8px;">
                </div>
                <div style="font-size: 12px; color: var(--text-secondary); line-height: 1.5; margin-bottom: 20px;">
                    <p style="font-weight: 600; margin-bottom: 6px; color: var(--text-primary);">💡 Auto-Headers Mapped:</p>
                    <p>• Company name columns (e.g. <code>company</code>, <code>business</code>)</p>
                    <p>• Email address columns (e.g. <code>email</code>, <code>contact_email</code>)</p>
                    <p>• Website URL, Contact Name, Practice/specialty sectors.</p>
                </div>
                <div style="display: flex; justify-content: flex-end; gap: 10px;">
                    <button type="button" class="btn" onclick="closeModal('csv-modal')">Cancel</button>
                    <button type="submit" class="btn btn-primary" id="csv-submit-btn">Upload &amp; Parse</button>
                </div>
            </form>
        </div>
    </dialog>

    <!-- ── Inspect Brief Modal ── -->
    <dialog id="brief-modal" style="max-width: 650px;">
        <div class="modal-header">
            <div class="modal-title">📧 Compiled Email Outreach Brief</div>
            <button class="close-modal-btn" onclick="closeModal('brief-modal')">✕</button>
        </div>
        <div class="modal-body" style="padding-top: 16px;">
            <div style="margin-bottom: 12px; font-size: 13px;">
                <span class="form-label" style="display: inline-block; margin-bottom: 0;">To:</span>
                <span id="brief-recipient" style="font-weight: 600;">john@acme.com</span>
            </div>
            <div class="form-group">
                <textarea id="brief-content" class="form-textarea monospace" rows="14" readonly style="resize: vertical; font-size: 12.5px; line-height: 1.5; background: #06080b; color: #d1d5db;"></textarea>
            </div>
            <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 20px;">
                <span style="font-size: 11px; color: var(--text-secondary);" id="brief-sent-time">Waiting to be sent...</span>
                <div style="display: flex; gap: 10px;">
                    <button class="btn" onclick="copyBriefText()">📋 Copy Text</button>
                    <button class="btn btn-primary" onclick="closeModal('brief-modal')">Close</button>
                </div>
            </div>
        </div>
    </dialog>

    <!-- JS Logic -->
    <script>
        // Seeded directly from Flask Jinja context
        let leads = {{ leads_json | safe }};
        let currentFilter = 'all';
        let searchQuery = '';
        let sortColumn = 'created_at';
        let sortDirection = 'desc';
        let currentPage = 1;
        const rowsPerPage = 15;

        // Toast Helper
        function showToast(message, type = 'info') {
            const container = document.getElementById('toast-container');
            const toast = document.createElement('div');
            toast.className = `toast ${type}`;
            toast.innerHTML = `<span>💬</span> <div>${message}</div>`;
            container.appendChild(toast);
            
            setTimeout(() => {
                toast.style.opacity = '0';
                toast.style.transform = 'translateY(10px)';
                setTimeout(() => toast.remove(), 300);
            }, 3000);
        }

        // Modal Helpers
        function openModal(id) {
            document.getElementById(id).showModal();
        }

        function closeModal(id) {
            document.getElementById(id).close();
        }

        // Play/Pause Runner toggle
        async function toggleCampaignState() {
            const indicator = document.getElementById('campaign-indicator');
            const textEl = document.getElementById('campaign-state-text');
            const isRunning = textEl.textContent.trim().toLowerCase() === 'running';
            const newState = isRunning ? 'paused' : 'running';

            try {
                const res = await fetch('/toggle_campaign', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ state: newState })
                });

                if (res.ok) {
                    const data = await res.json();
                    textEl.textContent = data.state;
                    if (data.state === 'running') {
                        indicator.className = 'switch-indicator running';
                        showToast('Campaign pipeline is now active and running!', 'success');
                    } else {
                        indicator.className = 'switch-indicator paused';
                        showToast('Campaign pipeline is paused safely.', 'warning');
                    }
                }
            } catch (err) {
                showToast('Failed to switch campaign execution mode.', 'error');
            }
        }

        // Add Single Prospect Form
        async function submitAddLead(e) {
            e.preventDefault();
            const data = {
                company_name: document.getElementById('add-company').value,
                contact_name: document.getElementById('add-name').value,
                contact_email: document.getElementById('add-email').value,
                website: document.getElementById('add-website').value,
                practice_areas: document.getElementById('add-areas').value
            };

            try {
                const res = await fetch('/add_lead', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify(data)
                });
                
                const result = await res.json();
                if (res.ok) {
                    showToast('Prospect added successfully to SQLite pipeline!', 'success');
                    closeModal('add-modal');
                    document.getElementById('add-lead-form').reset();
                    reloadDashboardData();
                } else {
                    showToast(result.message || 'Error adding lead.', 'error');
                }
            } catch (err) {
                showToast('Network error during operation.', 'error');
            }
        }

        // CSV Import Form
        async function submitCSVImport(e) {
            e.preventDefault();
            const fileInput = document.getElementById('csv-file');
            const submitBtn = document.getElementById('csv-submit-btn');
            
            if (fileInput.files.length === 0) return;
            
            const formData = new FormData();
            formData.append('csv_file', fileInput.files[0]);
            
            submitBtn.disabled = true;
            submitBtn.textContent = 'Parsing...';
            
            try {
                const res = await fetch('/import_csv', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await res.json();
                if (res.ok) {
                    showToast(`Success! Imported ${result.added} prospects. (${result.duplicates} skipped as duplicates)`, 'success');
                    closeModal('csv-modal');
                    document.getElementById('csv-form').reset();
                    reloadDashboardData();
                } else {
                    showToast(result.message || 'Failed to parse CSV.', 'error');
                }
            } catch (err) {
                showToast('Error uploading CSV leads spreadsheet.', 'error');
            } finally {
                submitBtn.disabled = false;
                submitBtn.textContent = 'Upload & Parse';
            }
        }

        // Trigger dynamic API page data reload
        async function reloadDashboardData() {
            try {
                const res = await fetch('/leads_api');
                if (res.ok) {
                    const data = await res.json();
                    leads = data.leads;
                    
                    // Update stats counters
                    document.getElementById('stat-total').textContent = data.stats.total;
                    document.getElementById('stat-pending').textContent = data.stats.pending;
                    document.getElementById('stat-sent').textContent = data.stats.sent;
                    document.getElementById('stat-replied').textContent = data.stats.replied;
                    document.getElementById('stat-failed').textContent = data.stats.failed;
                    document.getElementById('stat-rate').textContent = data.stats.reply_rate + '%';
                    
                    renderTable();
                }
            } catch (err) {
                console.error('Error reloading statistics.', err);
            }
        }

        // Action: Mark as Replied
        async function markAsReplied(id) {
            try {
                const res = await fetch(`/update_status/${id}`, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ status: 'replied' })
                });
                if (res.ok) {
                    showToast('Prospect marked as Replied! Campaign outbound checks paused.', 'success');
                    reloadDashboardData();
                }
            } catch (err) {
                showToast('Failed to update prospect.', 'error');
            }
        }

        // Action: Delete Lead
        async function deleteLead(id) {
            if (!confirm('Are you absolutely sure you want to remove this prospect from your sovereign database?')) return;
            
            try {
                const res = await fetch(`/delete_lead/${id}`, {
                    method: 'POST'
                });
                if (res.ok) {
                    showToast('Prospect deleted successfully.', 'success');
                    reloadDashboardData();
                }
            } catch (err) {
                showToast('Failed to remove prospect.', 'error');
            }
        }

        // Modal Action: Inspect Brief Drawer
        function inspectBrief(id) {
            const lead = leads.find(l => l.id == id);
            if (!lead) return;
            
            document.getElementById('brief-recipient').textContent = `${lead.company_name} (${lead.contact_email})`;
            document.getElementById('brief-content').value = lead.generated_email || 'No outreach brief compiled yet. The campaign loop will crawl the website and synthesize a highly personalized outline natively on first execution.';
            document.getElementById('brief-sent-time').textContent = lead.sent_at ? `Sent on: ${lead.sent_at}` : 'Status: Waiting in outreach queue';
            
            openModal('brief-modal');
        }

        // Copy outreach brief text
        function copyBriefText() {
            const copyText = document.getElementById('brief-content');
            copyText.select();
            copyText.setSelectionRange(0, 99999);
            navigator.clipboard.writeText(copyText.value);
            showToast('Outreach text copied to system clipboard!', 'success');
        }

        // Table Render engine with sorting, search queries, and client-side pagination
        function filterByStatus(status) {
            currentFilter = status;
            
            // Remove active classes
            document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
            const activeTab = document.getElementById(`tab-${status}`);
            if (activeTab) activeTab.classList.add('active');
            
            currentPage = 1;
            renderTable();
        }

        function handleSearch() {
            searchQuery = document.getElementById('search-input').value.toLowerCase();
            currentPage = 1;
            renderTable();
        }

        function sortTable(column) {
            if (sortColumn === column) {
                sortDirection = sortDirection === 'asc' ? 'desc' : 'asc';
            } else {
                sortColumn = column;
                sortDirection = 'asc';
            }
            renderTable();
        }

        function prevPage() {
            if (currentPage > 1) {
                currentPage--;
                renderTable();
            }
        }

        function nextPage() {
            const filtered = getFilteredLeads();
            if (currentPage * rowsPerPage < filtered.length) {
                currentPage++;
                renderTable();
            }
        }

        function getFilteredLeads() {
            return leads.filter(lead => {
                // Filter by status tab selection
                if (currentFilter !== 'all') {
                    if (lead.status !== currentFilter) return false;
                }
                
                // Filter by search query
                if (searchQuery) {
                    const matchCompany = (lead.company_name || '').toLowerCase().includes(searchQuery);
                    const matchName = (lead.contact_name || '').toLowerCase().includes(searchQuery);
                    const matchEmail = (lead.contact_email || '').toLowerCase().includes(searchQuery);
                    return matchCompany || matchName || matchEmail;
                }
                
                return true;
            }).sort((a, b) => {
                let valA = a[sortColumn] || '';
                let valB = b[sortColumn] || '';
                
                if (typeof valA === 'string') valA = valA.toLowerCase();
                if (typeof valB === 'string') valB = valB.toLowerCase();
                
                if (valA < valB) return sortDirection === 'asc' ? -1 : 1;
                if (valA > valB) return sortDirection === 'asc' ? 1 : -1;
                return 0;
            });
        }

        function renderTable() {
            const tbody = document.getElementById('leads-tbody');
            tbody.innerHTML = '';
            
            const filtered = getFilteredLeads();
            
            // Slice page rows
            const startIndex = (currentPage - 1) * rowsPerPage;
            const endIndex = Math.min(startIndex + rowsPerPage, filtered.length);
            const pagedLeads = filtered.slice(startIndex, endIndex);
            
            if (pagedLeads.length === 0) {
                tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; color: var(--text-secondary); padding: 30px;">No prospects found in your SQLite pipeline database. Click "+ Add Prospect" to get started!</td></tr>`;
                document.getElementById('pagination-info').textContent = 'Showing 0-0 of 0 prospects';
                document.getElementById('btn-prev').disabled = true;
                document.getElementById('btn-next').disabled = true;
                return;
            }
            
            pagedLeads.forEach(lead => {
                const tr = document.createElement('tr');
                
                const displayContactName = lead.contact_name ? lead.contact_name : 'N/A';
                const formattedSent = lead.sent_at ? lead.sent_at : 'Waiting';
                
                const websiteLink = lead.website 
                    ? `<a href="${lead.website}" target="_blank" class="website-link">${lead.website.replace(/^https?:\/\//i, '')}</a>` 
                    : '<span style="color:var(--text-secondary);">None</span>';
                
                tr.innerHTML = `
                    <td>
                        <div style="font-weight: 600; color:var(--text-primary);">${lead.company_name}</div>
                        <div style="font-size: 11.5px; color: var(--text-secondary); margin-top: 2px;">👤 ${displayContactName}</div>
                    </td>
                    <td class="monospace">${lead.contact_email}</td>
                    <td>${websiteLink}</td>
                    <td><span class="status status-${lead.status}">${lead.status}</span></td>
                    <td class="monospace">${formattedSent}</td>
                    <td>
                        <div class="actions-cell">
                            <button class="btn-action" onclick="inspectBrief(${lead.id})">🔍 Inspect Brief</button>
                            ${lead.status !== 'replied' ? `<button class="btn-action btn-replied" onclick="markAsReplied(${lead.id})">✔ Replied</button>` : ''}
                            <button class="btn-action btn-delete" onclick="deleteLead(${lead.id})">✕ Remove</button>
                        </div>
                    </td>
                `;
                tbody.appendChild(tr);
            });
            
            // Update pagination text & buttons
            document.getElementById('pagination-info').textContent = `Showing ${startIndex + 1}-${endIndex} of ${filtered.length} prospects`;
            document.getElementById('btn-prev').disabled = currentPage === 1;
            document.getElementById('btn-next').disabled = endIndex >= filtered.length;
        }

        // Run render on initial loading
        window.onload = () => {
            renderTable();
        };
    </script>
</body>
</html>
"""

def get_db_connection():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def index():
    conn = get_db_connection()
    leads_rows = conn.execute('SELECT * FROM leads ORDER BY created_at DESC').fetchall()
    
    # Map row objects to clean lists of dicts for client JSON injection
    leads_list = []
    for r in leads_rows:
        leads_list.append({
            'id': r['id'],
            'company_name': r['company_name'],
            'contact_name': r['contact_name'],
            'contact_email': r['contact_email'],
            'website': r['website'],
            'practice_areas': r['practice_areas'],
            'status': r['status'],
            'generated_email': r['generated_email'],
            'created_at': r['created_at'].strftime('%Y-%m-%d %H:%M:%S') if r['created_at'] else None,
            'sent_at': r['sent_at'].strftime('%Y-%m-%d %H:%M:%S') if r['sent_at'] else None
        })
        
    from datetime import datetime
    today = datetime.now().strftime('%Y-%m-%d')
    
    total = conn.execute('SELECT COUNT(*) FROM leads').fetchone()[0]
    sent = conn.execute("SELECT COUNT(*) FROM leads WHERE status IN ('sent', 'followed_up')").fetchone()[0]
    replied = conn.execute("SELECT COUNT(*) FROM leads WHERE status = 'replied'").fetchone()[0]
    pending = conn.execute("SELECT COUNT(*) FROM leads WHERE status = 'pending'").fetchone()[0]
    failed = conn.execute("SELECT COUNT(*) FROM leads WHERE status = 'failed'").fetchone()[0]
    
    # Calculate Dynamic Reply Rate %
    total_contacted = sent + replied
    reply_rate = round((replied / total_contacted) * 100, 1) if total_contacted > 0 else 0.0
    
    stats = {
        'total': total,
        'sent': sent,
        'replied': replied,
        'pending': pending,
        'failed': failed,
        'reply_rate': reply_rate
    }
    
    # Check current Play/Pause Campaign state
    state = 'running'
    if os.path.exists("campaign_state.txt"):
        with open("campaign_state.txt", "r") as f:
            file_state = f.read().strip().lower()
            if file_state in ['running', 'paused']:
                state = file_state
                
    conn.close()
    
    # Import json safely into HTML Template injection
    import json
    return render_template_string(HTML_TEMPLATE, leads_json=json.dumps(leads_list), stats=stats, state=state)

@app.route('/leads_api')
def leads_api():
    conn = get_db_connection()
    leads_rows = conn.execute('SELECT * FROM leads ORDER BY created_at DESC').fetchall()
    
    leads_list = []
    for r in leads_rows:
        leads_list.append({
            'id': r['id'],
            'company_name': r['company_name'],
            'contact_name': r['contact_name'],
            'contact_email': r['contact_email'],
            'website': r['website'],
            'practice_areas': r['practice_areas'],
            'status': r['status'],
            'generated_email': r['generated_email'],
            'created_at': r['created_at'].strftime('%Y-%m-%d %H:%M:%S') if r['created_at'] else None,
            'sent_at': r['sent_at'].strftime('%Y-%m-%d %H:%M:%S') if r['sent_at'] else None
        })
        
    total = conn.execute('SELECT COUNT(*) FROM leads').fetchone()[0]
    sent = conn.execute("SELECT COUNT(*) FROM leads WHERE status IN ('sent', 'followed_up')").fetchone()[0]
    replied = conn.execute("SELECT COUNT(*) FROM leads WHERE status = 'replied'").fetchone()[0]
    pending = conn.execute("SELECT COUNT(*) FROM leads WHERE status = 'pending'").fetchone()[0]
    failed = conn.execute("SELECT COUNT(*) FROM leads WHERE status = 'failed'").fetchone()[0]
    
    total_contacted = sent + replied
    reply_rate = round((replied / total_contacted) * 100, 1) if total_contacted > 0 else 0.0
    
    stats = {
        'total': total,
        'sent': sent,
        'replied': replied,
        'pending': pending,
        'failed': failed,
        'reply_rate': reply_rate
    }
    
    conn.close()
    return jsonify({'leads': leads_list, 'stats': stats})

@app.route('/toggle_campaign', methods=['POST'])
def toggle_campaign():
    data = request.json or {}
    new_state = data.get('state', 'running').strip().lower()
    
    if new_state not in ['running', 'paused']:
        return jsonify({'status': 'error', 'message': 'Invalid state'}), 400
        
    with open("campaign_state.txt", "w") as f:
        f.write(new_state)
        
    return jsonify({'status': 'success', 'state': new_state})

@app.route('/add_lead', methods=['POST'])
def add_lead_route():
    data = request.json or {}
    company_name = data.get('company_name', '').strip()
    contact_name = data.get('contact_name', '').strip()
    contact_email = data.get('contact_email', '').strip()
    website = data.get('website', '').strip()
    practice_areas = data.get('practice_areas', '').strip()
    
    if not company_name or not contact_email:
        return jsonify({'status': 'error', 'message': 'Company name and Email are required'}), 400
        
    conn = get_db_connection()
    try:
        conn.execute('''
            INSERT INTO leads (company_name, contact_name, contact_email, website, practice_areas, created_at, status)
            VALUES (?, ?, ?, ?, ?, ?, 'pending')
        ''', (company_name, contact_name, contact_email, website, practice_areas, datetime.now()))
        conn.commit()
        conn.close()
        return jsonify({'status': 'success', 'message': 'Prospect added successfully'})
    except sqlite3.IntegrityError:
        conn.close()
        return jsonify({'status': 'error', 'message': 'Prospect email already exists in database'}), 400

@app.route('/update_status/<int:lead_id>', methods=['POST'])
def update_status(lead_id):
    data = request.json or {}
    status = data.get('status', '').strip().lower()
    if status not in ['pending', 'generated', 'sent', 'replied', 'followed_up', 'failed']:
        return jsonify({'status': 'error', 'message': 'Invalid status'}), 400
        
    conn = get_db_connection()
    conn.execute("UPDATE leads SET status = ? WHERE id = ?", (status, lead_id))
    conn.commit()
    conn.close()
    return jsonify({'status': 'success'})

@app.route('/delete_lead/<int:lead_id>', methods=['POST'])
def delete_lead(lead_id):
    conn = get_db_connection()
    conn.execute("DELETE FROM leads WHERE id = ?", (lead_id,))
    conn.commit()
    conn.close()
    return jsonify({'status': 'success'})

@app.route('/import_csv', methods=['POST'])
def import_csv():
    if 'csv_file' not in request.files:
        return jsonify({'status': 'error', 'message': 'No file uploaded'}), 400
    file = request.files['csv_file']
    if file.filename == '':
        return jsonify({'status': 'error', 'message': 'No file selected'}), 400
    
    try:
        stream = io.StringIO(file.stream.read().decode("UTF8"), newline=None)
        csv_input = csv.reader(stream)
        
        # Read header row
        try:
            header = next(csv_input)
        except StopIteration:
            return jsonify({'status': 'error', 'message': 'Empty CSV file'}), 400
            
        header_lower = [h.lower().strip() for h in header]
        
        # Map headers to our fields
        col_mapping = {
            'company_name': -1,
            'contact_name': -1,
            'contact_email': -1,
            'website': -1,
            'practice_areas': -1
        }
        
        for idx, h in enumerate(header_lower):
            if 'company' in h or 'business' in h:
                col_mapping['company_name'] = idx
            elif 'contact_name' in h or 'contact name' in h or h == 'name':
                col_mapping['contact_name'] = idx
            elif 'email' in h or 'mail' in h:
                col_mapping['contact_email'] = idx
            elif 'website' in h or 'url' in h or 'site' in h:
                col_mapping['website'] = idx
            elif 'practice' in h or 'industry' in h or 'specialty' in h or 'city' in h:
                col_mapping['practice_areas'] = idx
                
        # Positional guess fallbacks
        if col_mapping['company_name'] == -1 and len(header) > 0: col_mapping['company_name'] = 0
        if col_mapping['contact_name'] == -1 and len(header) > 1: col_mapping['contact_name'] = 1
        if col_mapping['contact_email'] == -1 and len(header) > 2: col_mapping['contact_email'] = 2
        if col_mapping['website'] == -1 and len(header) > 3: col_mapping['website'] = 3
        if col_mapping['practice_areas'] == -1 and len(header) > 4: col_mapping['practice_areas'] = 4
        
        # Ensure company and email mapped
        if col_mapping['contact_email'] == -1 or col_mapping['company_name'] == -1:
            col_mapping['company_name'] = 0
            col_mapping['contact_email'] = min(2, len(header)-1)
            
        conn = get_db_connection()
        added_count = 0
        dup_count = 0
        
        for row in csv_input:
            if not row:
                continue
            try:
                c_name = row[col_mapping['company_name']].strip() if col_mapping['company_name'] < len(row) else ''
                c_email = row[col_mapping['contact_email']].strip() if col_mapping['contact_email'] < len(row) else ''
                
                if not c_name or not c_email:
                    continue
                    
                cnt_name = row[col_mapping['contact_name']].strip() if (col_mapping['contact_name'] != -1 and col_mapping['contact_name'] < len(row)) else ''
                web = row[col_mapping['website']].strip() if (col_mapping['website'] != -1 and col_mapping['website'] < len(row)) else ''
                prac = row[col_mapping['practice_areas']].strip() if (col_mapping['practice_areas'] != -1 and col_mapping['practice_areas'] < len(row)) else ''
                
                conn.execute('''
                    INSERT INTO leads (company_name, contact_name, contact_email, website, practice_areas, created_at, status)
                    VALUES (?, ?, ?, ?, ?, ?, 'pending')
                ''', (c_name, cnt_name, c_email, web, prac, datetime.now()))
                added_count += 1
            except sqlite3.IntegrityError:
                dup_count += 1
            except Exception:
                continue
                
        conn.commit()
        conn.close()
        
        return jsonify({'status': 'success', 'added': added_count, 'duplicates': dup_count})
    except Exception as e:
        return jsonify({'status': 'error', 'message': f'CSV parsing failed: {str(e)}'}), 500

if __name__ == '__main__':
    # Launch Flask on port 5050
    app.run(port=5050, debug=True)
