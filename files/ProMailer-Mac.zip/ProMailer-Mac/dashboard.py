from flask import Flask, render_template_string, request
import sqlite3
import os
from database import DB_NAME

app = Flask(__name__)

HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>ProMailer Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Fira+Code:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-color: #080a0c;
            --card-bg: #0f141c;
            --border-color: #1c2636;
            --text-primary: #e6edf3;
            --text-secondary: #8b949e;
            --accent-blue: #58a6ff;
            --accent-cyan: #00f2fe;
            --status-pending: #d29922;
            --status-sent: #388bfd;
            --status-replied: #30a14e;
            --status-followed: #bc8cff;
            --status-generated: #565656;
        }

        body {
            font-family: 'Fira Code', 'Courier New', Courier, monospace;
            background: var(--bg-color);
            background-image: 
                radial-gradient(var(--border-color) 1px, transparent 0),
                radial-gradient(var(--border-color) 1px, transparent 0);
            background-size: 40px 40px;
            background-position: 0 0, 20px 20px;
            color: var(--text-primary);
            margin: 0;
            padding: 40px 20px;
            min-height: 100vh;
        }

        .container {
            max-width: 1100px;
            margin: 0 auto;
            background: rgba(15, 20, 28, 0.85);
            backdrop-filter: blur(12px);
            border: 1px solid var(--border-color);
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.5);
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 20px;
            margin-bottom: 30px;
        }

        h1 {
            color: var(--text-primary);
            font-size: 26px;
            margin: 0;
            font-weight: 700;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        h1 span {
            color: var(--accent-cyan);
            text-shadow: 0 0 10px rgba(0, 242, 254, 0.4);
        }

        .tagline {
            font-size: 12px;
            color: var(--text-secondary);
            margin-top: 4px;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin-bottom: 35px;
        }

        .stat-card {
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            padding: 20px;
            border-radius: 8px;
            position: relative;
            overflow: hidden;
            transition: transform 0.2s, border-color 0.2s;
        }

        .stat-card:hover {
            transform: translateY(-2px);
            border-color: var(--accent-blue);
        }

        .stat-card::after {
            content: '';
            position: absolute;
            top: 0; left: 0; width: 4px; height: 100%;
            background: var(--accent-blue);
        }
        
        .stat-card.total::after { background: var(--accent-cyan); }
        .stat-card.sent::after { background: var(--status-sent); }
        .stat-card.replied::after { background: var(--status-replied); }
        .stat-card.pending::after { background: var(--status-pending); }

        .stat-card h3 {
            margin: 0;
            font-size: 11px;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .stat-card p {
            font-size: 32px;
            font-weight: 700;
            margin: 10px 0 0;
            color: var(--text-primary);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th, td {
            text-align: left;
            padding: 14px 16px;
            border-bottom: 1px solid var(--border-color);
            font-size: 13px;
        }

        th {
            background: rgba(28, 38, 54, 0.4);
            color: var(--text-secondary);
            font-weight: 500;
            text-transform: uppercase;
            font-size: 11px;
            letter-spacing: 0.5px;
        }

        tr:hover td {
            background: rgba(88, 166, 255, 0.03);
        }

        .status {
            padding: 4px 10px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            display: inline-block;
        }

        .status-pending { background: rgba(210, 153, 34, 0.15); color: var(--status-pending); border: 1px solid rgba(210, 153, 34, 0.3); }
        .status-sent { background: rgba(56, 139, 253, 0.15); color: var(--status-sent); border: 1px solid rgba(56, 139, 253, 0.3); }
        .status-followed_up { background: rgba(188, 140, 255, 0.15); color: var(--status-followed); border: 1px solid rgba(188, 140, 255, 0.3); }
        .status-replied { background: rgba(48, 161, 78, 0.15); color: var(--status-replied); border: 1px solid rgba(48, 161, 78, 0.3); }
        .status-generated { background: rgba(86, 86, 86, 0.15); color: var(--status-generated); border: 1px solid rgba(86, 86, 86, 0.3); }

        .btn-view {
            background: transparent;
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            padding: 6px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 11px;
            font-family: inherit;
            transition: all 0.2s;
        }

        .btn-view:hover {
            border-color: var(--accent-cyan);
            color: var(--accent-cyan);
            box-shadow: 0 0 8px rgba(0, 242, 254, 0.15);
        }

        .email-row td {
            padding: 0;
            border: none;
        }

        .email-view {
            background: #0b0f15;
            padding: 20px;
            border: 1px solid var(--border-color);
            border-top: none;
            margin: 0 16px 20px 16px;
            white-space: pre-wrap;
            color: #c9d1d9;
            font-size: 12px;
            line-height: 1.6;
            border-radius: 0 0 6px 6px;
            box-shadow: inset 0 2px 8px rgba(0,0,0,0.4);
        }
        
        .footer {
            margin-top: 40px;
            text-align: center;
            font-size: 11px;
            color: var(--text-secondary);
        }
        
        .footer a {
            color: var(--accent-cyan);
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <div>
                <h1>⚡ ProMailer <span>Sovereign Outreach</span></h1>
                <div class="tagline">Local-first, air-gapped cold email compiler & engine</div>
            </div>
            <div>
                <span style="font-size: 11px; color: var(--text-secondary);">Active Port: 5050</span>
            </div>
        </header>
        
        <div class="stats">
            <div class="stat-card total">
                <h3>Total Prospects</h3>
                <p>{{ stats.total }}</p>
            </div>
            <div class="stat-card sent">
                <h3>Outbox Today</h3>
                <p>{{ stats.sent_today }}</p>
            </div>
            <div class="stat-card replied">
                <h3>Replies Received</h3>
                <p>{{ stats.replied }}</p>
            </div>
            <div class="stat-card pending">
                <h3>Pipeline Queue</h3>
                <p>{{ stats.pending }}</p>
            </div>
        </div>

        <table>
            <thead>
                <tr>
                    <th>Business / Contact Name</th>
                    <th>Email Address</th>
                    <th>Outreach Status</th>
                    <th>Last Sent / Active</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                {% for lead in leads %}
                <tr>
                    <td>
                        <div style="font-weight: 600;">{{ lead.company_name }}</div>
                        <div style="font-size: 11px; color: var(--text-secondary); margin-top: 2px;">{{ lead.contact_name or 'N/A' }}</div>
                    </td>
                    <td>{{ lead.contact_email }}</td>
                    <td><span class="status status-{{ lead.status }}">{{ lead.status }}</span></td>
                    <td>{{ lead.sent_at or 'Waiting' }}</td>
                    <td><button class="btn-view" onclick="viewEmail('{{ lead.id }}')">Inspect Brief</button></td>
                </tr>
                <tr class="email-row" id="email-{{ lead.id }}" style="display:none;">
                    <td colspan="5">
                        <div class="email-view">{{ lead.generated_email or 'No campaign text compiled yet.' }}</div>
                    </td>
                </tr>
                {% endfor %}
            </tbody>
        </table>
        
        <div class="footer">
            Sovereign pipeline powered by <a href="https://justmemedia.ca" target="_blank">Just Me Media</a> — © 2026 ProMailer. All Rights Reserved.
        </div>
    </div>

    <script>
        function viewEmail(id) {
            var el = document.getElementById('email-' + id);
            el.style.display = (el.style.display === 'none' || el.style.display === '') ? 'table-row' : 'none';
        }
    </script>
</body>
</html>
"""

def get_db_connection():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def index():
    conn = get_db_connection()
    leads = conn.execute('SELECT * FROM leads ORDER BY created_at DESC').fetchall()
    
    from datetime import datetime
    today = datetime.now().strftime('%Y-%m-%d')
    
    stats = {
        'total': conn.execute('SELECT COUNT(*) FROM leads').fetchone()[0],
        'sent_today': conn.execute("SELECT COUNT(*) FROM leads WHERE status IN ('sent', 'followed_up') AND sent_at LIKE ?", (f"{today}%",)).fetchone()[0],
        'replied': conn.execute("SELECT COUNT(*) FROM leads WHERE status = 'replied'").fetchone()[0],
        'pending': conn.execute("SELECT COUNT(*) FROM leads WHERE status = 'pending'").fetchone()[0],
    }
    
    conn.close()
    return render_template_string(HTML_TEMPLATE, leads=leads, stats=stats)

if __name__ == '__main__':
    # Launch Flask on port 5050
    app.run(port=5050, debug=True)
