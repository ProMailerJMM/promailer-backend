import os
import requests
from dotenv import load_dotenv

# Ensure environment variables are loaded
load_dotenv()

def generate_text(prompt: str, system_prompt: str = None) -> str:
    """
    Unified LLM text generation service supporting Ollama, OpenAI, and Anthropic.
    Requires no heavy external SDKs (uses requests directly).
    """
    provider = os.getenv("LLM_PROVIDER", "ollama").lower().strip()

    if provider == "openai":
        return _generate_openai(prompt, system_prompt)
    elif provider == "anthropic":
        return _generate_anthropic(prompt, system_prompt)
    else:
        # Default fallback is Ollama
        return _generate_ollama(prompt)

def _generate_ollama(prompt: str) -> str:
    ollama_url = os.getenv("OLLAMA_URL", "http://localhost:11434/api/generate")
    ollama_model = os.getenv("OLLAMA_MODEL", "llama3.2:3b")
    
    payload = {
        "model": ollama_model,
        "prompt": prompt,
        "stream": False
    }
    
    try:
        response = requests.post(ollama_url, json=payload, timeout=60)
        response.raise_for_status()
        return response.json().get("response", "").strip()
    except Exception as e:
        print(f"[Ollama] Generation failed: {e}")
        raise e

def _generate_openai(prompt: str, system_prompt: str = None) -> str:
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise ValueError("OPENAI_API_KEY is not configured in .env")
        
    model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    sys_content = system_prompt if system_prompt else "You are a professional outreach assistant."
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": sys_content},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.7
    }
    
    try:
        response = requests.post("https://api.openai.com/v1/chat/completions", headers=headers, json=payload, timeout=30)
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"].strip()
    except Exception as e:
        print(f"[OpenAI] Generation failed: {e}")
        raise e

def _generate_anthropic(prompt: str, system_prompt: str = None) -> str:
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        raise ValueError("ANTHROPIC_API_KEY is not configured in .env")
        
    model = os.getenv("ANTHROPIC_MODEL", "claude-3-5-haiku-20241022")
    
    headers = {
        "x-api-key": api_key,
        "anthropic-version": "2023-06-01",
        "Content-Type": "application/json"
    }
    
    payload = {
        "model": model,
        "max_tokens": 1024,
        "messages": [
            {"role": "user", "content": prompt}
        ]
    }
    
    if system_prompt:
        payload["system"] = system_prompt
        
    try:
        response = requests.post("https://api.anthropic.com/v1/messages", headers=headers, json=payload, timeout=30)
        response.raise_for_status()
        return response.json()["content"][0]["text"].strip()
    except Exception as e:
        print(f"[Anthropic] Generation failed: {e}")
        raise e
