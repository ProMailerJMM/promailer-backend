import os
import sys
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import requests
import time
from dotenv import load_dotenv
from database import init_db, add_lead, get_pending_leads, update_lead_status
from prompt_templates import OLLAMA_PROMPT
from scraper import scrape_website
from datetime import datetime, timedelta

# Check for setup or reconfiguration flag before loading env
if "--setup" in sys.argv or "--reconfigure" in sys.argv:
    import setup_wizard
    setup_wizard.run_wizard()
    sys.exit(0)

# Check if .env exists, if not run first-run setup wizard
if not os.path.exists(".env"):
    print("[ProMailer] Configuration file (.env) not found. Launching Setup Wizard...")
    import setup_wizard
    setup_wizard.run_wizard()

# Load environment variables
load_dotenv()

SMTP_SERVER = os.getenv("SMTP_SERVER", "smtp.gmail.com")
try:
    SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
except ValueError:
    SMTP_PORT = 587
SMTP_USER = os.getenv("SMTP_USER") or os.getenv("GMAIL_USER")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD") or os.getenv("GMAIL_APP_PASSWORD")
SENDER_NAME = os.getenv("SENDER_NAME") or "William Commu"

# Maintain variables for backward compatibility
GMAIL_USER = SMTP_USER
GMAIL_APP_PASSWORD = SMTP_PASSWORD

# Import the centralized LLM text generation service
from llm import generate_text

MAX_EMAILS_PER_DAY = 20
SEND_GAP_SECONDS = 240 # test only

def generate_email(lead, website_content=""):
    # lead tuple: (id, company_name, contact_name, contact_email, website, practice_areas, status, generated_email, created_at, sent_at)
    prompt = OLLAMA_PROMPT.format(
        company_name=lead[1],
        contact_name=lead[2] if lead[2] else "there",
        website=lead[4],
        practice_areas=lead[5],
        website_content=website_content
    )
    
    try:
        # Use our robust, unified multi-LLM orchestrator (Ollama, OpenAI, or Anthropic)
        return generate_text(prompt, system_prompt="You are a professional email outreach assistant. Substitute names, ensure absolute plain-text and warm personal tone.")
    except Exception as e:
        print(f"[ProMailer] Error generating email for {lead[3]}: {e}")
        return None

def send_email(to_email, subject, body_text):
    msg = MIMEMultipart()
    msg['From'] = f"{SENDER_NAME} <{SMTP_USER}>"
    msg['To'] = to_email
    msg['Subject'] = subject
    
    reply_to = os.getenv("REPLY_TO")
    print(f"[ProMailer] Sending from {msg['From']} with Reply-To {reply_to or SMTP_USER}")
    if reply_to:
        msg['Reply-To'] = reply_to

    # Plain text for that personal cold-email feel
    msg.attach(MIMEText(body_text, 'plain'))

    try:
        if SMTP_PORT == 465:
            server = smtplib.SMTP_SSL(SMTP_SERVER, SMTP_PORT)
        else:
            server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
            server.starttls()
            
        server.login(SMTP_USER, SMTP_PASSWORD)
        server.send_message(msg)
        server.quit()
        return True
    except Exception as e:
        print(f"[ProMailer] Failed to send email to {to_email}: {e}")
        return False

def get_sends_today():
    from database import DB_NAME
    import sqlite3
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    today = datetime.now().strftime('%Y-%m-%d')
    cursor.execute("SELECT COUNT(*) FROM leads WHERE status IN ('sent', 'followed_up') AND sent_at LIKE ?", (f"{today}%",))
    count = cursor.fetchone()[0]
    conn.close()
    return count

def process_pipeline():
    leads = get_pending_leads()
    if not leads:
        print("[ProMailer] No pending leads found in the pipeline.")
        return

    print(f"[ProMailer] Found {len(leads)} pending leads. Starting outreach...")
    
    for lead in leads:
        # Check daily limit
        if get_sends_today() >= MAX_EMAILS_PER_DAY:
            print(f"[ProMailer] Daily limit of {MAX_EMAILS_PER_DAY} emails reached. Stopping for today.")
            break

        lead_id = lead[0]
        company_name = lead[1]
        contact_email = lead[3]
        website_url = lead[4]
        
        print(f"\n--- [ProMailer] Processing Lead: {company_name} ({contact_email}) ---")
        
        # Step 1: Scrape website
        print(f"1. Scraping website: {website_url}...")
        website_content = scrape_website(website_url)

        # Step 2: Generate email
        print("2. Generating personalized email using active AI provider...")
        email_body = generate_email(lead, website_content=website_content)
        
        if email_body:
            print("3. Email generated successfully. Saving to database...")
            update_lead_status(lead_id, 'generated', generated_email=email_body)
            
            # Step 3: Send email
            subject = f"Quick question regarding {company_name}"
            
            print(f"4. Sending email via Gmail SMTP ({GMAIL_USER})...")
            if send_email(contact_email, subject, email_body):
                print(f"[ProMailer] Success! Email sent to {contact_email}.")
                update_lead_status(lead_id, 'sent', sent_at=datetime.now())
                
                # Polite delay to avoid rate limits
                print(f"Waiting {SEND_GAP_SECONDS} seconds before the next lead (Rate Limiting)...")
                time.sleep(SEND_GAP_SECONDS)
            else:
                print(f"[ProMailer] Error: Failed to send email to {contact_email}")
        else:
            print("[ProMailer] Error: Failed to generate email text.")

def seed_test_lead():
    add_lead(
        company_name="Acme Corp", 
        contact_name="John", 
        contact_email="william@justmemedia.ca", # Test lead
        website="acmecorp.com", 
        practice_areas="SaaS, B2B Software"
    )

if __name__ == "__main__":
    init_db()
    
    # Process the pipeline
    process_pipeline()
