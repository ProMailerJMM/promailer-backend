import sys
import os

try:
    from AppKit import NSImage, NSWorkspace
except ImportError:
    print("PyObjC or AppKit not installed on this system.")
    print("Cannot set custom Finder icons programmatically.")
    sys.exit(1)

def set_icon(image_path, file_path):
    if not os.path.exists(image_path):
        print(f"Error: Image path not found: {image_path}")
        return False
    if not os.path.exists(file_path):
        print(f"Error: Target path not found: {file_path}")
        return False
        
    # Load the image
    image = NSImage.alloc().initWithContentsOfFile_(image_path)
    if not image:
        print(f"Error: Could not load image from {image_path}")
        return False
        
    # Set the Finder icon
    success = NSWorkspace.sharedWorkspace().setIcon_forFile_options_(image, file_path, 0)
    if success:
        print(f"Successfully applied ProMailer branding to: {os.path.basename(file_path)}")
        return True
    else:
        print(f"Failed to apply branding to: {os.path.basename(file_path)}")
        return False

if __name__ == "__main__":
    script_dir = os.path.dirname(os.path.abspath(__file__))
    image_path = os.path.join(script_dir, "promailer.png")
    
    # 1. Target local command files inside the directory
    command_files = [os.path.join(script_dir, f) for f in os.listdir(script_dir) if f.endswith(".command")]
    
    # 2. Target desktop launchers if they are present
    desktop_dir = os.path.expanduser("~/Desktop")
    desktop_launchers = [
        os.path.join(desktop_dir, "ProMailer_Dashboard.command"),
        os.path.join(desktop_dir, "ProMailer_Send_Outreach.command")
    ]
    
    for dl in desktop_launchers:
        if os.path.exists(dl):
            command_files.append(dl)
            
    print(f"Loading ProMailer logo asset from: {image_path}")
    
    for f in command_files:
        set_icon(image_path, f)
