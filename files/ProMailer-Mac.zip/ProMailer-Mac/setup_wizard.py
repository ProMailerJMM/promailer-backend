import os
import sys
import requests
import json

# Setup CLI styles
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
BLUE = "\033[94m"
BOLD = "\033[1m"
RESET = "\033[0m"

def print_header():
    print(f"\n{BOLD}{BLUE}================================================{RESET}")
    print(f"{BOLD}{BLUE}        PROMAILER — SOVEREIGN SETUP WIZARD      {RESET}")
    print(f"{BOLD}{BLUE}================================================{RESET}")
    print("Welcome to your local-first cold outreach system.\n")

def validate_openai(key):
    print("Validating OpenAI API Key...")
    headers = {
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": "gpt-4o-mini",
        "messages": [{"role": "user", "content": "ping"}],
        "max_tokens": 1
    }
    try:
        response = requests.post("https://api.openai.com/v1/chat/completions", headers=headers, json=payload, timeout=10)
        if response.status_code == 200:
            print(f"{GREEN}✓ OpenAI API Key is valid and active.{RESET}")
            return True
        else:
            err_msg = response.json().get("error", {}).get("message", "Unknown error")
            print(f"{RED}✗ OpenAI Validation Failed: {err_msg}{RESET}")
            return False
    except Exception as e:
        print(f"{RED}✗ OpenAI Connection Error: {e}{RESET}")
        return False

def validate_anthropic(key):
    print("Validating Anthropic API Key...")
    headers = {
        "x-api-key": key,
        "anthropic-version": "2023-06-01",
        "Content-Type": "application/json"
    }
    payload = {
        "model": "claude-3-5-haiku-20241022",
        "max_tokens": 1,
        "messages": [{"role": "user", "content": "ping"}]
    }
    try:
        response = requests.post("https://api.anthropic.com/v1/messages", headers=headers, json=payload, timeout=10)
        if response.status_code == 200:
            print(f"{GREEN}✓ Anthropic API Key is valid and active.{RESET}")
            return True
        else:
            err_msg = response.json().get("error", {}).get("message", "Unknown error")
            print(f"{RED}✗ Anthropic Validation Failed: {err_msg}{RESET}")
            return False
    except Exception as e:
        print(f"{RED}✗ Anthropic Connection Error: {e}{RESET}")
        return False

def validate_ollama(url, model):
    print(f"Connecting to local Ollama at {url}...")
    try:
        response = requests.get(f"{url.replace('/api/generate', '')}/api/tags", timeout=5)
        if response.status_code == 200:
            print(f"{GREEN}✓ Ollama Connection Active.{RESET}")
            models = [m["name"] for m in response.json().get("models", [])]
            if any(model in m for m in models):
                print(f"{GREEN}✓ Model '{model}' found locally.{RESET}")
            else:
                print(f"{YELLOW}! Warning: Model '{model}' not found in Ollama local library. ProMailer will attempt to run, but ensure you run 'ollama pull {model}' before starting.{RESET}")
            return True
        else:
            print(f"{RED}✗ Ollama active but returned status {response.status_code}.{RESET}")
            return False
    except Exception as e:
        print(f"{YELLOW}! Warning: Could not connect to local Ollama. Ensure Ollama.app is running on port 11434.{RESET}")
        return True # Permit offline configuration

def run_wizard():
    print_header()

    # Step 1: Select LLM Provider
    provider = ""
    while provider not in ["1", "2", "3"]:
        print(f"{BOLD}1. Select AI Text Generation Provider:{RESET}")
        print("  [1] Ollama (Sovereign Local — Free)")
        print("  [2] OpenAI API (Cloud — Usage Costs apply)")
        print("  [3] Anthropic API (Cloud — Usage Costs apply)")
        provider = input("Choose option [1-3] (Default: 1): ").strip()
        if not provider:
            provider = "1"

    provider_map = {"1": "ollama", "2": "openai", "3": "anthropic"}
    llm_provider = provider_map[provider]

    openai_key = ""
    anthropic_key = ""
    ollama_url = "http://localhost:11434/api/generate"
    ollama_model = "llama3.2:3b"

    # Step 2: Configure & Validate Provider Keys
    if llm_provider == "openai":
        validated = False
        while not validated:
            openai_key = input("\nEnter your OpenAI API Key (sk-...): ").strip()
            if not openai_key:
                print(f"{RED}Error: OpenAI API Key is required.{RESET}")
                continue
            validated = validate_openai(openai_key)
            if not validated:
                retry = input("Try again? [y/N]: ").strip().lower()
                if retry != 'y':
                    print("Exiting setup.")
                    sys.exit(1)
                    
    elif llm_provider == "anthropic":
        validated = False
        while not validated:
            anthropic_key = input("\nEnter your Anthropic API Key (sk-ant-...): ").strip()
            if not anthropic_key:
                print(f"{RED}Error: Anthropic API Key is required.{RESET}")
                continue
            validated = validate_anthropic(anthropic_key)
            if not validated:
                retry = input("Try again? [y/N]: ").strip().lower()
                if retry != 'y':
                    print("Exiting setup.")
                    sys.exit(1)
                    
    else:
        # Ollama configuration
        url_input = input(f"\nEnter Ollama API Endpoint [Default: {ollama_url}]: ").strip()
        if url_input:
            ollama_url = url_input
        model_input = input(f"Enter Ollama Model [Default: {ollama_model}]: ").strip()
        if model_input:
            ollama_model = model_input
        validate_ollama(ollama_url, ollama_model)

    # Step 3: Configure SMTP Outbox credentials
    print(f"\n{BOLD}2. Configure SMTP Outbox Provider:{RESET}")
    print("  [1] Gmail SMTP (Default — requires 16-character App Password)")
    print("  [2] Custom SMTP Server (SendGrid, Mailgun, Brevo, Resend, Amazon SES, etc.)")
    smtp_choice = input("Choose option [1-2] (Default: 1): ").strip()
    if not smtp_choice:
        smtp_choice = "1"
        
    smtp_server = "smtp.gmail.com"
    smtp_port = "587"
    smtp_user = ""
    smtp_password = ""
    sender_name = "William Commu"
    
    if smtp_choice == "1":
        # Gmail SMTP Setup
        print(f"\n{BOLD}Configure Gmail Credentials:{RESET}")
        while not smtp_user:
            smtp_user = input("Gmail Username (sender email): ").strip()
            if not smtp_user:
                print(f"{RED}Error: Gmail Username is required.{RESET}")
        while not smtp_password:
            smtp_password = input("Gmail 16-character App Password: ").strip()
            if not smtp_password:
                print(f"{RED}Error: Gmail App Password is required.{RESET}")
        
        name_input = input("Sender Display Name [Default: William Commu]: ").strip()
        if name_input:
            sender_name = name_input
    else:
        # Custom SMTP Setup
        print(f"\n{BOLD}Configure Custom SMTP Server:{RESET}")
        server_input = input("SMTP Server Host (e.g. smtp.sendgrid.net): ").strip()
        if server_input:
            smtp_server = server_input
        else:
            print(f"{RED}Error: SMTP Server Host is required.{RESET}")
            sys.exit(1)
            
        port_input = input("SMTP Server Port [Default: 587]: ").strip()
        if port_input:
            smtp_port = port_input
            
        while not smtp_user:
            smtp_user = input("SMTP Username: ").strip()
            if not smtp_user:
                print(f"{RED}Error: SMTP Username is required.{RESET}")
                
        while not smtp_password:
            smtp_password = input("SMTP Password: ").strip()
            if not smtp_password:
                print(f"{RED}Error: SMTP Password is required.{RESET}")
                
        while not sender_name or sender_name == "William Commu":
            sender_name = input("Sender Display Name (e.g. William Commu): ").strip()
            if not sender_name:
                print(f"{RED}Error: Sender Display Name is required.{RESET}")

    reply_to = input(f"Custom Reply-To Email [Default: {smtp_user}]: ").strip()
    if not reply_to:
        reply_to = smtp_user

    # Step 4: Write .env
    print(f"\n{BOLD}3. Saving configuration...{RESET}")
    
    with open(".env", "w") as f:
        f.write("# ProMailer Configuration File\n")
        f.write("# Auto-generated by setup_wizard.py\n\n")
        
        f.write(f"SMTP_SERVER={smtp_server}\n")
        f.write(f"SMTP_PORT={smtp_port}\n")
        f.write(f"SMTP_USER={smtp_user}\n")
        f.write(f"SMTP_PASSWORD={smtp_password}\n")
        f.write(f"SENDER_NAME={sender_name}\n")
        f.write(f"REPLY_TO={reply_to}\n\n")
        
        # Maintain Gmail env tags for backward compatibility
        f.write(f"GMAIL_USER={smtp_user}\n")
        f.write(f"GMAIL_APP_PASSWORD={smtp_password}\n\n")
        
        f.write(f"LLM_PROVIDER={llm_provider}\n\n")
        
        f.write(f"OLLAMA_URL={ollama_url}\n")
        f.write(f"OLLAMA_MODEL={ollama_model}\n\n")
        
        f.write(f"OPENAI_API_KEY={openai_key}\n")
        f.write(f"OPENAI_MODEL=gpt-4o-mini\n\n")
        
        f.write(f"ANTHROPIC_API_KEY={anthropic_key}\n")
        f.write(f"ANTHROPIC_MODEL=claude-3-5-haiku-20241022\n")

    # Secure file permissions (standard practice for configuration secrets)
    import platform
    if platform.system() != "Windows":
        try:
            os.chmod(".env", 0o600)
            print(f"{GREEN}✓ Secured file permissions on .env (chmod 600 active).{RESET}")
        except Exception as e:
            print(f"{YELLOW}! Warning: Could not adjust .env file permissions: {e}{RESET}")
    else:
        print(f"{GREEN}✓ Configuration saved securely under Windows profile.{RESET}")

    print(f"\n{GREEN}{BOLD}PROMAILER CONFIGURED SUCCESSFULLY!{RESET}")
    print("Run your campaign using 'python3 main.py' or check stats using 'python3 dashboard.py'.\n")

if __name__ == "__main__":
    run_wizard()
