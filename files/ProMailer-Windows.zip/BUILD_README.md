# ProMailer — Native Executable Build System

Compiles ProMailer into platform-native executables.
Buyers get a **double-click app with zero Python dependency**.

---

## What gets built

| Platform | Output | Buyer experience |
|----------|--------|-----------------|
| macOS    | `ProMailer.app` | Double-click in Finder |
| Windows  | `ProMailer.exe` | Double-click in Explorer |
| Linux    | `ProMailer` binary + `.desktop` | Double-click or run `./ProMailer` |

**First launch** → GUI setup wizard (SMTP + AI provider)  
**Every launch after** → Flask dashboard starts, browser opens automatically at `localhost:5050`

---

## How to build

Each platform must be built **on that platform** (PyInstaller cross-compilation
is not supported). Use a Mac to build the Mac version, Windows for Windows, etc.

### macOS
```bash
cd /path/to/ProMailer
chmod +x build/build_mac.sh
./build/build_mac.sh
# Output: dist/ProMailer.app
zip -r ProMailer-Mac.zip dist/ProMailer.app
```

### Windows
```cmd
cd C:\path\to\ProMailer
build\build_windows.bat
:: Output: dist\ProMailer.exe
```

### Linux
```bash
cd /path/to/ProMailer
chmod +x build/build_linux.sh
./build/build_linux.sh
# Output: dist/ProMailer  +  dist/ProMailer.desktop
tar -czf ProMailer-Linux.tar.gz -C dist ProMailer promailer.png ProMailer.desktop
```

---

## File structure required before building

```
ProMailer/
├── app_launcher.py        ← unified entry point (replaces .command/.bat/.sh)
├── main.py
├── dashboard.py
├── database.py
├── llm.py
├── setup_wizard.py
├── scraper.py
├── prompt_templates.py
├── promailer.png          ← your orange logo (used for .icns/.ico auto-conversion)
├── templates/             ← Flask HTML templates (if any)
├── static/                ← CSS/JS assets (if any)
└── build/
    ├── promailer_mac.spec
    ├── promailer_windows.spec
    ├── promailer_linux.spec
    ├── version_info.txt
    ├── build_mac.sh
    ├── build_windows.bat
    └── build_linux.sh
```

---

## How app_launcher.py works

1. Detects whether `.env` exists next to the executable
2. If missing → launches the **Tkinter GUI setup wizard** (no terminal)
3. If present → starts **Flask dashboard** in a background thread, opens browser
4. Shows a small "ProMailer is running / Quit" window to keep the process alive

The wizard collects: AI provider + API key, SMTP credentials, sender name.  
It writes `.env` with `chmod 600` on Mac/Linux automatically.

---

## Distribution checklist

- [ ] Build on each platform natively
- [ ] Test first-run wizard (delete `.env` to trigger it again)
- [ ] Test dashboard loads at `localhost:5050`
- [ ] Zip/tar the output and upload to `ProMailer-PaymentServer/files/`
- [ ] Push to GitHub → Render auto-deploys

---

## Upgrading

To release a new version:
1. Bump `CFBundleShortVersionString` in `promailer_mac.spec`
2. Bump `filevers` and `FileVersion` in `version_info.txt`
3. Re-run all three build scripts
4. Replace the ZIPs on the payment server
