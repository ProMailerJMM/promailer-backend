# ⚡ ProMailer — Sovereign Cold Outreach Workstation (Windows Edition)

🚀 **QUICK START: Double-click `PROMAILER_DASHBOARD.bat` in this folder to automatically check your environment, start secure database pipelines, open the dark-mode console, and initiate outreach sends on safe background threads!**

---

ProMailer is a local-first, highly deliverable cold outreach engine built to run natively on Windows 10 and 11. By running entirely on your own workstation, you maintain 100% database privacy, absolute file security, and pay zero ongoing middleman subscription SaaS fees.

---

## 🚀 Easy Onboarding (Under 2 Minutes)

### 1. Extract the Application Folder
* **Action:** Right-click `ProMailer-Windows.zip` and select **"Extract All"** to unzip the workspace folder onto your workstation.

### 2. Launch the Control Panel (`PROMAILER_DASHBOARD.bat`)
* **Action:** Double-click `PROMAILER_DASHBOARD.bat` from File Explorer.
* **Result:** Checks if Python is installed and on your PATH (displaying a helpful guide if PATH is missing), installs any missing dependencies (Flask, requests, dotenv, beautifulsoup4), starts your local SQLite WAL database server, and loads the premium web console on **`http://localhost:5050`**!

### 3. Native Setup Wizard
* **First Launch:** On your first run, a clean, dark-themed GUI wizard opens.
* **Setup:** Enter your outbox SMTP credentials, sender display name, custom IMAP server for replies, and chosen AI backend (OpenAI, Anthropic, or 100% local sovereign Ollama).
* **Security:** Credentials are saved securely inside your Windows profile directory next to the database next to your local `.env`.

### 4. Zero-Terminal Campaign & Reply Engine
Once onboarding is complete:
1. The premium dark-theme web console boots automatically on **`http://localhost:5050`** and loads in your default browser.
2. **Campaign outreach and reply tracking run automatically on silent background threads!** As long as the dashboard is running, ProMailer automatically runs campaign dispatches (respecting your daily 20-email limit and a polite 4-minute cool-down delay) and scans for replies on a silent IMAP loop. You do NOT need to execute secondary batch files!

---

## 🔍 In-App AI Lead Finder & Scraper
No more buying lists or scraping websites manually. ProMailer features a built-in search engine:
1. Click the **"Find Leads"** button in the dashboard header.
2. Enter a search query (e.g., `Dentists in Toronto Ontario`) and choose your target size.
3. Click **Find & Enrich Leads**.
4. Watch the glassmorphic terminal log stream active website crawls, extract real-time contact emails (`mailto:` and text regex), filter junk domains, and load them **instantly** into your active SQLite outreach pipeline!

---

## 🔒 100% Sovereign Local AI (Ollama Setup)
To compile outreach copy completely offline and free of cost:
1. Download and run [Ollama for Windows](https://ollama.com).
2. Pull your local language model in command prompt:
   ```cmd
   ollama pull llama3.2:3b
   ```
3. Boot the ProMailer launcher, select Option **[1] (Ollama)** in the setup wizard, and enjoy zero-cost, private text compiling on your GPU/CPU hardware.

---

Sovereign cold outreach engineered by **[Just Me Media](https://justmemedia.ca)**.  
*© 2026 Just Me Media. All rights reserved.*
