# ⚡ ProMailer — Sovereign Cold Outreach Workstation (Windows Edition)

🚀 **QUICK START: Double-click `PROMAILER_DASHBOARD.bat` in this folder to automatically check your Python environment, install required modules, and open your web browser to the premium dark-mode console on `http://localhost:5050`!**

---

ProMailer is a local-first, highly deliverable cold outreach engine built to run natively on Windows 10 and 11. By running entirely on your own desktop, you maintain full data sovereignty, complete database privacy, and pay zero ongoing middleman subscription SaaS fees.

---

## 🚀 Easy Onboarding (Under 2 Minutes)

### 1. 📊 Launch Your Dark-Mode UI (`PROMAILER_DASHBOARD.bat`)
* **Action:** Double-click this file from File Explorer.
* **Result:** Checks if Python is installed and configured on your PATH, automatically installs any missing dependencies (Flask, requests, dotenv, beautifulsoup4), starts your secure database server, and opens your web browser to the premium dark-mode web console on **`http://localhost:5050`**!
* **Control Panel Features:** 
  * 📥 **Load CSV**: Drag-and-drop or select any prospect CSV spreadsheet to parse and load prospects automatically.
  * ➕ **Add Prospect**: Add a single prospect manually inside the UI.
  * 🔍 **Inspect Brief**: Click to open a gorgeous glassmorphic modal containing the custom compiled outreach email for review and clipboard copy.
  * ⏸ **Toggle State (Play/Pause)**: Click the header switch to easily start or pause campaign dispatches.
  * 🗑 **Actions**: Remove duplicate prospects or mark leads as Replied instantly with one click.

### 2. ✉ Run Campaigns (`START_PROMAILER.bat`)
* **Action:** Double-click this file from File Explorer.
* **Result:** Instantly executes your campaign pipeline in a clean Command window. It scrapes target company websites on-the-fly, compiles highly customized personal pitches using your selected AI, respects your 20-email daily outbox limits, and automatically executes with **polite 4-minute cool-down delays** between sends to guarantee elite deliverability directly to primary inboxes.

---

## 🔧 Configure Your Outbox Server
Run the interactive onboard setup wizard to securely connect your outgoing mail servers:
1. Open **Command Prompt** or **PowerShell** (`Win + R` -> type `cmd` or `powershell`).
2. Navigate to this folder: `cd %USERPROFILE%\Downloads\ProMailer-Windows`
3. Execute the setup wizard: `python setup_wizard.py`
*(Supports 1-click Google Workspace/Gmail setup via App Passwords, or any custom SMTP like Resend, SendGrid, Brevo, or Amazon SES).*

---

## 🔒 Local AI & Data Sovereignty
To maintain absolute private, zero-cost, air-gapped text compiling:
1. Download and run [Ollama for Windows](https://ollama.com).
2. Pull your local language model:
   ```cmd
   ollama pull llama3.2:3b
   ```
3. Boot the setup wizard (`python setup_wizard.py`) and select Option `[1]`. Your prompt matrices will now compile completely offline on your computer's local hardware!

---

## 🛡️ File Security & Permissions
Since your configuration files contain plaintext API keys and outbox App Passwords, ProMailer automatically locks down your configurations securely under your Windows User profile settings, ensuring that your private credentials remain structurally unreadable to other system accounts or guest users on your machine.

---
Sovereign cold outreach engineered by **[Just Me Media](https://justmemedia.ca)**.  
*© 2026 Just Me Media. All rights reserved.*
