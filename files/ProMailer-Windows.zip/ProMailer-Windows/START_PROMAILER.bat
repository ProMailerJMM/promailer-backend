@echo off
title ProMailer Campaign Runner
cd /d "%~dp0"
echo [ProMailer] Checking python installation...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ProMailer] Error: Python was not found. Please install Python from python.org.
    pause
    exit /b 1
)
python main.py
echo.
echo [ProMailer] Campaign runner exited. Press any key to close this window.
pause
