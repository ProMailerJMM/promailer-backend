@echo off
title ProMailer Campaign Runner
cd /d "%~dp0"

echo ===================================================
echo             PROMAILER CAMPAIGN RUNNER
echo ===================================================
echo.

:: Check python installation
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python 3 is not installed on your system or is not in your environment PATH!
    echo.
    echo ProMailer requires Python 3 to run. 
    echo Please follow these simple steps to install:
    echo 1. Visit: https://www.python.org/downloads/
    echo 2. Download and run the installer for Windows.
    echo 3. IMPORTANT: Make sure to check the box that says:
    echo    "Add Python to PATH" or "Add python.exe to PATH"
    echo    before clicking Install.
    echo.
    pause
    exit /b 1
)

:: Check/Install dependencies automatically
echo [ProMailer] Verifying required Python modules...
python -c "import flask, dotenv, requests, bs4" >nul 2>&1
if %errorlevel% neq 0 (
    echo [ProMailer] Dependencies missing. Installing now...
    pip install -r requirements.txt
    if %errorlevel% neq 0 (
        echo [ERROR] Failed to install dependencies via pip.
        pause
        exit /b 1
    )
    echo [ProMailer] Dependencies installed successfully!
    echo.
)

:: Run campaign
python main.py
echo.
echo [ProMailer] Campaign runner exited. Press any key to close this window.
pause
