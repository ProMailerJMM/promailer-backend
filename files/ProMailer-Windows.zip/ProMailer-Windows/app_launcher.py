"""
ProMailer — app_launcher.py
Unified entry point for the compiled executable on macOS, Windows, and Linux.

On first run  → shows GUI setup wizard (no terminal needed)
On subsequent runs → starts Flask dashboard and opens browser automatically
"""

import os
import sys
import platform
import threading
import webbrowser
import time
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
from pathlib import Path
from dotenv import load_dotenv

# ── Resolve data path (works both in source and PyInstaller bundle) ───────────
def resource_path(relative):
    base = getattr(sys, '_MEIPASS', Path(__file__).parent)
    return Path(base) / relative

def user_data_dir():
    """Writable directory for .env and pipeline.db — always next to the exe."""
    if getattr(sys, 'frozen', False):
        return Path(sys.executable).parent
    return Path(__file__).parent

DATA_DIR = user_data_dir()
ENV_FILE = DATA_DIR / '.env'

# ── Colours & fonts ───────────────────────────────────────────────────────────
BG       = '#080a0c'
CARD     = '#0f141c'
BORDER   = '#1c2636'
FG       = '#e6edf3'
MUTED    = '#8b949e'
CYAN     = '#00f2fe'
GREEN    = '#30a14e'
RED      = '#f85149'
YELLOW   = '#d29922'
FONT_MONO = ('Courier New', 11) if platform.system() == 'Windows' else ('Menlo', 12)
FONT_UI   = ('Segoe UI', 11)    if platform.system() == 'Windows' else ('Helvetica Neue', 12)
FONT_H1   = ('Segoe UI', 18, 'bold') if platform.system() == 'Windows' else ('Helvetica Neue', 20, 'bold')
FONT_H2   = ('Segoe UI', 13, 'bold') if platform.system() == 'Windows' else ('Helvetica Neue', 14, 'bold')


# ═════════════════════════════════════════════════════════════════════════════
#  GUI SETUP WIZARD
# ═════════════════════════════════════════════════════════════════════════════

class SetupWizard(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('ProMailer — First Run Setup')
        self.configure(bg=BG)
        self.resizable(False, False)

        # Centre window
        w, h = 620, 680
        x = (self.winfo_screenwidth()  - w) // 2
        y = (self.winfo_screenheight() - h) // 2
        self.geometry(f'{w}x{h}+{x}+{y}')

        self._build_ui()

    def _label(self, parent, text, font=None, fg=FG, pady=0):
        lbl = tk.Label(parent, text=text, bg=BG, fg=fg,
                       font=font or FONT_UI, anchor='w')
        lbl.pack(fill='x', pady=(pady, 0))
        return lbl

    def _entry(self, parent, placeholder='', show=None):
        var = tk.StringVar()
        frame = tk.Frame(parent, bg=BORDER, pady=1)
        frame.pack(fill='x', pady=(4, 10))
        e = tk.Entry(frame, textvariable=var, bg=CARD, fg=FG, insertbackground=CYAN,
                     relief='flat', font=FONT_MONO, show=show or '')
        e.pack(fill='x', padx=1, pady=1, ipady=6, ipadx=8)
        if placeholder:
            e.insert(0, placeholder)
            e.config(fg=MUTED)
            def on_focus_in(ev, _e=e, _v=var, _p=placeholder):
                if _e.get() == _p: _e.delete(0, 'end'); _e.config(fg=FG)
            def on_focus_out(ev, _e=e, _v=var, _p=placeholder):
                if not _e.get(): _e.insert(0, _p); _e.config(fg=MUTED)
            e.bind('<FocusIn>',  on_focus_in)
            e.bind('<FocusOut>', on_focus_out)
        return var, e

    def _section(self, parent, title):
        f = tk.Frame(parent, bg=BORDER, height=1)
        f.pack(fill='x', pady=(18, 4))
        tk.Label(parent, text=title, bg=BG, fg=CYAN,
                 font=FONT_H2, anchor='w').pack(fill='x')

    def _build_ui(self):
        # Header
        hdr = tk.Frame(self, bg=CARD, padx=24, pady=18)
        hdr.pack(fill='x')
        tk.Label(hdr, text='⚡ ProMailer Setup', bg=CARD, fg=FG,
                 font=FONT_H1).pack(anchor='w')
        tk.Label(hdr, text='Configure your sovereign outreach workstation — takes about 2 minutes.',
                 bg=CARD, fg=MUTED, font=FONT_UI).pack(anchor='w', pady=(4, 0))

        # Scrollable body
        canvas  = tk.Canvas(self, bg=BG, highlightthickness=0)
        scrollbar = ttk.Scrollbar(self, orient='vertical', command=canvas.yview)
        self.body = tk.Frame(canvas, bg=BG, padx=24)
        self.body.bind('<Configure>',
            lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.create_window((0, 0), window=self.body, anchor='nw')
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side='left', fill='both', expand=True)
        scrollbar.pack(side='right', fill='y')

        body = self.body

        # ── SMTP (Email Sending) ──────────────────────────────────────────────
        self._section(body, '1.  Email Sending (SMTP)')
        self._label(body,
            '⚠  Gmail: use an App Password, NOT your Gmail password.\n'
            '   Create one at: myaccount.google.com → Security → App Passwords',
            fg=YELLOW, pady=4)

        self._label(body, 'Sender email address:')
        self.smtp_user_var, _ = self._entry(body, placeholder='you@gmail.com')

        self._label(body, 'Gmail App Password (16 chars) or SMTP password:')
        self.smtp_pass_var, _ = self._entry(body, show='•')

        self._label(body, 'Your display name (how recipients see you):')
        self.sender_name_var, _ = self._entry(body, placeholder='William from ProMailer')

        self._label(body, 'Reply-To address (leave blank to use sender email):')
        self.reply_to_var, _ = self._entry(body, placeholder='optional@yourdomain.com')

        # Advanced SMTP (collapsed by default)
        self.adv_open = tk.BooleanVar(value=False)
        adv_toggle = tk.Label(body, text='▶  Advanced SMTP settings (SendGrid, Mailgun, etc.)',
                              bg=BG, fg=CYAN, font=(FONT_UI[0], 10), cursor='hand2')
        adv_toggle.pack(anchor='w', pady=(6, 0))

        self.adv_frame = tk.Frame(body, bg=BG)
        self._label(self.adv_frame, 'SMTP server host:')
        self.smtp_server_var, _ = self._entry(self.adv_frame, placeholder='smtp.gmail.com')
        self._label(self.adv_frame, 'SMTP port:')
        self.smtp_port_var, _ = self._entry(self.adv_frame, placeholder='587')
        self._label(self.adv_frame, 'IMAP server host (for reply tracking):')
        self.imap_server_var, _ = self._entry(self.adv_frame, placeholder='imap.gmail.com')
        self._label(self.adv_frame, 'IMAP port:')
        self.imap_port_var, _ = self._entry(self.adv_frame, placeholder='993')

        def toggle_adv(_e=None):
            if self.adv_open.get():
                self.adv_frame.pack_forget()
                adv_toggle.config(text='▶  Advanced SMTP/IMAP settings (SendGrid, Mailgun, etc.)')
                self.adv_open.set(False)
            else:
                self.adv_frame.pack(fill='x')
                adv_toggle.config(text='▼  Advanced SMTP/IMAP settings (SendGrid, Mailgun, etc.)')
                self.adv_open.set(True)
        adv_toggle.bind('<Button-1>', toggle_adv)

        # ── AI Provider ───────────────────────────────────────────────────────
        self._section(body, '2.  AI Email Generation')
        self._label(body, '💡 Help: Which option should I choose?\n'
                          '• OpenAI / Anthropic: Highly intelligent cloud personalization.\n'
                          '• Groq / Gemini: 100% FREE API keys. Fast and fully cloud-hosted.\n'
                          '• Note: You can switch providers or add other models later in Settings.',
                    font=(FONT_UI[0], 9.5), fg=MUTED, pady=4)

        self.provider_var = tk.StringVar(value='groq')
        providers = [
            ('openai',    '☁  OpenAI API (Cloud)',
             'Get a developer account key at: platform.openai.com/api-keys'),
            ('anthropic', '☁  Anthropic API (Cloud)',
             'Get a developer account key at: console.anthropic.com/settings/keys'),
            ('groq',      '⚡  Groq Cloud API (100% FREE API Key)',
             'Get a free account key at: console.groq.com (recommended for fast free setup)'),
            ('google',    '♊  Google Gemini API (100% FREE API Key)',
             'Get a free account key at: aistudio.google.com (Gemini 1.5 Flash)'),
            ('ollama',    '🖥  Ollama Local (Local / Free / Private)',
             'Bonus / Advanced. Requires Ollama installed: ollama.com'),
        ]
        for val, lbl, hint in providers:
            row = tk.Frame(body, bg=CARD, pady=8, padx=12, cursor='hand2')
            row.pack(fill='x', pady=3)
            rb = tk.Radiobutton(row, variable=self.provider_var, value=val,
                                bg=CARD, fg=FG, selectcolor=CARD,
                                activebackground=CARD, font=FONT_UI, text=lbl)
            rb.pack(anchor='w')
            tk.Label(row, text=hint, bg=CARD, fg=MUTED,
                     font=(FONT_UI[0], 9)).pack(anchor='w', padx=20)
            row.bind('<Button-1>', lambda e, v=val: self.provider_var.set(v))

        self._label(body, 'API Key (leave blank if using Ollama):', pady=8)
        self.api_key_var, self.api_key_entry = self._entry(
            body, placeholder='Paste your API Key here')

        # ── Ollama model ──────────────────────────────────────────────────────
        self._label(body, 'Ollama model (only needed if using Ollama):', pady=0)
        self.ollama_model_var, _ = self._entry(body, placeholder='llama3.2:3b')

        # ── Google Places ─────────────────────────────────────────────────────
        self._section(body, '3.  Google Places API (Optional)')
        
        link_frame = tk.Frame(body, bg=BG)
        link_frame.pack(fill='x', pady=(4, 0))
        tk.Label(link_frame, text='Used to find local business leads. ', bg=BG, fg=MUTED, font=(FONT_UI[0], 10)).pack(side='left')
        link = tk.Label(link_frame, text='Get free key →', bg=BG, fg=CYAN, font=(FONT_UI[0], 10), cursor='hand2')
        link.pack(side='left')
        link.bind('<Button-1>', lambda e: webbrowser.open('https://console.cloud.google.com'))

        self._label(body, 'Google Places API Key:')
        self.google_places_api_key_var, _ = self._entry(body, placeholder='AIzaSy...')

        # ── Footer ────────────────────────────────────────────────────────────
        tk.Frame(body, bg=BG, height=20).pack()

        foot = tk.Frame(self, bg=CARD, padx=24, pady=16)
        foot.pack(fill='x', side='bottom')

        self.status_var = tk.StringVar(value='')
        tk.Label(foot, textvariable=self.status_var, bg=CARD, fg=YELLOW,
                 font=(FONT_UI[0], 10)).pack(anchor='w')

        btn = tk.Button(foot, text='  Save & Launch ProMailer  →',
                        bg=CYAN, fg='#000000', font=(FONT_UI[0], 12, 'bold'),
                        relief='flat', padx=20, pady=10, cursor='hand2',
                        command=self._save)
        btn.pack(anchor='e', pady=(8, 0))

    # ── Validation & save ─────────────────────────────────────────────────────
    def _get(self, var, placeholder=''):
        v = var.get().strip()
        return '' if v == placeholder else v

    def _save(self):
        provider    = self.provider_var.get()
        api_key     = self._get(self.api_key_var,     'sk-...  or  sk-ant-...')
        ollama_model= self._get(self.ollama_model_var,'llama3.2:3b') or 'llama3.2:3b'
        smtp_user   = self._get(self.smtp_user_var,   'you@gmail.com')
        smtp_pass   = self.smtp_pass_var.get().strip()
        sender_name = self._get(self.sender_name_var, 'William from ProMailer')
        reply_to    = self._get(self.reply_to_var,    'optional@yourdomain.com')
        smtp_server = self._get(self.smtp_server_var, 'smtp.gmail.com') or 'smtp.gmail.com'
        smtp_port   = self._get(self.smtp_port_var,   '587') or '587'
        google_places_key = self._get(self.google_places_api_key_var, 'AIzaSy...')

        # Validate required fields
        if not smtp_user:
            self.status_var.set('⚠  Sender email address is required.')
            return
        if not smtp_pass:
            self.status_var.set('⚠  SMTP password / App Password is required.')
            return
        if provider in ('openai', 'anthropic', 'groq', 'google') and not api_key:
            self.status_var.set('⚠  API key is required for cloud providers.')
            return

        if not sender_name:
            sender_name = smtp_user.split('@')[0].capitalize()
        if not reply_to:
            reply_to = smtp_user

        # Auto-derive IMAP settings
        domain = smtp_user.split('@')[-1].lower() if '@' in smtp_user else ''
        if domain in ['gmail.com', 'googlemail.com'] or smtp_server == 'smtp.gmail.com':
            default_imap_server = 'imap.gmail.com'
            default_imap_port = '993'
        else:
            default_imap_server = f'imap.{domain}'
            default_imap_port = '993'

        imap_server = self._get(self.imap_server_var, 'imap.gmail.com') or default_imap_server
        imap_port   = self._get(self.imap_port_var,   '993') or default_imap_port

        # Assign keys to correct variable
        openai_key    = api_key if provider == 'openai'    else ''
        anthropic_key = api_key if provider == 'anthropic' else ''
        groq_key      = api_key if provider == 'groq'      else ''
        google_key    = api_key if provider == 'google'    else ''
        ollama_url    = 'http://localhost:11434/api/generate'

        env_content = f"""# ProMailer Configuration
# Generated by setup wizard — do not share this file.

SMTP_SERVER={smtp_server}
SMTP_PORT={smtp_port}
SMTP_USER={smtp_user}
SMTP_PASSWORD={smtp_pass}
SENDER_NAME={sender_name}
REPLY_TO={reply_to}

IMAP_SERVER={imap_server}
IMAP_PORT={imap_port}

GMAIL_USER={smtp_user}
GMAIL_APP_PASSWORD={smtp_pass}

DAILY_SEND_LIMIT=20
COOLDOWN_MINUTES=4
LLM_PROVIDER={provider}

OLLAMA_URL={ollama_url}
OLLAMA_MODEL={ollama_model}

OPENAI_API_KEY={openai_key}
OPENAI_MODEL=gpt-4o-mini

ANTHROPIC_API_KEY={anthropic_key}
ANTHROPIC_MODEL=claude-3-5-haiku-20241022

GROQ_API_KEY={groq_key}
GROQ_MODEL=llama3-8b-8192

GOOGLE_API_KEY={google_key}
GOOGLE_MODEL=gemini-1.5-flash

GOOGLE_PLACES_API_KEY={google_places_key}
"""
        try:
            ENV_FILE.write_text(env_content)
            if platform.system() != 'Windows':
                os.chmod(ENV_FILE, 0o600)
            self.status_var.set('✓ Configuration saved — launching dashboard...')
            self.after(800, self._finish)
        except Exception as e:
            self.status_var.set(f'Error saving config: {e}')

    def _finish(self):
        self.destroy()


# ═════════════════════════════════════════════════════════════════════════════
#  FLASK DASHBOARD LAUNCHER
# ═════════════════════════════════════════════════════════════════════════════

def open_browser(url):
    """Open the URL in Chrome's App Mode (chromeless window) or fallback to default browser."""
    import platform
    import subprocess
    syst = platform.system()
    try:
        if syst == 'Darwin':  # macOS
            # Try Chrome App Mode first for "native app" feel
            chrome_path = "/Applications/Google Chrome.app"
            if os.path.exists(chrome_path):
                subprocess.Popen(['open', '-a', 'Google Chrome', '--args', f'--app={url}'])
                return
            # Fallback to macOS open command (more reliable than webbrowser.open)
            subprocess.Popen(['open', url])
            return
        elif syst == 'Windows':
            # Try Chrome App Mode on Windows
            import winreg
            try:
                # Check if Chrome is in registry
                key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe")
                winreg.CloseKey(key)
                subprocess.Popen(['cmd', '/c', 'start', 'chrome', f'--app={url}'])
                return
            except Exception:
                pass
            # Fallback to standard start
            subprocess.Popen(['cmd', '/c', 'start', url])
            return
        elif syst == 'Linux':
            # Try google-chrome app mode
            try:
                subprocess.Popen(['google-chrome', f'--app={url}'])
                return
            except Exception:
                pass
            # Fallback to xdg-open
            subprocess.Popen(['xdg-open', url])
            return
    except Exception:
        pass
    
    # Ultimate fallback to python's built-in webbrowser module
    webbrowser.open(url)


def launch_dashboard():
    """Start Flask in a background thread, then open the browser."""
    os.chdir(DATA_DIR)
    load_dotenv(ENV_FILE)

    # Delay import until after chdir so Flask finds templates/static
    from dashboard import app

    def _run():
        app.run(host='127.0.0.1', port=5050, debug=False, use_reloader=False)

    t = threading.Thread(target=_run, daemon=True)
    t.start()

    # Wait for Flask to be ready then open browser
    time.sleep(1.2)
    open_browser('http://localhost:5050')

    # Keep the process alive (the daemon thread dies if main thread exits)
    show_tray_message()


def show_tray_message():
    """
    Show a minimal 'ProMailer is running' window with a Quit button.
    Keeps the process alive while Flask serves in the background.
    """
    root = tk.Tk()
    root.title('ProMailer')
    root.configure(bg=BG)
    root.resizable(False, False)

    w, h = 380, 160
    x = (root.winfo_screenwidth()  - w) // 2
    y = (root.winfo_screenheight() - h) // 2
    root.geometry(f'{w}x{h}+{x}+{y}')

    tk.Label(root, text='⚡ ProMailer is running',
             bg=BG, fg=CYAN, font=FONT_H2).pack(pady=(28, 4))
    tk.Label(root, text='Dashboard open at  http://localhost:5050',
             bg=BG, fg=MUTED, font=FONT_UI).pack()

    btn_frame = tk.Frame(root, bg=BG)
    btn_frame.pack(pady=20)

    tk.Button(btn_frame, text='Open Dashboard', bg=CARD, fg=FG,
              font=FONT_UI, relief='flat', padx=14, pady=6, cursor='hand2',
              command=lambda: open_browser('http://localhost:5050')
              ).pack(side='left', padx=8)

    tk.Button(btn_frame, text='Quit ProMailer', bg=CARD, fg=RED,
              font=FONT_UI, relief='flat', padx=14, pady=6, cursor='hand2',
              command=root.destroy
              ).pack(side='left', padx=8)

    root.mainloop()


# ═════════════════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ═════════════════════════════════════════════════════════════════════════════

def kill_port_5050():
    """Kill any previous process running on port 5050 to resolve port conflicts."""
    import signal
    import subprocess
    syst = platform.system()
    try:
        if syst in ('Darwin', 'Linux'):
            pids = subprocess.check_output(["lsof", "-t", "-i:5050"]).decode().strip().split()
            for pid in pids:
                if pid:
                    os.kill(int(pid), signal.SIGKILL)
                    print(f"Killed old ProMailer process on port 5050: PID {pid}")
        elif syst == 'Windows':
            cmd = 'netstat -ano | findstr :5050'
            out = subprocess.check_output(cmd, shell=True).decode().strip()
            for line in out.split('\n'):
                parts = line.strip().split()
                if len(parts) >= 5 and parts[1].endswith(':5050'):
                    pid = parts[4]
                    subprocess.run(f"taskkill /F /PID {pid}", shell=True)
                    print(f"Killed old ProMailer process on port 5050: PID {pid}")
    except Exception:
        pass


def main():
    # Kill any dangling background processes from a previous run
    kill_port_5050()

    os.chdir(DATA_DIR)

    if not ENV_FILE.exists():
        # First run — show GUI setup wizard
        wizard = SetupWizard()
        wizard.mainloop()

        # If user closed without saving, exit
        if not ENV_FILE.exists():
            sys.exit(0)

    # Config exists — launch dashboard
    launch_dashboard()


if __name__ == '__main__':
    main()
