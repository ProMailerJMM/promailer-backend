"""
ProMailer — lead_finder.py
Lead Discovery Engine

Searches Google Places API for businesses by type + location,
scrapes each website for contact emails, and loads results
directly into the ProMailer SQLite pipeline.

Usage:
    python3 lead_finder.py                         # launches interactive GUI
    python3 lead_finder.py --cli                   # CLI mode
"""

import os
import re
import csv
import sys
import time
import sqlite3
import requests
import threading
from pathlib import Path
from urllib.parse import urlparse, urljoin
from bs4 import BeautifulSoup
from dotenv import load_dotenv
from datetime import datetime

load_dotenv()

# ── Config ────────────────────────────────────────────────────────────────────
DB_NAME          = os.getenv("DB_NAME", "pipeline.db")
GOOGLE_API_KEY   = os.getenv("GOOGLE_PLACES_API_KEY", "")
PLACES_SEARCH_URL = "https://maps.googleapis.com/maps/api/place/textsearch/json"
PLACES_DETAIL_URL = "https://maps.googleapis.com/maps/api/place/details/json"
PLACES_NEXT_URL   = "https://maps.googleapis.com/maps/api/place/textsearch/json"

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    )
}

# Common contact page slugs to check for emails
CONTACT_SLUGS = [
    "/contact", "/contact-us", "/about", "/about-us",
    "/team", "/our-team", "/staff", "/people",
    "/get-in-touch", "/reach-us", "/connect",
]

EMAIL_REGEX = re.compile(
    r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}"
)

# Domains to ignore in email extraction
IGNORE_EMAIL_DOMAINS = {
    "example.com", "sentry.io", "wixpress.com", "squarespace.com",
    "wordpress.com", "godaddy.com", "w3.org", "schema.org",
    "googleapis.com", "google.com", "facebook.com", "twitter.com",
    "instagram.com", "linkedin.com", "youtube.com", "apple.com",
    "microsoft.com", "amazon.com", "cloudflare.com",
}


# ═════════════════════════════════════════════════════════════════════════════
#  GOOGLE PLACES SEARCH
# ═════════════════════════════════════════════════════════════════════════════

def search_places(query: str, max_results: int = 60,
                  progress_cb=None) -> list[dict]:
    """
    Search Google Places API for businesses matching query.
    Returns list of dicts with name, address, website, phone, place_id.
    Falls back to free DuckDuckGo scraping if no API key.
    """
    if GOOGLE_API_KEY:
        return _search_google_places(query, max_results, progress_cb)
    else:
        return _search_duckduckgo_fallback(query, max_results, progress_cb)


def _search_google_places(query: str, max_results: int,
                           progress_cb=None) -> list[dict]:
    results = []
    params  = {"query": query, "key": GOOGLE_API_KEY}
    page    = 0

    while len(results) < max_results:
        if progress_cb:
            progress_cb(f"🔍  Searching Google Places — page {page + 1}...")

        try:
            r = requests.get(PLACES_SEARCH_URL, params=params, timeout=10)
            data = r.json()
        except Exception as e:
            if progress_cb:
                progress_cb(f"⚠  Google Places error: {e}")
            break

        if data.get("status") not in ("OK", "ZERO_RESULTS"):
            if progress_cb:
                progress_cb(f"⚠  Google Places: {data.get('status')} — {data.get('error_message','')}")
            break

        for place in data.get("results", []):
            if len(results) >= max_results:
                break

            # Get extra detail (website, phone)
            detail = _get_place_detail(place["place_id"])
            results.append({
                "company_name": place.get("name", ""),
                "address":      place.get("formatted_address", ""),
                "website":      detail.get("website", ""),
                "phone":        detail.get("formatted_phone_number", ""),
                "place_id":     place["place_id"],
                "contact_name": "",
                "contact_email": "",
                "industry":     query,
            })
            time.sleep(0.05)  # gentle rate limiting

        next_token = data.get("next_page_token")
        if not next_token or len(results) >= max_results:
            break

        page += 1
        time.sleep(2)  # Google requires delay before next_page_token is valid
        params = {"pagetoken": next_token, "key": GOOGLE_API_KEY}

    return results


def _get_place_detail(place_id: str) -> dict:
    try:
        r = requests.get(PLACES_DETAIL_URL, params={
            "place_id": place_id,
            "fields": "website,formatted_phone_number",
            "key": GOOGLE_API_KEY,
        }, timeout=8)
        return r.json().get("result", {})
    except Exception:
        return {}


def _search_duckduckgo_fallback(query: str, max_results: int,
                                 progress_cb=None) -> list[dict]:
    """
    Free fallback using DuckDuckGo HTML search + result scraping.
    No API key required. Slower but works out of the box.
    """
    if progress_cb:
        progress_cb("🔍  No Google API key — using free web search fallback...")

    results  = []
    seen_domains = set()

    # Break query into pages of 10
    for start in range(0, min(max_results * 3, 90), 10):
        if len(results) >= max_results:
            break

        if progress_cb:
            progress_cb(f"🌐  Scanning search results {start + 1}–{start + 10}...")

        try:
            r = requests.get(
                "https://html.duckduckgo.com/html/",
                params={"q": query, "s": start},
                headers=HEADERS,
                timeout=12
            )
            soup = BeautifulSoup(r.text, "html.parser")
            links = soup.select("a.result__url")

            for link in links:
                if len(results) >= max_results:
                    break

                url = link.get("href", "").strip()
                if not url.startswith("http"):
                    url = "https://" + url

                domain = urlparse(url).netloc.replace("www.", "")

                # Skip aggregators, directories, social
                skip = {"yelp.com","yellowpages.ca","yellowpages.com",
                        "facebook.com","linkedin.com","twitter.com",
                        "instagram.com","google.com","findlaw.com",
                        "lawyers.com","avvo.com","justia.com",
                        "martindale.com","lawinfo.com","bark.com",
                        "thumbtack.com","clutch.co","bbb.org"}
                if any(s in domain for s in skip):
                    continue
                if domain in seen_domains:
                    continue

                seen_domains.add(domain)
                name = link.get_text(strip=True) or domain

                results.append({
                    "company_name":  name,
                    "address":       "",
                    "website":       url,
                    "phone":         "",
                    "place_id":      "",
                    "contact_name":  "",
                    "contact_email": "",
                    "industry":      query,
                })

            time.sleep(1.5)

        except Exception as e:
            if progress_cb:
                progress_cb(f"⚠  Search page error: {e}")
            time.sleep(3)

    return results


# ═════════════════════════════════════════════════════════════════════════════
#  EMAIL SCRAPER
# ═════════════════════════════════════════════════════════════════════════════

def scrape_email_from_website(url: str, timeout: int = 10) -> tuple[str, str]:
    """
    Scrape a website for the best contact email.
    Returns (email, contact_name) — contact_name may be empty.
    Checks homepage first, then common contact page slugs.
    """
    if not url:
        return "", ""

    if not url.startswith("http"):
        url = "https://" + url

    try:
        base_url = f"{urlparse(url).scheme}://{urlparse(url).netloc}"
    except Exception:
        return "", ""

    pages_to_check = [url] + [base_url + slug for slug in CONTACT_SLUGS]
    found_emails   = []

    for page_url in pages_to_check:
        try:
            r = requests.get(page_url, headers=HEADERS,
                             timeout=timeout, allow_redirects=True)
            if r.status_code != 200:
                continue

            # Check mailto: links first (most reliable)
            soup = BeautifulSoup(r.text, "html.parser")
            for a in soup.find_all("a", href=True):
                href = a["href"]
                if href.startswith("mailto:"):
                    email = href.replace("mailto:", "").split("?")[0].strip().lower()
                    if _valid_email(email):
                        found_emails.append(email)

            # Fallback: regex scan page text
            if not found_emails:
                text_emails = EMAIL_REGEX.findall(r.text)
                for email in text_emails:
                    email = email.lower().strip(".")
                    if _valid_email(email):
                        found_emails.append(email)

            if found_emails:
                break  # stop as soon as we find something

        except Exception:
            continue

    if not found_emails:
        return "", ""

    # Pick the best email — prefer generic over personal
    best = _pick_best_email(found_emails)
    return best, ""


def _valid_email(email: str) -> bool:
    if not email or "@" not in email:
        return False
    domain = email.split("@")[-1].lower()
    if domain in IGNORE_EMAIL_DOMAINS:
        return False
    if len(email) > 100:
        return False
    # Must have a real TLD
    parts = domain.split(".")
    if len(parts) < 2 or len(parts[-1]) < 2:
        return False
    return True


def _pick_best_email(emails: list[str]) -> str:
    """Prefer info@, contact@, hello@, admin@ over personal addresses."""
    priority_prefixes = ["info", "contact", "hello", "admin",
                         "office", "team", "enquiries", "enquiry",
                         "mail", "support", "general"]
    for prefix in priority_prefixes:
        for email in emails:
            if email.startswith(f"{prefix}@"):
                return email
    return emails[0]  # fallback to first found


# ═════════════════════════════════════════════════════════════════════════════
#  DATABASE LOADER
# ═════════════════════════════════════════════════════════════════════════════

def load_leads_to_db(leads: list[dict], progress_cb=None) -> tuple[int, int]:
    """
    Insert scraped leads into ProMailer's SQLite pipeline.
    Returns (added, skipped) counts.
    """
    conn = sqlite3.connect(DB_NAME, timeout=30)
    conn.execute("PRAGMA journal_mode=WAL")
    cursor = conn.cursor()
    added = skipped = 0

    for lead in leads:
        email = lead.get("contact_email", "").strip().lower()
        if not email:
            skipped += 1
            continue
        try:
            cursor.execute("""
                INSERT INTO leads
                    (company_name, contact_name, contact_email,
                     website, practice_areas, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                lead.get("company_name", ""),
                lead.get("contact_name", "") or None,
                email,
                lead.get("website", "") or None,
                lead.get("industry", "") or None,
                datetime.now().isoformat(),
            ))
            added += 1
        except sqlite3.IntegrityError:
            skipped += 1  # duplicate email

    conn.commit()
    conn.close()

    if progress_cb:
        progress_cb(f"✅  Loaded {added} new leads into pipeline. ({skipped} duplicates skipped)")

    return added, skipped


def export_leads_to_csv(leads: list[dict], filepath: str) -> str:
    """Export a list of leads to a CSV file."""
    path = Path(filepath)
    fieldnames = ["company_name", "contact_name", "contact_email",
                  "website", "phone", "address", "industry"]
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(leads)
    return str(path)


# ═════════════════════════════════════════════════════════════════════════════
#  MAIN FIND + ENRICH PIPELINE
# ═════════════════════════════════════════════════════════════════════════════

def find_and_enrich(
    query: str,
    max_results: int = 40,
    load_to_db: bool = True,
    export_csv: bool = True,
    progress_cb=None,
) -> dict:
    """
    Full pipeline:
    1. Search for businesses matching query
    2. Scrape each website for contact email
    3. Load into ProMailer database
    4. Export CSV

    Returns summary dict.
    """
    if progress_cb:
        progress_cb(f"🚀  Starting lead search: \"{query}\"")
        progress_cb(f"📊  Target: {max_results} leads")

    # Step 1 — Find businesses
    businesses = search_places(query, max_results, progress_cb)

    if not businesses:
        if progress_cb:
            progress_cb("⚠  No businesses found. Try a different search query.")
        return {"found": 0, "with_email": 0, "added": 0, "skipped": 0, "leads": []}

    if progress_cb:
        progress_cb(f"📋  Found {len(businesses)} businesses. Scraping contact emails...")

    # Step 2 — Scrape emails
    enriched = []
    for i, biz in enumerate(businesses):
        website = biz.get("website", "")
        name    = biz.get("company_name", "Unknown")

        if progress_cb:
            progress_cb(f"📧  [{i+1}/{len(businesses)}] Scraping {name}...")

        if website:
            email, contact_name = scrape_email_from_website(website)
            biz["contact_email"] = email
            biz["contact_name"]  = contact_name
        else:
            biz["contact_email"] = ""
            biz["contact_name"]  = ""

        enriched.append(biz)
        time.sleep(0.3)  # polite delay

    with_email = sum(1 for b in enriched if b.get("contact_email"))

    if progress_cb:
        progress_cb(f"✉️   Found emails for {with_email}/{len(enriched)} businesses")

    # Step 3 — Load to DB
    added = skipped = 0
    if load_to_db:
        added, skipped = load_leads_to_db(enriched, progress_cb)

    # Step 4 — Export CSV
    csv_path = ""
    if export_csv and enriched:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_query = re.sub(r'[^\w\s-]', '', query).strip().replace(' ', '_')[:40]
        csv_path   = export_leads_to_csv(
            enriched, f"leads_{safe_query}_{timestamp}.csv"
        )
        if progress_cb:
            progress_cb(f"💾  CSV exported: {csv_path}")

    if progress_cb:
        progress_cb(f"\n🎯  Complete! {added} leads loaded into your ProMailer pipeline.")

    return {
        "found":      len(businesses),
        "with_email": with_email,
        "added":      added,
        "skipped":    skipped,
        "leads":      enriched,
        "csv_path":   csv_path,
    }


# ═════════════════════════════════════════════════════════════════════════════
#  CLI MODE
# ═════════════════════════════════════════════════════════════════════════════

def run_cli():
    GREEN  = "\033[92m"
    CYAN   = "\033[96m"
    YELLOW = "\033[93m"
    BOLD   = "\033[1m"
    RESET  = "\033[0m"

    print(f"\n{BOLD}{CYAN}⚡ ProMailer — Lead Finder{RESET}")
    print("─" * 45)

    if not GOOGLE_API_KEY:
        print(f"{YELLOW}! No GOOGLE_PLACES_API_KEY in .env — using free fallback search.{RESET}")
        print(f"{YELLOW}  For better results, add a Google Places API key.{RESET}\n")

    query = input("Search query (e.g. 'criminal lawyers Ottawa Ontario'): ").strip()
    if not query:
        print("No query entered. Exiting.")
        sys.exit(0)

    try:
        count = int(input("How many leads? [Default: 40]: ").strip() or "40")
    except ValueError:
        count = 40

    print()
    result = find_and_enrich(
        query=query,
        max_results=count,
        load_to_db=True,
        export_csv=True,
        progress_cb=lambda msg: print(f"  {msg}"),
    )

    print(f"\n{GREEN}{BOLD}Results:{RESET}")
    print(f"  Businesses found:  {result['found']}")
    print(f"  Emails scraped:    {result['with_email']}")
    print(f"  Added to pipeline: {result['added']}")
    print(f"  Duplicates skipped:{result['skipped']}")
    if result.get("csv_path"):
        print(f"  CSV saved to:      {result['csv_path']}")
    print()


if __name__ == "__main__":
    if "--cli" in sys.argv:
        run_cli()
    else:
        # Launch GUI if available, fall back to CLI
        try:
            import tkinter
            from lead_finder_gui import LeadFinderApp
            app = LeadFinderApp()
            app.mainloop()
        except ImportError:
            run_cli()
